# Fleetwood pull progress (fork). PGA ids 30911, DP 35371.
PGA rounds to pull via parse get_player_shots_compact (1 credit): R2026005 1-4, 007 1-4, 009 1-4, 011 1-4, 041 1-4, 012 1-4, 556 1-4, 480 1-4, 033 1-2, 023 1-4, 032 1-4, 026 1-4, 034 1-4, 541 1-4, 027 1-4, 028 1-4 (060 already in RCProjects pga-2026-sample). Masters 014 + Open 100 = scores only.
Check which are done: python3 extract.py pga-raw  (reads transcripts)
DP: plan.txt (8 DP-only events), workers via ../forrest pattern in this dir.
Field avgs PGA: ../scottie/cs/<ev>/csN.json (all present).
