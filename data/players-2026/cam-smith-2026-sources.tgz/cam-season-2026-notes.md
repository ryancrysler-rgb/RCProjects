# Cameron Smith: the 2026 season (counted 2026-11-04; 41 rounds, all with shots)

> **Owner override, 2026-11-04:** "convert to meters for all Cams data".
>
> The house rule (metres computed end to end, never converted) is waived for this report.
> - **Converted rounds:** 26. These are LIV Mexico R1–R4, LIV Virginia R1–R4, LIV Korea R1–R4, LIV Andalucía R1–R4, the Masters R1–R2, the PGA Championship R1–R4, the U.S. Open R1–R2 and The Open R1–R2, at yd × 0.9144.
> - **Labelling:** each converted round carries `units: "m (converted from yd, owner 2026-11-04)"` in the JSON.
> - **Approximate starts:** Clippd start distances are approximate (Mexico, Virginia, Korea, Andalucía, Open, Masters). They are worked back from the first putt and each shot's travel, with the tee shot starting at the hole length.
> - **Putting** stays in feet.

## Rules followed

- Bands are named, never spans.
- Inside 6 ft is held against a 100% standard.
- Every superlative was checked against the counts.
- Tour figures come only from the tour study dated 2026-10-31 (`tour-benchmarks.js`, house rules v17).

## Season order

| # | Event | Dates and source |
|---|---|---|
| 1 | LIV Mexico | 4–5 May by the Clippd timestamps. R1 and R2 share a day, so these may be upload dates. |
| 2 | LIV Virginia | Trump National Washington DC, 7–10 May |
| 3 | The Masters | Not dated in the files. It is played in April, so it may come first. |
| 4 | PGA Championship | May, per the coordinator |
| 5 | LIV Korea | 28–31 May |
| 6 | LIV Andalucía | Real Club Valderrama, 4–7 Jun |
| 7 | U.S. Open | June, per the coordinator |
| 8–13 | The Open, LIV UK, LIV NY, LIV Indy, FedEx Open de France, Dunhill R3 | |

## Season totals

- **Score:** 2,881 strokes (−25) across 41 rounds.
- **Korea R4** now has shots: the owner replaced its scorecard with the Shot by Shot page. H6 is read as stroke and distance (Tee → Tee 192 yds, shot 2 the penalty).

## Event table

| Event | Score | Finish | FW | GIR | Putts/rd | Inside 6 ft | Scrambling | CFP | Dead-zone leaves |
|---|---|---|---|---|---|---|---|---|---|
| Mexico | 286 (+2) | not on file | 22/56 | 43/72 | 29.5 | 60/67 | 14/29 | 10/24 | 9 |
| **Virginia** | **281 (−7), par 72** | **T26 (header)** | **20/56** | **53/72** | **30.0** | **59/59** | **9/19** | **7/18** | **8** |
| Masters | 151 (+7) | MC | 15/28 | 15/36 | 27.5 | 30/32 | 11/21 | 7/15 | 3 |
| PGA | 276 (−4) | T7 | 23/56 | 49/72 | 29.5 | 57/59 | 13/23 | 10/21 | 3 |
| **Korea** | **276 (−4), par 70** | **T4 / 2nd (sources disagree)** | **37/56** | **49/72** | **28.0** | **60/63** | **16/23** | **7/10** | **2** |
| **Andalucía** | **279 (−5), par 71** | **not on file** | **31/56** | **50/72** | **29.3** | **54/59** | **11/22** | **12/20** | **5** |
| U.S. Open | 146 (+6) | MC | 19/28 | 20/36 | 30.5 | 31/34 | 9/16 | 3/9 | 2 |
| Open | 142 (+2) | not on file | 11/28 | 20/36 | 28.5 | 29/30 | 10/16 | 4/11 | 0 |
| UK | 271 (−17) | 4th | 31/56 | 47/72 | 26.0 | 51/53 | 14/25 | 9/18 | 5 |
| NY | 288 (+4) | T28 | 32/56 | 41/72 | 28.5 | 55/58 | 19/31 | 14/25 | 8 |
| Indy | 270 (−10) | T17 | 48/56 | 43/72 | 25.5 | 55/56 | 23/29 | 7/12 | 4 |
| France | 144 (+2) | not on file | 23/28 | 21/36 | 29.0 | 30/31 | 10/15 | 2/7 | 1 |
| Dunhill R3 | 71 (−1) | not on file | 10/16 | 11/18 | 29 | 15/18 | 4/7 | 0/2 | 0 |
| **Season (41)** | **2,881 (−25)** | | **322/576 (56%)** | **462/738 (62.6%)** | **28.4** | **586/619 (95%)** | **163/276 (59%)** | **92/192 (48%)** | **50** |

CFP = Clutch Factor Putting. Season three-putts: 16. Penalty holes: 16.

Korea R4: 73 (+3). FW 8/14, GIR 10/18, 27 putts, 0 three-putts, inside 6 ft 17/18, scrambling 4/8, Clutch Factor Putting 1/2, 2 birdies, 3 bogeys and 1 double (H6, stroke and distance). Par 5s: laid up at H4 to 115.2 m (−1) and at H15 to 207.9 m (par). No dead-zone leaves.

### Virginia by round

| | R1 | R2 | R3 | R4 |
|---|---|---|---|---|
| Score | 72 (E) | 69 (−3) | 69 (−3) | 71 (−1) |
| FW | 5/14 | 6/14 | 4/14 | 5/14 |
| GIR | 14/18 | 14/18 | 14/18 | 11/18 |
| Putts | 31 | 30 | 30 | 29 |
| 3-putts | 1 (H7) | 0 | 1 (H17) | 0 |
| Inside 6 ft | 15/15 | 15/15 | 15/15 | 14/14 |
| Scrambling | 2/4 | 2/4 | 2/4 | 3/7 |
| CFP | 3/5 | 1/3 | 1/4 | 2/6 |
| Penalty holes | H8; H17 (re-tee) | H12 | — | — |
| Par 5s, went | H6 −1 | H6 −1, H17 −1 | H2 0, H12 −1, H17 0 | H2 −1, H12 −1, H17 −1 |
| Par 5s, laid up | H2 to 39 m −1, H12 to 38.7 m 0 | H2 to 47.2 m 0 | H6 to 96 m −1 | H6 to 59.7 m 0 |
| Par 5s, second stroke a penalty | H17 +1 | H12 +1 | — | — |
| Finish | | | | T26 (header) |

### Andalucía by round

| | R1 | R2 | R3 | R4 |
|---|---|---|---|---|
| Score | 69 (−2) | 70 (−1) | 69 (−2) | 71 (E) |
| FW | 9/14 | 6/14 | 5/14 | 11/14 |
| GIR | 16/18 | 12/18 | 12/18 | 10/18 |
| Putts | 31 | 29 | 28 | 29 |
| 3-putts | 0 | 0 | 0 | 0 |
| Inside 6 ft | 13/13 | 14/15 | 13/15 | 14/16 |
| Scrambling | 0/2 | 3/6 | 4/6 | 4/8 |
| CFP | 2/3 | 3/6 | 4/6 | 3/5 |
| Par 5s, went | H11 0 | H11 −1 | H17 −1 | H4 −2 (eagle), H17 −1 |
| Par 5s, laid up | H4 to 72.8 m 0, H17 to 111.9 m −1 | H4 to 296 m 0, H17 to 142.3 m +1 | H4 to 50 m −1, H11 to 128.3 m 0 | H11 to 61 m 0 |
| Note | | | | Read in playing order from hole 5 (the header says "Started 5 … Back"). The file lists holes 1–18. |

## What improved most (owner: "we also need to really emphasize what improved more")

**The split.** I compared the start of the season with the end.
- **First part:** Mexico, Virginia, the Masters, the PGA Championship and Korea (18 rounds). That is the season order up to Korea. I added Mexico and Virginia to your "Masters → Korea" suggestion to double the sample.
- **Last part:** LIV UK, LIV NY, LIV Indianapolis, the French Open and the Dunhill R3 (15 rounds).
- **Left out:** Andalucía, the U.S. Open and The Open (8 rounds) sit between the two parts.

**How a change is called.** A two-proportion z for rates, and a Poisson rate z for per-round counts.
- |z| ≥ 2 is called **improved** (or **went back**).
- Anything smaller is **a direction**: n is too small to call it.

**Source caveat.** The first part is all Clippd and ShotLink rounds converted from yards. The last part is the LIV feed, DP World and computed metric rounds. So Clutch Factor Ball Striking, Clutch Factor Damage Control and the bands are not like for like across the split.

### The two improvements the counts support

1. **Fairways: 46% → 68%** (117/252 → 144/212, z 4.65). This is the clearest gain of the year.
2. **Birdie conversion: 32% → 42%** (67/209 → 69/163, z 2.04). He turned more of his greens into birdies.

### Everything that moved the right way, ranked by size

| # | Measure | Mexico → Korea | UK → Dunhill | Change (pts) | Verdict | What it says |
|---|---|---|---|---|---|---|
| 1 | Fairways | 117/252 (46.4%) | 144/212 (67.9%) | +21.5 | improved (z 4.65) | He hit far more fairways late in the season: 46% across Mexico → Korea, 68% across UK → Dunhill — the clearest gain of the year. |
| 2 | Birdie conversion | 67/209 (32.1%) | 69/163 (42.3%) | +10.3 | improved (z 2.04) | He turned more of his greens into birdies: 32% → 42% of greens hit became birdie or better. |
| 3 | Band 202+ m greens | 14/39 (35.9%) | 16/29 (55.2%) | +19.3 | better (a direction) (z 1.58) | From the 202+ band he found more greens: 36% → 55%. |
| 4 | Clutch Factor Response (answered) | 23/44 (52.3%) | 22/34 (64.7%) | +12.4 | better (a direction) (z 1.1) | After a bogey he answered with a birdie in the next three holes more often: 52% → 65%. |
| 5 | Clutch Factor Response (stopped) | 25/44 (56.8%) | 23/34 (67.6%) | +10.8 | better (a direction) (z 0.97) | After a bogey he kept the next three holes clean more often: 57% → 68%. |
| 6 | Scrambling | 63/115 (54.8%) | 70/107 (65.4%) | +10.6 | better (a direction) (z 1.62) | He saved par more often after missing a green: 55% → 65%. |
| 7 | Band 111–128 m greens | 27/36 (75%) | 28/33 (84.8%) | +9.8 | better (a direction) (z 1.02) | His 111–128 band, already a strength, went 75% → 85%. |
| 8 | Reset hole (next hole par or better after a bogey) | 41/52 (78.8%) | 33/38 (86.8%) | +8 | better (a direction) (z 0.98) | The hole after a bogey was par or better 79% → 87% of the time. |
| 9 | Clutch Factor Putting | 41/88 (46.6%) | 32/64 (50%) | +3.4 | better (a direction) (z 0.42) | He holed slightly more par-saving putts from 5 ft and out: 47% → 50%. |
| 10 | Band 69–91 m greens | 12/15 (80%) | 10/12 (83.3%) | +3.3 | better (a direction) (z 0.22) | The 69–91 band moved 80% → 83%. |

Per-round counts, ranked by relative size (all are directions):

| # | Measure | Mexico → Korea | UK → Dunhill | Change | Verdict | What it says |
|---|---|---|---|---|---|---|
| 1 | Three-putts a round | 8 in 18 rounds (0.44) | 5 in 15 rounds (0.33) | −25% | better (a direction) (z -0.51) | Three-putts fell from 0.44 to 0.33 a round. |
| 2 | Dead-zone leaves a round (37–68 band) | 25 in 18 rounds (1.39) | 18 in 15 rounds (1.2) | −14% | better (a direction) (z -0.47) | Dead-zone leaves fell from 1.4 to 1.2 a round. |
| 3 | Bogeys or worse a round | 56 in 18 rounds (3.11) | 42 in 15 rounds (2.8) | −10% | better (a direction) (z -0.52) | Bogeys or worse fell from 3.1 to 2.8 a round. |
| 4 | Putts a round | 523 in 18 rounds (29.06) | 407 in 15 rounds (27.13) | −7% | better (a direction) (z -1.04) | He took about two putts fewer a round: 29.1 → 27.1. |

**Level:** inside 6 ft (95% in both parts, still short of the 100% standard) and the 92–110 band (63% in both).

### What went back

| Measure | Mexico → Korea | UK → Dunhill | Verdict | Caveat |
|---|---|---|---|---|
| GIR | 209/324 (64.5%) | 163/270 (60.4%) | worse, a direction (z -1.04) | — |
| Clutch Factor Ball Striking | 29/55 (52.7%) | 10/23 (43.5%) | worse, a direction (z -0.74) | cross-source |
| Clutch Factor Damage Control | 51/55 (92.7%) | 16/23 (69.6%) | went back (z -2.68) | cross-source |
| Band ≤36 m greens | 25/25 (100%) | 15/20 (75%) | went back (z -2.65) | cross-source |
| Band 37–68 m greens | 14/16 (87.5%) | 8/10 (80%) | worse, a direction (z -0.52) | cross-source |
| Band 129–146 m greens | 30/40 (75%) | 27/41 (65.9%) | worse, a direction (z -0.9) | cross-source |
| Band 147–165 m greens | 32/52 (61.5%) | 24/40 (60%) | worse, a direction (z -0.15) | cross-source |
| Band 166–183 m greens | 23/34 (67.6%) | 8/16 (50%) | worse, a direction (z -1.2) | cross-source |
| Band 184–201 m greens | 15/33 (45.5%) | 7/26 (26.9%) | worse, a direction (z -1.46) | cross-source |
| Penalty holes a round | 7 in 18 rounds (0.39) | 9 in 15 rounds (0.6) | worse, a direction (z 0.87) | — |

- **Clutch Factor Damage Control and the ≤36 band** both reach z ≥ 2. Both are cross-source:
  - Clippd marks a Recovery lie on its own, so it counts milder trouble holes: 55 in 18 rounds, against 23 in 15 in the LIV-feed part.
  - The first part's ≤36 band uses Clippd start distances, which are approximate.
- **GIR:** −4 points, a direction.

## Clutch Factor stats (`automation/metrics.js` v4; names always in full)

- **Clutch Factor Response** is read in play order. France and the Dunhill are read by hole number, because their feeds carry no play order.
- **Clutch Factor Ball Striking and Clutch Factor Damage Control** count trouble holes the way each source can mark them. Indy R1, from the derived file, is not on file for these two.
- **Clutch Factor Closing** is not on file for every round. There is no start-of-round gap to the lead, and it is not estimated.
- **Per-round detail** is in the JSON `clutch.rounds`.

| Event | Rounds | Clutch Factor Putting | Clutch Factor Ball Striking (semi / flagged) | Clutch Factor Response stopped / answered of att | Clutch Factor Damage Control held / att (doubles) | Clutch Factor Closing |
|---|---|---|---|---|---|---|
| LIV Mexico | 4 | 10/24 | 12/22 (8 / 2) | 7 / 6 of 14 | 20/22 (2) | not on file |
| LIV Virginia | 4 | 7/18 | 4/9 (5 / 0) | 5 / 6 of 7 | 9/9 (0) | not on file |
| The Masters 2026 | 2 | 7/15 | 3/6 (2 / 1) | 4 / 5 of 8 | 5/6 (1) | not on file |
| PGA Championship 2026 | 4 | 10/21 | 8/12 (4 / 0) | 5 / 4 of 8 | 12/12 (0) | not on file |
| LIV Korea | 4 | 7/10 | 2/6 (3 / 1) | 4 / 2 of 7 | 5/6 (1) | not on file |
| LIV Andalucía | 4 | 12/20 | 2/3 (1 / 0) | 7 / 2 of 9 | 3/3 (0) | not on file |
| U.S. Open 2026 | 2 | 3/9 | 5/8 (3 / 0) | 3 / 2 of 7 | 8/8 (0) | not on file |
| The 154th Open | 2 | 4/11 | 3/6 (3 / 0) | 4 / 4 of 7 | 6/6 (0) | not on file |
| LIV UK | 4 | 9/18 | 1/2 (0 / 1) | 6 / 7 of 9 | 1/2 (1) | not on file |
| LIV New York | 4 | 14/25 | 1/5 (2 / 2) | 7 / 6 of 13 | 3/5 (2) | not on file |
| LIV Indianapolis | 4 | 7/12 | 2/5 (2 / 1) | 6 / 5 of 7 | 4/5 (1) | not on file |
| FedEx Open de France | 2 | 2/7 | 3/7 (1 / 3) | 2 / 2 of 2 | 4/7 (3) | not on file |
| Alfred Dunhill Links Championship | 1 | 0/2 | 3/4 (1 / 0) | 2 / 2 of 3 | 4/4 (0) | not on file |
| **Season** | **41** | **92/192 (47.9%)** | **49/95 (51.6%; 35 / 11)** | **62 (61.4%) / 53 (52.5%) of 101** | **84/95 (88.4%; 11)** | **not on file** |

## The bag and the par-5 go-line test

**Where the bag came from:** the owner's Drive sheet "Cam Smith Yardage" (2026-05-07). I used its metres column exactly as the sheet gives it; nothing was converted by us. The sheet does not say whether the figures are carry or total.

| 60 | 56 | 52 | 46 | 9 iron | 8 iron | 7 iron | 6 iron | 5 iron | 4 iron | 7 wood | 3 wood | Driver |
|---|---|---|---|---|---|---|---|---|---|---|---|---|
| 60 | 100 | 114 | 130 | 142 | 154 | 167 | 180 | 194 | 204 | 217 | 240 | 265 |

**How it was run:** `automation/par5-go.js` `assess()` on all 113 par 5s whose second shot was not a penalty.
- **Club:** `deckClub` picked the **3 wood (240 m)** as the longest club off the deck. I ran the **7 wood (217 m)** beside it.
- **Greens test:** passes when the go leave is reachable with the deck club and the season ladder band at that leave reads 40%+. The band needs 3+ approaches, the way `decision-gained.js` reads it.
- **Miss test:** passes when go leave − deck club is under 37 m, which keeps the miss inside the ≤36 band and out of the dead zone.
- **Plan:** "both" = the go is the plan; "one" = his call; "neither" = lay up.
- **"Went":** the second shot finished on the green or in the ≤36 band.
- **Per-hole results** are in the JSON under `study.par5.holes`. par5-go names its distance field `yards`; here it holds metres.

| Club | Cleared a test | Both | Miss only | Greens only | Neither | Goes where cleared | Lay-ups where cleared | Lay-ups where neither | Goes where neither |
|---|---|---|---|---|---|---|---|---|---|
| 3 wood (240 m) | 83 | 32 | 51 | 0 | 30 | 54, −0.67 a hole | 29, +0.07 | 26, −0.27 | 4, −0.25 |
| 7 wood (217 m) | 56 | 10 | 46 | 0 | 57 | 43, −0.65 | 13, +0.15 | 42, −0.17 | 15, −0.60 |

**With the 3 wood:**
- Where both tests cleared (go leave of 240 m or less), his goes scored −0.71 a hole (24) and his lay-ups −0.12 (8).
- Where only the miss cleared (240–277 m), goes scored −0.63 (30) and lay-ups +0.14 (21).
- Most holes that cleared neither were beyond 277 m.

**The read:** with either club, on a hole that clears the test, the go beat the lay-up by about 0.7 a hole. His 29 lay-ups on 3-wood-clear holes are the shots to win back.

**Caveat on the greens test:** it reads the ladder's 202+ band (35/81, 43%), which counts every regulation approach from there. His par-5 second shots from the 202+ band found the green only 15 of 105 times (14%).

## The metric ladder (41 rounds)

| Band | ≤36 | 37–68 | 69–91 | 92–110 | 111–128 | 129–146 | 147–165 | 166–183 | 184–201 | 202+ |
|---|---|---|---|---|---|---|---|---|---|---|
| Greens | 47/52 | 26/32 | 26/33 | 45/66 | 71/90 | 72/103 | 72/121 | 38/62 | 27/75 | 35/81 |
| % | 90 | 81 | 79 | 68 | 79 | 70 | 60 | 61 | 36 | 43 |

- **Overall GIR:** 462/738 (62.6%).
- **Good bands:** ≤36, 37–68, 69–91, 92–110, 111–128 and 129–146.
- **Just under the line:** the 166–183 band (61.3%) and the 147–165 band (59.5%). The 147–165 band is his most-played band.

## The Check

Share of approaches from good bands, and the greens hit from them:

| Event | Share | Greens from good bands |
|---|---|---|
| Mexico | 56% | 28/39 (72%) |
| Virginia | 42% | 27/29 (93%) |
| Masters | 54% | 12/19 (63%) |
| PGA | 50% | 27/36 (75%) |
| Korea | 51% | 31/36 (86%) |
| Andalucía | 61% | 35/44 (80%) |
| U.S. Open | 42% | 11/15 (73%) |
| Open | 42% | 11/15 (73%) |
| UK | 58% | 31/41 (76%) |
| NY | 46% | 24/32 (75%) |
| Indy | 66% | 34/46 (74%) |
| France | 48% | 9/12 (75%) |
| Dunhill | 67% | 7/12 (58%) |

**Read:** neither number tracks his finish.
- Virginia converted best (93%) and finished T26.
- Korea converted 86% and finished T4.
- The Masters converted 63%, the lowest of the multi-round events, and missed the cut.

## Par 5s

| Outcome | Holes | To par | Per hole |
|---|---|---|---|
| Went (on the green or into the ≤36 band) | 58 | −37 | −0.64 |
| Laid up | 55 | −5 | −0.09 |
| Second shot into a penalty | 3 | +3 | +1.00 |

The three penalty seconds were Mexico R4 H6, Virginia R1 H17 and Virginia R2 H12.

- **Where the goes finished:** 17 of the 56 goes with an end lie found the green; the other 39 missed into the ≤36 band.
- **From the 202+ band:** second shots found the green 15 of 105 times.
- **Virginia's par 5s:** −9 in total, the best event total of the season.
- **Korea:** he laid up on all eight par 5s (−2).

Lay-up leaves by band:

| Lay-up left in band | Holes | To par | Per hole |
|---|---|---|---|
| 37–68 | 19 | −5 | −0.26 |
| 69–91 | 8 | 0 | 0.00 |
| 92–110 | 4 | −2 | −0.50 |
| 111–128 | 12 | −2 | −0.17 |
| 129–146 | 3 | +3 | +1.00 |
| 147–165 | 4 | −1 | −0.25 |
| 184–201 | 1 | 0 | 0.00 |
| 202+ | 4 | +2 | +0.50 |

## Reset hole and near the lead

- **Reset hole:** the next hole after a bogey was par or better 99 of 116 times (17 repeats). Clutch Factor Response: stopped 62/101, answered 53/101.
- **Near the lead** (PGA R2 and Indy R2–R4): bogey or worse on 16.7% of holes, against 17.0% in his other rounds, so no worse near the lead. 

## Trends (Mexico → Dunhill)

- **Fairways improved:** 41% across the first four events, 85% at Indy and France. Virginia (36%) is the season's lowest week.
- **GIR is mixed:** the four highest weeks were Virginia 74%, Andalucía 69%, and PGA and Korea tied at 68%, all in May–June. From the U.S. Open on, none was higher than UK's 65%. The Masters (42%) is the low.
- **Clutch Factor Putting is mixed** at 48%. Korea's 70% is the highest event rate, on 10 attempts.
- **Scrambling is mixed:** Virginia 47% is the low; Indy 79% is the high.
- **Bogeys a round are mixed:** Korea 1.8 is the low, the Masters 5.5 the high.
- **Not improved:**
  - The long bands, with the 184–201 band lowest at 36%.
  - Birdie conversion: Korea is the season's lowest at 24% on 68% greens; Virginia converted 34%, Andalucía 30%.
  - Dead-zone leaves: 50 in 40 rounds.
  - Penalty holes: 16.
- **Inside 6 ft:** 95% against the 100% standard. Virginia is the only event at the standard.

## Next to master

1. **The par-5 decision, tested against his bag.**
   - Go on the 83 par 5s where the 3 wood clears par5-go.js. There his goes scored −0.67 a hole and his lay-ups +0.07.
   - Lay up where the test does not clear (beyond 277 m). Those lay-ups scored −0.27 a hole; the 37–68 and 92–110 bands have scored best.
2. **The 184–201 band** (36%) **and the 147–165 band** (60%, his most-played band).
3. **Birdie conversion when the greens come.**

## Hold the standard

- **Inside 6 ft:** 586/619 (95%), 33 misses short of 100%.
- **The ≤36 band** (90%, the highest rate on the ladder) **and the 111–128 band** (79%).
- **The Indy and France tee pattern.**
- **The reset hole.**

## Gaps and disagreements

- **Not on file:** Virginia and Andalucía field averages. The Andalucía finish.
- **Andalucía R4 hole order:** taken from the header, not from the file.
- **Virginia R1 H17:** "Tee → Tee, - yds" is read as a re-tee, with the penalty as stroke 2.
- **Korea finish:** T4 per the coordinator; 2nd per the Drive script.
- **Mexico dates:** may be upload dates.
- **Masters:** not dated in the files.
- **Earlier disagreements:** unchanged (UK sheets, NY R3, Indy R3, Open R2 H18, France R2 H10, Dunhill par-3 tees).
