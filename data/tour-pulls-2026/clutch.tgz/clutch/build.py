import json,html
F=json.load(open('final.json')); e=html.escape
WCB=0.75
import collections as _C
_rd=json.load(open('rounds.json')); _SP=_C.defaultdict(list)
for _a in _rd: _SP[_a['pid']].append(_a)
_nm={x['name']:x for x in F['board']}
for x in F['board']: x['rating']=x['clean']+WCB*x['cb']-x['lost']
F['board'].sort(key=lambda x:-x['rating'])
head=open('../head.html').read().replace('Kiril Engeli Poretti · State of the Game','Clutch Rating · Tour Study')
css='''<style>
.tb{width:100%;border-collapse:collapse;font-size:12px}
.tb th{font-family:var(--fm);font-size:8.6px;letter-spacing:.1em;text-transform:uppercase;color:var(--ink5);font-weight:600;text-align:right;padding:0 6px 6px;border-bottom:1px solid var(--bs)}
.tb th:first-child,.tb th:nth-child(2){text-align:left}
.tb td{padding:5px 6px;border-bottom:1px solid var(--bs);text-align:right;font-family:var(--fm);font-variant-numeric:tabular-nums;color:var(--ink9)}
.tb td:first-child{text-align:left;color:var(--ink5);width:24px}.tb td:nth-child(2){text-align:left;font-family:var(--fs);font-weight:600}
.tb tr:last-child td{border-bottom:0}
.tbw th{color:var(--g300);border-color:var(--bi)}.tbw td{color:#fff;border-color:var(--bi)}.tbw td:first-child{color:var(--g300)}
.bar{display:flex;align-items:center;gap:10px;margin-bottom:7px}
.bar .l{width:230px;font-size:12.5px;color:var(--ink7)}
.bar .t{flex:1;height:18px;background:var(--paper2);border-radius:3px;overflow:hidden}
.bar .v{width:52px;text-align:right;font-family:var(--fm);font-weight:700;font-size:12.5px}
</style>'''
head=head.replace('</head>',css+'</head>')
lock='<div class="lock"><div><div class="wm"><span style="color:#fff;">RCGreen</span><span style="color:var(--g400);">light</span></div><div class="desc" style="color:var(--g300);">Every number ends with a choice</div></div></div>'
def paper(n,label,kick,title,right,body,fn):
    return f'''<section data-label="{label}" data-screen-label="{n:02d}" style="background:var(--paper);color:var(--ink9);"><div style="position:absolute;inset:0;padding:40px 52px 30px;display:flex;flex-direction:column;"><div class="hd"><div><div class="kick" style="color:var(--g700);margin-bottom:10px;">{kick}</div><h2 class="h2">{title}</h2></div><div class="kick" style="color:var(--ink5);text-align:right;">{right}</div></div>{body}<div class="fn" style="margin-top:auto;padding-top:10px;">{fn}</div></div></section>'''
def dark(n,label,kick,title,right,body,fn=''):
    return f'''<section data-label="{label}" data-screen-label="{n:02d}" style="background:var(--g950);color:#fff;"><div style="position:absolute;inset:0;padding:44px 56px 36px;display:flex;flex-direction:column;"><div class="hdd"><div><div class="kick" style="color:var(--lime4);margin-bottom:10px;">{kick}</div><h2 class="h2w">{title}</h2></div><div class="kick" style="color:var(--g300);text-align:right;">{right}</div></div>{body}<div class="fnw" style="margin-top:auto;padding-top:10px;">{fn}</div></div></section>'''
def bar(l,v,w,col,vcol=None):
    return f'<div class="bar"><span class="l">{l}</span><div class="t"><div style="width:{w}%;height:100%;background:{col};"></div></div><span class="v" style="color:{vcol or "var(--ink9)"};">{v}</span></div>'
S=[]
# 1 cover
S.append(f'''<section data-label="Cover" data-screen-label="01" style="background:var(--g950);color:#fff;display:flex;flex-direction:column;justify-content:space-between;">
<svg class="ctour" viewBox="0 0 1056 816" fill="none" aria-hidden="true" style="opacity:.12;"><ellipse cx="830" cy="180" rx="520" ry="330" stroke="#5BD891" stroke-width="1.2"/><ellipse cx="830" cy="180" rx="400" ry="240" stroke="#5BD891" stroke-width="1.1"/><ellipse cx="200" cy="700" rx="380" ry="250" stroke="#B4EA32" stroke-width="1.1"/></svg>
<div style="position:relative;padding:52px 64px 0;display:flex;justify-content:space-between;align-items:flex-start;">{lock}<div class="kick" style="color:var(--g200);border:1px solid var(--bi);border-radius:999px;padding:9px 17px;">Internal study · PGA Tour 2026</div></div>
<div style="position:relative;padding:0 64px;"><div class="kick" style="color:var(--lime4);margin-bottom:20px;">Clutch Rating · working name</div>
<h1 class="dsp" style="font-size:84px;line-height:.92;color:#fff;margin-bottom:24px;">The best comeback<br>is the one you<br><span style="color:var(--lime);">never needed.</span></h1>
<p style="font-size:17px;line-height:1.45;color:var(--g200);max-width:700px;">Who gets back on track after a bad shot, and who avoids the bad shot in the first place. One number for both, tested on every made-cut round we hold.</p></div>
<div style="position:relative;padding:0 64px 44px;display:flex;gap:14px;">
<div class="blw" style="flex:1;"><div class="kick" style="color:var(--g300);font-size:9px;margin-bottom:7px;">Events</div><div class="big mono" style="font-size:38px;color:#fff;">8</div><div class="fnw" style="margin-top:4px;">Jan–Mar + Los Cabos</div></div>
<div class="blw" style="flex:1;"><div class="kick" style="color:var(--g300);font-size:9px;margin-bottom:7px;">Rounds</div><div class="big mono" style="font-size:38px;color:#fff;">1,906</div><div class="fnw" style="margin-top:4px;">every made-cut round with shot detail</div></div>
<div class="blw" style="flex:1;"><div class="kick" style="color:var(--g300);font-size:9px;margin-bottom:7px;">Holes graded</div><div class="big mono" style="font-size:38px;color:#fff;">34,308</div><div class="fnw" style="margin-top:4px;">188 players</div></div>
<div class="blw" style="flex:1;"><div class="kick" style="color:var(--g300);font-size:9px;margin-bottom:7px;">Rating vs score</div><div class="big mono" style="font-size:38px;color:var(--lime);">0.71</div><div class="fnw" style="margin-top:4px;">the strongest link we tested</div></div></div></section>''')
# 2 the idea + trap
S.append(dark(2,'The Idea','— The quarterback question','A comeback stat rewards<br>falling behind. Ours can’t.','The NFL trap',
'''<div style="display:flex;gap:14px;flex:1;min-height:0;">
<div class="blw" style="flex:1;"><div class="kick" style="color:var(--lime4);font-size:9px;margin-bottom:9px;">The question</div><p class="bdw" style="font-size:14px;margin-bottom:10px;">The quarterback with the most fourth-quarter comebacks is the one who keeps winning after falling behind. In golf: <b style="color:#fff;">after a bad shot, who still makes par?</b></p><p class="bdw" style="font-size:14px;">But a comeback needs a deficit. Count comebacks alone and the player who falls behind most looks most clutch.</p></div>
<div class="blw" style="flex:1;background:color-mix(in oklch,var(--lime) 12%,transparent);border-color:var(--lime6);"><div class="kick" style="color:var(--lime);font-size:9px;margin-bottom:9px;">What the data says</div><div class="big mono" style="font-size:64px;color:#fff;margin-bottom:8px;">0.00</div><p class="bdw" style="font-size:14px;color:var(--g100);">The correlation between <b style="color:#fff;">how many comebacks</b> a player makes in a round and how he scores against the field. None. The comebacks and the bad shots that cause them cancel out.</p></div>
<div class="blw" style="flex:1;"><div class="kick" style="color:var(--lime4);font-size:9px;margin-bottom:9px;">So the rating counts both</div><p class="bdw" style="font-size:14px;margin-bottom:10px;"><b style="color:#fff;">Clean holes</b>: no bad shot at all. The house philosophy: decide before the tee, play stress free.</p><p class="bdw" style="font-size:14px;"><b style="color:#fff;">Comebacks</b>: a bad shot, and still par or better, counted at <b style="color:#fff;">three quarters</b> of a clean hole. And it takes one off for every hole <b style="color:#fff;">lost</b> to a double after a bad shot.</p></div></div>''',
'Correlations are across 1,906 rounds, each round scored against the average of its own event and round.'))
# 3 definitions
S.append(paper(3,'The Definition','— What counts, in house-rule terms','A bad shot is a broken<br>house rule.','Approved by RC, 18 Nov',
'''<div style="display:flex;gap:14px;flex:1;min-height:0;">
<div class="card sp" style="flex:1;"><div class="kick" style="color:var(--g700);font-size:9px;margin-bottom:10px;">The four bad shots</div>
<div class="bl" style="margin-bottom:8px;"><b>Tee shot out of play</b> <span class="bd" style="font-size:12px;">· par 4s and 5s: a penalty, a recovery lie or a bunker off the tee (rule 5, off the tee)</span></div>
<div class="bl" style="margin-bottom:8px;"><b>Approach from 160 yards and in that misses the green</b> <span class="bd" style="font-size:12px;">· the scoring zone; par-3 tee shots included</span></div>
<div class="bl" style="margin-bottom:8px;"><b>Chip, pitch or bunker shot off the green</b> <span class="bd" style="font-size:12px;">· inside 50 yards (the green is the minimum)</span></div>
<div class="bl"><b>A miss from 6 feet and in, or a three-putt</b> <span class="bd" style="font-size:12px;">· inside 6 feet is sacred</span></div></div>
<div class="card sp" style="flex:1;"><div class="kick" style="color:var(--g700);font-size:9px;margin-bottom:10px;">Every hole lands in one bucket</div>
<table class="tb"><tr><th></th><th>Bucket</th><th>What happened</th></tr>
<tr><td></td><td style="color:var(--g700)">Clean</td><td style="font-family:var(--fs);text-align:left">no bad shot, par or better</td></tr>
<tr><td></td><td style="color:var(--g700)">Comeback</td><td style="font-family:var(--fs);text-align:left">a bad shot, still par or better</td></tr>
<tr><td></td><td style="color:var(--bogT)">Bogey saved</td><td style="font-family:var(--fs);text-align:left">a bad shot, bogey</td></tr>
<tr><td></td><td style="color:var(--red6)">Lost</td><td style="font-family:var(--fs);text-align:left">a bad shot, double or worse</td></tr>
<tr><td></td><td style="color:var(--ink5)">Quiet bogey</td><td style="font-family:var(--fs);text-align:left">no listed bad shot, still over par</td></tr></table>
<div style="background:var(--g950);border-radius:12px;padding:12px 14px;margin-top:14px;"><div class="kick" style="color:var(--lime4);font-size:9px;margin-bottom:6px;">Clutch Rating, per 18 holes</div><div class="mono" style="font-size:19px;color:#fff;font-weight:700;">Clean + ¾ × Comebacks − Lost</div><p class="bdw" style="font-size:12px;margin-top:6px;">Tour average 14.8. Best on the board 15.6. Higher is better. A clean hole counts more than a rescue: it rewards the less stressful hole (RC, 18 Nov).</p></div></div></div>''',
'A hole with several bad shots is one test. "Recovery lie" = native area, trees, dirt, rock, cart path, other, water; rough is in play. A miss from 6 ft for birdie that still makes par is a comeback.'))
# 4 average round
S.append(paper(4,'A Tour Round','— What 18 holes look like on tour','Thirteen clean holes,<br>four tests a round.','Per 18 holes · all 1,906 rounds',
'<div style="display:flex;gap:14px;flex:1;min-height:0;"><div class="card sp" style="flex:1.1;"><div class="kick" style="color:var(--g700);font-size:9px;margin-bottom:12px;">Where the 18 holes go</div>'+
bar('Clean','13.1',13.11/18*100*1.25 if False else 72.8,'var(--g500)','var(--g700)')+bar('Comeback','2.6',14.3,'var(--g400)','var(--g700)')+bar('Bogey saved','1.4',8.0,'var(--bog)','var(--bogT)')+bar('Quiet bogey','0.7',3.8,'var(--sand)','var(--ink7)')+bar('Lost (double+)','0.2',1.1,'var(--red)','var(--red6)')+
'<p class="bd" style="font-size:12.5px;margin-top:10px;">Four tests a round (4.2). Six in ten end in par or better. The tests, not the comebacks, decide the round.</p></div><div class="card sp" style="flex:1;"><div class="kick" style="color:var(--g700);font-size:9px;margin-bottom:12px;">Bad shots per round, by type</div>'+
bar('Approach 160 in, off the green','1.99',100,'var(--bog)')+bar('Tee shot out of play','1.52',76,'var(--bog)')+bar('Miss from 6 ft and in','0.74',37,'var(--bog)')+bar('Three-putt','0.51',26,'var(--bog)')+bar('Short game off the green','0.49',25,'var(--bog)')+
'<p class="bd" style="font-size:12.5px;margin-top:10px;">Two of every three bad shots are a tee shot or a scoring-zone approach. That is where the tests come from.</p></div></div>',
'Bars on the left are share of 18 holes. Bad shots counted individually on the right; a hole can hold more than one (1,738 of 8,024 tested holes had two or three).'))
# 5 what predicts
S.append(paper(5,'What Predicts','— Which number tracks the score','Avoiding the test beats<br>winning it.','Correlation with score vs the field, per round',
'<div style="display:flex;gap:14px;flex:1;min-height:0;"><div class="card sp" style="flex:1.15;"><div class="kick" style="color:var(--g700);font-size:9px;margin-bottom:12px;">Higher bar = tracks a lower score more closely</div>'+
bar('Clutch Rating (clean + ¾ comebacks − lost)','0.71',100,'var(--g600)','var(--g700)')+bar('Holes kept (par or better)','0.69',97,'var(--g500)')+bar('Clean holes','0.50',70,'var(--g500)')+bar('Tests (fewer is better)','0.41',57,'var(--g400)')+bar('Comeback rate','0.40',56,'var(--g400)')+bar('Comebacks (count)','0.00',0.5,'var(--red)','var(--red6)')+
'''</div><div class="card sp" style="flex:1;"><div class="kick" style="color:var(--g700);font-size:9px;margin-bottom:10px;">The comeback rate barely moves</div><table class="tb"><tr><th>Tests</th><th>Rounds</th><th>vs field</th><th>Comeback</th></tr>
<tr><td>0</td><td>22</td><td>−2.02</td><td>—</td></tr><tr><td>1</td><td>80</td><td>−1.75</td><td>62%</td></tr><tr><td>2</td><td>236</td><td>−1.01</td><td>61%</td></tr><tr><td>3</td><td>399</td><td>−0.69</td><td>61%</td></tr><tr><td>4</td><td>385</td><td>−0.28</td><td>62%</td></tr><tr><td>5</td><td>340</td><td>+0.22</td><td>63%</td></tr><tr><td>6</td><td>234</td><td>+1.08</td><td>59%</td></tr><tr><td>7+</td><td>210</td><td>+2.3</td><td>60%</td></tr></table>
<p class="bd" style="font-size:12px;margin-top:9px;">Every extra test costs <b>0.57 strokes</b> against the field. Players win about 6 in 10 whatever the count.</p></div></div>''',
'Weights tested: clean + w × comebacks − v × lost for w 0 to 1.25, v 0 to 2. Best fit: w = 1, v = 1 (0.718). RC chose to count a clean hole higher: w = 0.75 (0.713), nearly the same fit; w = 0.5 gives 0.674. 7+ row pools 210 rounds.'))
# 6 by type
S.append(paper(6,'By Bad Shot','— Which bad shots players come back from','Off the tee and from the<br>fairway: seven in ten.','Hole result after the first bad shot',
'<div class="card sp" style="flex:1;min-height:0;"><table class="tb" style="font-size:13px;"><tr><th></th><th>First bad shot on the hole</th><th>Holes</th><th>Comeback</th><th>Bogey saved</th><th>Lost</th></tr>'+
''.join(f'<tr><td></td><td>{a}</td><td>{b}</td><td style="color:var(--g700);font-weight:700">{c}</td><td style="color:var(--bogT)">{d}</td><td style="color:var(--red6)">{x}</td></tr>' for a,b,c,d,x in [('Approach 160 in, off the green','3,069','70%','27%','3%'),('Tee shot out of play','2,889','68%','25%','6%'),('Chip, pitch or bunker shot off the green','620','43%','46%','12%'),('Miss from 6 ft and in','1,066','40%','56%','3%'),('Three-putt','380','19%','78%','3%')])+
'''</table><div style="display:flex;gap:14px;margin-top:16px;"><div class="bl" style="flex:1;"><b>The long game is forgiving.</b> <span class="bd">A missed green or a bad drive still ends in par seven times in ten: the short game behind it does the work.</span></div><div class="bl" style="flex:1;"><b>The short game is not.</b> <span class="bd">A chip off the green loses the hole (double) 12% of the time, four times the rate of a missed approach. The green is the minimum for a reason.</span></div><div class="bl" style="flex:1;"><b>Putting misses are final.</b> <span class="bd">A miss inside 6 ft or a three-putt is usually the stroke itself; a comeback there is mostly a missed birdie putt that still made par.</span></div></div></div>''',
'Counted on the first bad shot of each tested hole (8,024 holes).'))
# 7 winners vs field
S.append(paper(7,'Winners','— The week’s winner against the rest','Winners don’t come back<br>more. They need to less.','Four counted rounds each',
'''<div style="display:flex;gap:14px;flex:1;min-height:0;"><div class="card sp" style="flex:1;"><table class="tb"><tr><th></th><th>Per 18 holes</th><th>Winners</th><th>Top 10</th><th>11th +</th></tr>
<tr><td></td><td>Clutch Rating</td><td style="color:var(--g700);font-weight:700">15.9</td><td>15.6</td><td>14.7</td></tr>
<tr><td></td><td>Clean holes</td><td style="color:var(--g700);font-weight:700">14.4</td><td>13.9</td><td>13.0</td></tr>
<tr><td></td><td>Tests</td><td style="color:var(--g700);font-weight:700">3.3</td><td>3.6</td><td>4.3</td></tr>
<tr><td></td><td>Comeback rate</td><td>59%</td><td>66%</td><td>59%</td></tr>
<tr><td></td><td>Lost holes</td><td style="color:var(--g700);font-weight:700">0.04</td><td>0.09</td><td>0.23</td></tr></table>
<p class="bd" style="font-size:12.5px;margin-top:12px;">The winners' edge is <b>one fewer test a round</b> and almost no lost holes. Their comeback rate is the field's. The top 10 come back more often (66%), but still face more tests than the winner.</p></div>
<div class="card sp" style="flex:1;"><div class="kick" style="color:var(--g700);font-size:9px;margin-bottom:8px;">The six winners · rank in their own field</div><table class="tb"><tr><th></th><th>Winner</th><th>Rating</th><th>Rank</th><th>Tests</th><th>Comeback</th></tr>'''+
''.join(f'<tr><td></td><td>{a}</td><td>{b}</td><td>{c}</td><td>{d}</td><td>{x}</td></tr>' for a,b,c,d,x in [('Nico Echavarria · Cognizant','16.50','1st','3.75','80%'),('Collin Morikawa · Pebble','16.31','2nd','2.75','64%'),('Chris Gotterup · Sony','15.94','6th','3.50','64%'),('Jacob Bridgeman · Genesis','15.50','8th','2.50','40%'),('Blades Brown · Los Cabos','16.12','11th','2.00','25%'),('Chris Gotterup · Phoenix','15.25','13th','5.00','80%')])+
'''</table><p class="bd" style="font-size:12px;margin-top:10px;">Three of six in their week's top 6, all six in the top 13. Bridgeman and Brown had the second-fewest tests in their fields and won on birdies, which the rating does not count above par.</p></div></div>''',
'American Express and Farmers winners not counted: those weeks lack shot detail on one course. Cognizant field is the 31 players we pulled. Rank ties share the better place.'))
# 8 leaderboard
B=F['board']
rows=''.join(f'<tr><td>{i}</td><td>{e(x["name"])}</td><td style="color:#fff;font-weight:700">{x["rating"]:.2f}</td><td>{x["clean"]:.1f}</td><td>{x["CB"]}/{x["T"]}</td><td>{x["cbr"]*100:.0f}%</td><td>{x["lost"]:.2f}</td><td>{x["rounds"]}</td></tr>' for i,x in enumerate(B[:12],1))
S.append(dark(8,'Leaderboard','— Clutch Rating leaders · 16 rounds or more','Matsuyama keeps the most<br>holes, and loses none.','32 players qualify',
f'<table class="tb tbw" style="font-size:12.5px;"><tr><th>#</th><th>Player</th><th>Rating</th><th>Clean</th><th>Comebacks</th><th>Rate</th><th>Lost</th><th>Rounds</th></tr>{rows}</table>',
'Per 18 holes; Clutch Rating = clean + ¾ comebacks − lost. Tour average rating 14.8 (clean 13.1, comeback rate 61%, lost 0.20). Two routes to the top: Matsuyama and Knapp with the best comeback rates (75%), Bridgeman and Gerard with the most clean holes (14.0, 13.9).'))
# 9 two kinds
C=F['comeback']
cr=''.join(f'<tr><td>{i}</td><td>{e(x["name"])}</td><td>{x["CB"]}/{x["T"]}</td><td style="font-weight:700">{x["cbr"]*100:.0f}%</td></tr>' for i,x in enumerate(C[:8],1))
cl=sorted(B,key=lambda x:x['tests'])[:8]
clr=''.join(f'<tr><td>{i}</td><td>{e(x["name"])}</td><td style="font-weight:700">{x["tests"]:.2f}</td><td>{x["clean"]:.1f}</td></tr>' for i,x in enumerate(cl,1))
S.append(paper(9,'Two Kinds','— Two ways to keep a hole','The comeback artists<br>and the clean players.','Same rating, different coaching',
f'''<div style="display:flex;gap:14px;flex:1;min-height:0;"><div class="card sp" style="flex:1;"><div class="kick" style="color:var(--g700);font-size:9px;margin-bottom:8px;">Comeback artists · rate, 50 tests or more</div><table class="tb"><tr><th>#</th><th>Player</th><th>Comebacks</th><th>Rate</th></tr>{cr}</table><p class="bd" style="font-size:12px;margin-top:9px;">Tour average 61%. These players turn three bad shots in four into par.</p></div>
<div class="card sp" style="flex:1;"><div class="kick" style="color:var(--g700);font-size:9px;margin-bottom:8px;">Clean players · fewest tests, 16 rounds or more</div><table class="tb"><tr><th>#</th><th>Player</th><th>Tests</th><th>Clean</th></tr>{clr}</table><p class="bd" style="font-size:12px;margin-top:9px;">Tour average 4.2 tests. These players are rarely asked to come back at all: the stress-free game.</p></div></div>''',
'Comeback board: every player with 50 tested holes or more (75 players). Clean board: the 32 players with 16 rounds or more, per 18 holes.'))
# 10 philosophy
S.append(dark(10,'Our Philosophy','— What it means for the house rules','Raise the floor by<br>removing the test.','How it fits',
'''<div style="display:flex;gap:14px;flex:1;min-height:0;">
<div class="blw" style="flex:1;"><div class="kick" style="color:var(--lime4);font-size:9px;margin-bottom:9px;">1 · It proves the rules</div><p class="bdw" style="font-size:13px;">Every bad shot is a broken house rule, and every one costs about half a stroke. Rounds are decided by how many rules break, not by heroics after. That is "decide before the tee, not after the miss" in one number.</p></div>
<div class="blw" style="flex:1;"><div class="kick" style="color:var(--lime4);font-size:9px;margin-bottom:9px;">2 · It sorts the coaching</div><p class="bdw" style="font-size:13px;">Low clean, high comeback rate: a scrambler. Work on the tee shot and the scoring-zone approach. High clean, low comeback rate: a front-runner. Work on the short game and the reset.</p></div>
<div class="blw" style="flex:1;"><div class="kick" style="color:var(--lime4);font-size:9px;margin-bottom:9px;">3 · It is the Clutch Factor umbrella</div><p class="bdw" style="font-size:13px;">Ball Striking and Damage Control count the comebacks and saved bogeys; Dominance is a round with almost no tests; Response is the reset after. Clutch Rating puts them on one line a player can read.</p></div></div>
<div class="blw" style="margin-top:14px;background:color-mix(in oklch,var(--lime) 12%,transparent);border-color:var(--lime6);"><div class="kick" style="color:var(--lime);font-size:9px;margin-bottom:6px;">How it could print on a Raw sheet</div><p class="mono" style="font-size:15px;color:#fff;">Clutch Rating 15.5 · 14 clean · 2 comebacks from 3 tests · 0 lost</p></div>''',
'The Raw sheet line is a mock-up for discussion, not built.'))

# 10b difficulty
S.append(paper(11,'Difficulty','— Comebacks graded by how hard they were','Some tests are a 10% par.<br>Some are 81%.','Index 100 = tour average',
'''<div style="display:flex;gap:14px;flex:1;min-height:0;"><div class="card sp" style="flex:1;"><div class="kick" style="color:var(--g700);font-size:9px;margin-bottom:8px;">How often the tour makes par from the spot after the bad shot</div><table class="tb"><tr><th></th><th>After the bad shot</th><th>Tests</th><th>Par or better</th></tr>
<tr><td></td><td>Penalty off the tee, 2 shots left for par</td><td>247</td><td style="color:var(--red6);font-weight:700">15%</td></tr>
<tr><td></td><td>Chip off the green into the fairway, 1 left</td><td>134</td><td style="color:var(--red6);font-weight:700">10%</td></tr>
<tr><td></td><td>Tee shot in a recovery lie, 3 left</td><td>714</td><td>71%</td></tr>
<tr><td></td><td>Tee shot in a bunker, 3 left</td><td>1,825</td><td>77%</td></tr>
<tr><td></td><td>Approach short of the green on the fairway, 2 left</td><td>1,582</td><td style="color:var(--g700);font-weight:700">81%</td></tr></table>
<p class="bd" style="font-size:12px;margin-top:10px;">Each comeback is scored against the tour's own rate from that lie, distance and shots left. A missed short putt is decided on the spot (a missed par putt can't become a comeback), so the index lives in the long game and the short game.</p></div>
<div class="card sp" style="flex:1;"><div class="kick" style="color:var(--g700);font-size:9px;margin-bottom:8px;">Comeback Index leaders · 50 tests or more</div><table class="tb"><tr><th>#</th><th>Player</th><th>Comebacks</th><th>Expected</th><th>Index</th></tr>'''+'<tr><td>1</td><td>Kevin Roy</td><td>40/53</td><td>62%</td><td style="font-weight:700;color:var(--g700)">122</td></tr><tr><td>2</td><td>Hideki Matsuyama</td><td>66/88</td><td>65%</td><td style="font-weight:700;color:var(--g700)">115</td></tr><tr><td>3</td><td>Jake Knapp</td><td>66/88</td><td>66%</td><td style="font-weight:700;color:var(--g700)">114</td></tr><tr><td>4</td><td>Sahith Theegala</td><td>66/93</td><td>62%</td><td style="font-weight:700;color:var(--g700)">115</td></tr><tr><td>5</td><td>Kristoffer Reitan</td><td>33/51</td><td>56%</td><td style="font-weight:700;color:var(--g700)">115</td></tr><tr><td>6</td><td>Robert MacIntyre</td><td>51/70</td><td>66%</td><td style="font-weight:700;color:var(--g700)">111</td></tr><tr><td>7</td><td>Jordan Spieth</td><td>40/54</td><td>67%</td><td style="font-weight:700;color:var(--g700)">111</td></tr><tr><td>8</td><td>Xander Schauffele</td><td>38/54</td><td>64%</td><td style="font-weight:700;color:var(--g700)">109</td></tr>'+'''</table><p class="bd" style="font-size:12px;margin-top:9px;">Reitan faced some of the hardest tests (56% expected) and still beat them by 15%.</p></div></div>''',
'8,024 tests; expected = the tour rate in 113 situations (bad-shot type × lie × distance band × shots left for par), small groups pulled toward their type average. Out of sample, a rating that splits comebacks into expected (¾) and above-expected (full credit) predicts later scoring 0.43–0.50, against 0.41–0.48 for the plain rating: a small gain on 28–40 players.'))
# 11 limits
S.append(paper(12,'Limits','— What this study can and cannot say','Strong on rounds.<br>Early on players.','Read before quoting a name',
'''<div style="display:flex;gap:14px;flex:1;min-height:0;">
<div class="card sp" style="flex:1;"><div class="kick" style="color:var(--g700);font-size:9px;margin-bottom:9px;">Solid</div><p class="bd" style="margin-bottom:9px;">The round-level findings: 1,906 rounds, every one graded hole by hole and scored against its own field. The rating's link to scoring (0.72), the flat comeback rate and the cost of a test hold across all eight events.</p><p class="bd">The definitions use house rules literally and are counted by code from the shot files, not read by eye.</p></div>
<div class="card sp" style="flex:1;background:color-mix(in oklch,var(--bog) 10%,#fff);border-color:var(--bog);"><div class="kick" style="color:var(--bogT);font-size:9px;margin-bottom:9px;">Early</div><p class="bd" style="margin-bottom:9px;">Player boards rest on 16 to 25 rounds each, from early-season events. Split-half checks (one set of events against the other) are low: fewest tests 0.30, clean holes 0.21, comeback rate 0.09. <b>A season of rounds is needed before a name is a fact.</b></p><p class="bd">American Express and Farmers are part-weeks (no shot detail on one course); Cognizant is the 31 players pulled.</p></div>
<div class="card sp" style="flex:1;"><div class="kick" style="color:var(--g700);font-size:9px;margin-bottom:9px;">Not in the data</div><p class="bd" style="margin-bottom:9px;">The tour feed marks no fringe: a ball on the collar reads as green or rough by the feed's own label. No clubs, no pins, no hazard lines.</p><p class="bd">Carry by 15 and the dead zone are not part of the bad-shot list yet.</p></div></div>''',
'The 2026 season pull (every event, every made-cut round) is paused at 8 events; finishing it is about 11,000 Parse.bot credits.'))
# 12 questions
S.append(dark(13,'Questions','— For RC','Four decisions.','Before it is named',
'''<div style="display:flex;flex-direction:column;gap:10px;flex:1;min-height:0;">'''+''.join(f'<div class="blw" style="display:flex;gap:16px;align-items:flex-start;"><span class="big mono" style="font-size:26px;color:var(--lime);width:32px;">{i}</span><div><div class="dsp" style="font-size:16px;color:#fff;margin-bottom:4px;">{t}</div><p class="bdw" style="font-size:12.5px;">{p}</p></div></div>' for i,t,p in [
(1,'Comeback Index beside the rating?','Replace the raw comeback rate with the index (100 = tour average from the same spots). Optional: give comebacks above the odds full credit inside the rating (out of sample 0.43–0.50 vs 0.41–0.48).'),
(2,'The Clutch family under one name?','Clutch Rating, with Clean · Comeback · Putting · Damage Control · Response · Closing beneath it. Agreed in principle; ships as one house-rules rev once a full season confirms it.'),
(3,'Refresh it when the season pull resumes?','Also add missed-cut rounds: worst rounds matter most for raising the floor.'),
(4,'The name.','Clutch Rating for now. Options: Clutch Rating · Holes Kept · The Floor Rating · Clutch Factor Comeback.')])+'</div>'))
out=head+'<deck-stage width="1056" height="816" no-rail>\n'+'\n'.join(S)+'\n</deck-stage>\n</body>\n</html>\n'
open('/home/user/rc-greenlight/deliverables/Clutch Rating - Tour Study 2026.html','w').write(out)
print(len(out))
