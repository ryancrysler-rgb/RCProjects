import json,os,re,collections,statistics as S,math
exec(open('count.py').read().split("rows=[]")[0])  # reuse helpers: B, EV, REC, yd, surf
def band(lie,d):
    if d is None: return 'na'
    if lie=='Green':
        f=d*3
        for c in [3,6,10,20,40]:
            if f<=c: return 'g%d'%c
        return 'g40+'
    for c in [10,20,30,50,100,150,200]:
        if d<=c: return 'y%d'%c
    return 'y200+'
def lieclass(t):
    if t in ('Green',): return 'Green'
    if 'Bunker' in t: return 'Bunker'
    if t in ('Fairway',): return 'Fairway'
    if t in ('Rough','Intermediate','Primary Rough','Intermediate Rough'): return 'Rough'
    if t in ('Water',): return 'Penalty'
    return 'Recovery'
T=[]
for e in EV:
    lb={p['id']:p for p in json.load(open(B+e+'/leaderboard.json'))['data']['players']}
    for f in sorted(os.listdir(B+e+'/raw')):
        pid,rnd=f[:-5].split('-'); d=json.load(open(B+e+'/raw/'+f))['data']; holes=d['holes']
        if len(holes)!=18 or any(s['strokeType']=='STROKE' and not s.get('finalStroke') and not s.get('toLocation') for h in holes for s in h['strokes']): continue
        for h in holes:
            par=int(h['par']); score=int(h['score']); hy=float(h['yardage'])
            st=[s for s in h['strokes'] if s['strokeType']!='DROP']
            prev=hy; putts=0; first=None; used=0
            for i,s in enumerate(st):
                if s['strokeType']=='PENALTY': used+=1; continue
                used+=1
                n=int(s['strokeNumber']); frm=surf(s.get('fromLocation')); to=surf(s.get('toLocation'))
                start=hy if (frm=='Tee Box' and n==1) else prev
                rem=yd(s.get('distanceRemaining')); holed=bool(s.get('finalStroke'))
                nxt=st[i+1] if i+1<len(st) else None; pen=nxt is not None and nxt['strokeType']=='PENALTY'
                badtype=None
                if frm=='Green':
                    putts+=1
                    if start is not None and start*3<=6.0 and not holed: badtype='short putt'
                    if putts==2 and not holed and badtype is None:
                        badtype=None  # three-putt known only later
                elif frm=='Tee Box' and par>=4:
                    nl=next((surf(x.get('fromLocation')) for x in st[i+1:] if x['strokeType']=='STROKE'),None)
                    if pen or to in REC or nl in REC: badtype='tee'
                elif start is not None and start<=160 and not holed and to!='Green':
                    badtype='approach' if start>50 else 'short game'
                if badtype and first is None:
                    lie='Penalty' if pen else lieclass(to)
                    first=dict(type=badtype,lie=lie,band=band('Green' if lie=='Green' else lie,rem),left=par-used-(1 if pen else 0))
                if rem is not None: prev=rem
            if first is None and putts>=3:
                first=dict(type='three-putt',lie='Green',band='g3',left=-1)
            if first:
                p=lb.get(pid,{}); T.append(dict(ev=e,pid=pid,name=p.get('displayName',pid),rnd=rnd,rel=score-par,cb=int(score<=par),**first))
json.dump(T,open('tests.json','w')); print('tests',len(T))
# expected by bucket (left clipped)
def key(t): return (t['type'],t['lie'],t['band'],max(-1,min(t['left'],3)))
G=collections.defaultdict(list)
for t in T: G[key(t)].append(t['cb'])
# shrink small buckets toward the type-level mean
TY=collections.defaultdict(list)
for t in T: TY[(t['type'],max(-1,min(t['left'],3)))].append(t['cb'])
for t in T:
    g=G[key(t)]; ty=TY[(t['type'],max(-1,min(t['left'],3)))]; k=20
    t['x']=(sum(g)+k*S.mean(ty))/(len(g)+k)
print('buckets',len(G),'mean expected',round(S.mean(t['x'] for t in T),3),'actual',round(S.mean(t['cb'] for t in T),3))
json.dump(T,open('tests.json','w'))
