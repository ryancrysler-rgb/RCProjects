import csv,collections,statistics as S,math,json
F='/tmp/claude-0/-home-user/c0cfce94-7d29-53ae-a568-1ec015f2a64a/scratchpad/fieldrb/SHOT_BY_SHOT_abu-dhabi-field-70-players.csv'
R=[r for r in csv.DictReader(open(F)) if not (r['isProvisional']=='True' and r['isProvisionalSelected']!='True') and r['eventType']!='BallDrop']
REL={'Albatross':-3,'Eagle':-2,'EagleOrBetter':-2,'Birdie':-1,'Par':0,'Bogey':1,'DoubleBogey':2,'DoubleBogeyOrWorse':2,'TripleBogey':3}
H=collections.defaultdict(list)
for r in R: H[(r['player'],r['round'],int(r['hole']))].append(r)
# strokes per hole = rows that are strokes (DetailedLie/BallHoled) + penalties
pars=collections.defaultdict(collections.Counter); recs={}
for k,rows in H.items():
    rows.sort(key=lambda r:(int(r['shot']) if r['shot'] else 0))
    st=sum(1 for r in rows if r['eventType'] in('DetailedLie','BallHoled','Penalty'))
    hs=[r['holeScore'] for r in rows if r['holeScore']]
    if hs and hs[-1] in REL and 'OrWorse' not in hs[-1] and 'OrBetter' not in hs[-1]: pars[k[2]][st-REL[hs[-1]]]+=1
    recs[k]=(rows,st)
PAR={h:c.most_common(1)[0][0] for h,c in pars.items()}
OFF={'Fairway Bunker','Greenside Bunker','Native Area','Water','Other','Unknown','Trees','Path'}
out=[]
for (pl,rd,h),(rows,st) in recs.items():
    par=PAR[h]; rel=st-par; bad=[]; prev=None; putts=0; lastlie=''
    strokes=[r for r in rows if r['eventType'] in('DetailedLie','BallHoled')]
    for i,r in enumerate(rows):
        if r['eventType']=='Penalty': continue
        lb=r['lieBeforeShot'] or ('Tee' if r is strokes[0] else lastlie)
        d_after=float(r['distanceToPin_yds']) if r['distanceToPin_yds'] else None
        if r is strokes[0]:
            start=(float(r['shotDistance_yds'] or 0)+(d_after or 0)) if r['shotDistance_yds'] else None; lb='Tee'
        else: start=prev
        holed=r['ballHoled']=='True'
        nxt=rows[i+1] if i+1<len(rows) else None
        pen=nxt is not None and nxt['eventType']=='Penalty'
        la=r['lieAfterShot']
        if lb=='Green':
            putts+=1
            if start is not None and start*3<=6.0 and not holed: bad.append('short putt')
        elif lb=='Tee' and par>=4:
            if pen or la in OFF: bad.append('tee out of play')
        else:
            if start is not None and start<=160 and not holed and la!='Green':
                bad.append('approach' if start>50 else 'short game')
        if d_after is not None: prev=d_after
        if la: lastlie=la
    if putts>=3: bad.append('three-putt')
    cls=('clean' if rel<=0 else 'quiet') if not bad else ('comeback' if rel<=0 else ('bogey saved' if rel==1 else 'lost'))
    out.append(dict(pl=pl,rd=rd,h=h,rel=rel,bad=bad,cls=cls))
print('holes',len(out),'rounds',len(set((o['pl'],o['rd']) for o in out)),'pars',sum(PAR.values()))
n=len(out); c=collections.Counter(o['cls'] for o in out); print({k:round(v/n*18,2) for k,v in c.items()})
b=collections.Counter(x for o in out for x in o['bad']); print({k:round(v/n*18,2) for k,v in b.items()})
RD=collections.defaultdict(list)
for o in out: RD[(o['pl'],o['rd'])].append(o)
rds=[]
for (pl,rd),hs in RD.items():
    if len(hs)!=18: continue
    cc=collections.Counter(h['cls'] for h in hs); t=cc['comeback']+cc['bogey saved']+cc['lost']
    rds.append(dict(pl=pl,rd=rd,clean=cc['clean'],cb=cc['comeback'],lost=cc['lost'],bs=cc['bogey saved'],tests=t,rel=sum(h['rel'] for h in hs)))
fm=collections.defaultdict(list)
for a in rds: fm[a['rd']].append(a['rel'])
for a in rds: a['vs']=a['rel']-S.mean(fm[a['rd']])
def corr(x,y):
    mx,my=S.mean(x),S.mean(y); sx=math.sqrt(sum((a-mx)**2 for a in x)); sy=math.sqrt(sum((b-my)**2 for b in y)); return sum((a-mx)*(b-my) for a,b in zip(x,y))/(sx*sy)
vs=[a['vs'] for a in rds]
for nm,f in [('rating 3/4',lambda a:a['clean']+.75*a['cb']-a['lost']),('rating 1.0',lambda a:a['clean']+a['cb']-a['lost']),('kept',lambda a:a['clean']+a['cb']),('clean',lambda a:a['clean']),('tests',lambda a:a['tests']),('comebacks count',lambda a:a['cb'])]:
    print(nm,round(corr([f(a) for a in rds],vs),3))
x=[(a['cb']/a['tests'],a['vs']) for a in rds if a['tests']]; print('comeback rate',round(corr([p for p,_ in x],[q for _,q in x]),3))
xs=[a['tests'] for a in rds]; mx=S.mean(xs); my=S.mean(vs); print('slope per test',round(sum((p-mx)*(q-my) for p,q in zip(xs,vs))/sum((p-mx)**2 for p in xs),3))
B=collections.defaultdict(list)
for a in rds: B[min(a['tests'],7)].append(a)
for t in sorted(B): print(' tests',t,len(B[t]),round(S.mean(a['vs'] for a in B[t]),2),round(S.mean(a['cb']/a['tests'] for a in B[t]),2) if t else '-')
tot=collections.Counter()
for a in rds:
    for k in ['clean','cb','lost','bs','tests']: tot[k]+=a[k]
print('field rating', round((tot['clean']+.75*tot['cb']-tot['lost'])/len(rds),2),'cb rate',round(tot['cb']/tot['tests'],3),'tests/rd',round(tot['tests']/len(rds),2))
P=collections.defaultdict(list)
for a in rds: P[a['pl']].append(a)
pl=[]
for p,l in P.items():
    if len(l)<4: continue
    t=sum(a['tests'] for a in l); r=sum(a['clean']+.75*a['cb']-a['lost'] for a in l)/len(l); tot_rel=sum(a['rel'] for a in l)
    pl.append((r,p,sum(a['clean'] for a in l)/len(l),t/len(l),sum(a['cb'] for a in l),t,sum(a['lost'] for a in l)/len(l),tot_rel))
pl.sort(reverse=True)
win=min(pl,key=lambda x:x[7]); print('lowest total',win[1],win[7],'rating',round(win[0],2),'rank',1+sum(1 for x in pl if x[0]>win[0]),'of',len(pl))
for i,x in enumerate(pl[:8],1): print(i,x[1],round(x[0],2),'clean',round(x[2],2),'tests',round(x[3],2),'cb %d/%d'%(x[4],x[5]),'lost',round(x[6],2),'to par',x[7])
top10=[x for x in sorted(pl,key=lambda x:x[7])[:10]]; rest=sorted(pl,key=lambda x:x[7])[10:]
for nm,G in [('top10 by score',top10),('rest',rest)]: print(nm,round(S.mean(x[0] for x in G),2),'tests',round(S.mean(x[3] for x in G),2),'clean',round(S.mean(x[2] for x in G),2),'cbrate',round(sum(x[4] for x in G)/sum(x[5] for x in G),3),'lost',round(S.mean(x[6] for x in G),2))
T=collections.defaultdict(collections.Counter)
for o in out:
    if o['bad']: T[o['bad'][0]][o['cls']]+=1
for t,c in T.items():
    m=sum(c.values()); print(t,m,round(100*c['comeback']/m),round(100*c['bogey saved']/m),round(100*c['lost']/m))
json.dump(dict(pl=pl,rds=rds),open('dpw.json','w'))
