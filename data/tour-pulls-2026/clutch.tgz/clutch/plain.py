import json,collections,statistics as S,math
rd=json.load(open('rounds.json')); T=json.load(open('tests.json'))
X=collections.defaultdict(float); A=collections.Counter()
for t in T: k=(t['ev'],t['pid'],t['rnd']); X[k]+=t['x']; A[k]+=t['cb']
for a in rd: k=(a['ev'],a['pid'],a['rnd']); a['x']=X[k]
def qgap(vals,vs):
    z=sorted(zip(vals,vs)); n=len(z)//4
    lo=S.mean(v for _,v in z[:n]); hi=S.mean(v for _,v in z[-n:]); return hi,lo
P={}
vs=[a['vs'] for a in rd]
M={'rating34':lambda a:a['clean']+.75*a['x']+(a['cb']-a['x'])-a['lost'],'rating_simple34':lambda a:a['clean']+.75*a['cb']-a['lost'],'w1':lambda a:a['clean']+a['cb']-a['lost'],'w125':lambda a:a['clean']+1.25*a['cb']-a['lost'],'w15':lambda a:a['clean']+1.5*a['cb']-a['lost'],
   'cbcount':lambda a:a['cb'],'clean':lambda a:a['clean'],'tests':lambda a:-a['tests']}
for k,f in M.items():
    hi,lo=qgap([f(a) for a in rd],vs); P[k]=(round(hi,2),round(lo,2)); print(k,'top quarter vs field',round(hi,2),'bottom quarter',round(lo,2),'gap',round(lo-hi,2))
# rounds with more tests: avg vs field by tests count in plain
# out of sample: top half vs bottom half
order=['R2026006','R2026002','R2026004','R2026003','R2026005','R2026007','R2026010','R2026457']; first=set(order[:4])
H=collections.defaultdict(lambda:[[],[]])
for a in rd: H[a['pid']][0 if a['ev'] in first else 1].append(a)
Q=[h for h in H.values() if len(h[0])>=6 and len(h[1])>=6]
def oos(f):
    xs=[(S.mean(f(a) for a in h[0]),S.mean(a['vs'] for a in h[1])) for h in Q]; xs.sort(key=lambda t:-t[0]); n=len(xs)//2
    return round(S.mean(v for _,v in xs[:n]),2),round(S.mean(v for _,v in xs[n:]),2)
print('OOS players',len(Q),'clutch rating',oos(M['rating34']),'own scoring',oos(lambda a:-a['vs']))
json.dump(dict(q=P,oos_cr=oos(M['rating34']),oos_score=oos(lambda a:-a['vs']),n=len(Q)),open('plain.json','w'))
# Abu Dhabi
d=json.load(open('dpw.json'))['rds']
hi,lo=qgap([a['clean']+.75*a['cb']-a['lost'] for a in d],[a['vs'] for a in d]); print('AbuDhabi rating',hi,lo)
hi,lo=qgap([a['cb'] for a in d],[a['vs'] for a in d]); print('AbuDhabi cbcount',hi,lo)
