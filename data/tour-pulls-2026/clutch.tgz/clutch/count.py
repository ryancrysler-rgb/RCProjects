import json,os,re,collections,sys
B='/tmp/claude-0/-home-user/c0cfce94-7d29-53ae-a568-1ec015f2a64a/scratchpad/season-pga/'
EV={'R2026006':'Sony Open','R2026002':'American Express','R2026004':'Farmers Insurance','R2026003':'WM Phoenix Open','R2026005':'AT&T Pebble Beach','R2026007':'Genesis Invitational','R2026010':'Cognizant Classic','R2026457':'World Wide Technology'}
REC={'Bunker','Native Area','Tree Outline','Dirt Outline','Rock Outline','Cart Path','Path','Bush','Wall','Water','Other','Fairway Bunker','Greenside Bunker'}
def yd(s):
    s=(s or '').strip()
    if not s: return None
    m=re.match(r'^([\d,.]+) yds?$',s)
    if m: return float(m.group(1).replace(',',''))
    ft=re.search(r'([\d.]+) ft',s); inch=re.search(r'([\d.]+) in',s)
    if ft or inch: return ((float(ft.group(1)) if ft else 0)+(float(inch.group(1)) if inch else 0)/12)/3
    return None
def surf(n): return (n or '').replace('Left ','').replace('Right ','')
rows=[]; skipped=collections.Counter(); kept_r=collections.Counter()
for e in EV:
    lb={p['id']:p for p in json.load(open(B+e+'/leaderboard.json'))['data']['players']}
    for f in sorted(os.listdir(B+e+'/raw')):
        pid,rnd=f[:-5].split('-'); d=json.load(open(B+e+'/raw/'+f))['data']
        holes=d['holes']; ok=True
        for h in holes:
            for s in h['strokes']:
                if s['strokeType']=='STROKE' and not s.get('finalStroke') and not s.get('toLocation'): ok=False
        if not ok or len(holes)!=18: skipped[e]+=1; continue
        kept_r[e]+=1
        for h in holes:
            par=int(h['par']); score=int(h['score']); hy=float(h['yardage'])
            st=[s for s in h['strokes'] if s['strokeType']!='DROP']
            bad=[]; prev=hy; putts=0
            strokes=[s for s in st if s['strokeType']=='STROKE']
            for i,s in enumerate(st):
                if s['strokeType']=='PENALTY':
                    continue
                n=int(s['strokeNumber']); frm=surf(s.get('fromLocation')); to=surf(s.get('toLocation'))
                start = hy if (frm=='Tee Box' and n==1) else prev
                rem=yd(s.get('distanceRemaining')); holed=bool(s.get('finalStroke'))
                nxt=st[i+1] if i+1<len(st) else None
                pen_after = nxt is not None and nxt['strokeType']=='PENALTY'
                if frm=='Green':
                    putts+=1
                    if start is not None and start*3<=6.0 and not holed: bad.append('short putt')
                else:
                    if frm=='Tee Box' and par>=4:
                        # next played lie
                        nl=None
                        for x in st[i+1:]:
                            if x['strokeType']=='STROKE': nl=surf(x.get('fromLocation')); break
                        if pen_after or to in REC or (nl in REC): bad.append('tee out of play')
                    else:
                        if start is not None and start<=160 and not holed and to!='Green':
                            bad.append('approach 160 in off green' if start>50 else 'short game off green')
                if rem is not None: prev=rem
            if putts>=3: bad.append('three-putt')
            rel=score-par
            if not bad: cls='clean' if rel<=0 else ('quiet bogey' if rel==1 else 'quiet double')
            else: cls='comeback' if rel<=0 else ('bogey saved' if rel==1 else 'lost')
            p=lb.get(pid,{})
            rows.append(dict(ev=e,pid=pid,name=p.get('displayName',pid),pos=p.get('position'),rnd=rnd,hole=h['holeNumber'],par=par,rel=rel,bad='|'.join(bad),cls=cls))
print('rounds kept',dict(kept_r),'skipped',dict(skipped),file=sys.stderr)
json.dump(rows,open('holes.json','w'))
c=collections.Counter(r['cls'] for r in rows); n=len(rows); print(n,{k:round(v/n*18,2) for k,v in c.items()})
b=collections.Counter(x for r in rows for x in r['bad'].split('|') if x); print({k:round(v/n*18,2) for k,v in b.items()})
