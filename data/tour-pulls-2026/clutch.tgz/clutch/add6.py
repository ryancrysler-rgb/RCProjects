p='build5.py';s=open(p).read()
add=open('add6_block.txt').read()
anchor="# 13 decisions"
assert anchor in s and 'Shot Success Rate' not in s.split(anchor)[1]
s=s.replace(anchor,add+anchor).replace("S.append(paper(13,'Decisions'","S.append(paper(19,'Decisions'").replace("<p class=\"bd\">· Which of the six new ideas to study first.</p>","<p class=\"bd\">· Which of the six new ideas join the family.</p>")
open(p,'w').write(s)
