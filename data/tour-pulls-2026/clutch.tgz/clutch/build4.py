import json,html
F=json.load(open('final.json')); e=html.escape
WCB=0.75
import collections as _C
_rd=json.load(open('rounds.json')); _SP=_C.defaultdict(list)
for _a in _rd: _SP[_a['pid']].append(_a)
_nm={x['name']:x for x in F['board']}
for x in F['board']: x['rating']=x['clean']+WCB*x['cb']-x['lost']
F['board'].sort(key=lambda x:-x['rating'])
head=open('../head.html').read().replace('Kiril Engeli Poretti · State of the Game','Clutch Rating · Tour Study')
css='''<style>
.tb{width:100%;border-collapse:collapse;font-size:12px}
.tb th{font-family:var(--fm);font-size:8.6px;letter-spacing:.1em;text-transform:uppercase;color:var(--ink5);font-weight:600;text-align:right;padding:0 6px 6px;border-bottom:1px solid var(--bs)}
.tb th:first-child,.tb th:nth-child(2){text-align:left}
.tb td{padding:5px 6px;border-bottom:1px solid var(--bs);text-align:right;font-family:var(--fm);font-variant-numeric:tabular-nums;color:var(--ink9)}
.tb td:first-child{text-align:left;color:var(--ink5);width:24px}.tb td:nth-child(2){text-align:left;font-family:var(--fs);font-weight:600}
.tb tr:last-child td{border-bottom:0}
.tbw th{color:var(--g300);border-color:var(--bi)}.tbw td{color:#fff;border-color:var(--bi)}.tbw td:first-child{color:var(--g300)}
.bar{display:flex;align-items:center;gap:10px;margin-bottom:7px}
.bar .l{width:230px;font-size:12.5px;color:var(--ink7)}
.bar .t{flex:1;height:18px;background:var(--paper2);border-radius:3px;overflow:hidden}
.bar .v{width:52px;text-align:right;font-family:var(--fm);font-weight:700;font-size:12.5px}
</style>'''
head=head.replace('</head>',css+'</head>')
lock='<div class="lock"><div><div class="wm"><span style="color:#fff;">RCGreen</span><span style="color:var(--g400);">light</span></div><div class="desc" style="color:var(--g300);">Every number ends with a choice</div></div></div>'
def paper(n,label,kick,title,right,body,fn):
    return f'''<section data-label="{label}" data-screen-label="{n:02d}" style="background:var(--paper);color:var(--ink9);"><div style="position:absolute;inset:0;padding:40px 52px 30px;display:flex;flex-direction:column;"><div class="hd"><div><div class="kick" style="color:var(--g700);margin-bottom:10px;">{kick}</div><h2 class="h2">{title}</h2></div><div class="kick" style="color:var(--ink5);text-align:right;">{right}</div></div>{body}<div class="fn" style="margin-top:auto;padding-top:10px;">{fn}</div></div></section>'''
def dark(n,label,kick,title,right,body,fn=''):
    return f'''<section data-label="{label}" data-screen-label="{n:02d}" style="background:var(--g950);color:#fff;"><div style="position:absolute;inset:0;padding:44px 56px 36px;display:flex;flex-direction:column;"><div class="hdd"><div><div class="kick" style="color:var(--lime4);margin-bottom:10px;">{kick}</div><h2 class="h2w">{title}</h2></div><div class="kick" style="color:var(--g300);text-align:right;">{right}</div></div>{body}<div class="fnw" style="margin-top:auto;padding-top:10px;">{fn}</div></div></section>'''
def bar(l,v,w,col,vcol=None):
    return f'<div class="bar"><span class="l">{l}</span><div class="t"><div style="width:{w}%;height:100%;background:{col};"></div></div><span class="v" style="color:{vcol or "var(--ink9)"};">{v}</span></div>'
D=json.load(open('four.json')); PL=D['pl']
def top(key,n=5): return sorted(PL,key=lambda p:-p[key])[:n]
def trow(cells,bold=2): return '<tr>'+''.join(f'<td{" style=\"font-weight:700\"" if i==bold else ""}>{c}</td>' for i,c in enumerate(cells))+'</tr>'
S=[]
S.append(f'''<section data-label="Cover" data-screen-label="01" style="background:var(--g950);color:#fff;display:flex;flex-direction:column;justify-content:space-between;">
<svg class="ctour" viewBox="0 0 1056 816" fill="none" aria-hidden="true" style="opacity:.12;"><ellipse cx="830" cy="180" rx="520" ry="330" stroke="#5BD891" stroke-width="1.2"/><ellipse cx="830" cy="180" rx="400" ry="240" stroke="#5BD891" stroke-width="1.1"/><ellipse cx="200" cy="700" rx="380" ry="250" stroke="#B4EA32" stroke-width="1.1"/></svg>
<div style="position:relative;padding:52px 64px 0;display:flex;justify-content:space-between;align-items:flex-start;">{lock}<div class="kick" style="color:var(--g200);border:1px solid var(--bi);border-radius:999px;padding:9px 17px;">Internal study · PGA Tour 2026</div></div>
<div style="position:relative;padding:0 64px;"><div class="kick" style="color:var(--lime4);margin-bottom:20px;">Four stats · one philosophy</div>
<h1 class="dsp" style="font-size:78px;line-height:.93;color:#fff;margin-bottom:24px;">The floor, the comeback,<br>the rule and the total.<br><span style="color:var(--lime);">Every number is a house rule.</span></h1>
<p style="font-size:17px;line-height:1.45;color:var(--g200);max-width:720px;">Clutch Rating, Comeback Factor, Rule Plus/Minus and Strokes Above The Cut: four ways to read a round, borrowed from the NFL, baseball and the NBA, all counted from the same shot files in the language of our house rules.</p></div>
<div style="position:relative;padding:0 64px 44px;display:flex;gap:14px;">
<div class="blw" style="flex:1;"><div class="kick" style="color:var(--g300);font-size:9px;margin-bottom:7px;">Rounds</div><div class="big mono" style="font-size:38px;color:#fff;">1,906</div><div class="fnw" style="margin-top:4px;">8 events, every made-cut round with shot detail</div></div>
<div class="blw" style="flex:1;"><div class="kick" style="color:var(--g300);font-size:9px;margin-bottom:7px;">Players ranked</div><div class="big mono" style="font-size:38px;color:#fff;">{len(PL)}</div><div class="fnw" style="margin-top:4px;">12 rounds or more</div></div>
<div class="blw" style="flex:1;"><div class="kick" style="color:var(--g300);font-size:9px;margin-bottom:7px;">Total value tracks scoring</div><div class="big mono" style="font-size:38px;color:var(--lime);">0.88</div><div class="fnw" style="margin-top:4px;">Strokes Above The Cut vs real strokes</div></div>
<div class="blw" style="flex:1;"><div class="kick" style="color:var(--g300);font-size:9px;margin-bottom:7px;">Top 13 in all four</div><div class="big mono" style="font-size:30px;color:#fff;margin-top:6px;">Jake Knapp</div><div class="fnw" style="margin-top:6px;">the only one</div></div></div></section>''')
fam=[('Clutch Rating','NFL · fourth-quarter comebacks','How many holes did he keep?','Clean + ¾ × comebacks − lost, per 18','The floor'),
('Comeback Factor','NFL · comeback wins, graded by the deficit','After a bad shot, did he beat the odds from that spot?','Comebacks ÷ the tour’s par rate from the same lie, distance and shots left · 100 = tour','The rescue'),
('Rule Plus/Minus','NBA · plus/minus, on and off the court','What does a house rule cost when it breaks?','Strokes vs the field on the same hole that day, rules kept vs rules broken','The rule'),
('Strokes Above The Cut','MLB · wins above replacement','How many strokes does he add over a cut-line player?','Avoidance + Comeback Factor + damage + birdies, against the 50th-and-worse finishers','The total')]
cards=''.join(f'<div class="blw" style="flex:1;display:flex;flex-direction:column;"><div class="kick" style="color:var(--lime4);font-size:8.6px;margin-bottom:8px;">{e(o)}</div><div class="dsp" style="font-size:19px;color:#fff;margin-bottom:8px;">{e(n)}</div><p class="bdw" style="font-size:13px;margin-bottom:8px;"><b style="color:#fff;">{e(q)}</b></p><p class="bdw" style="font-size:12px;margin-bottom:10px;">{e(f)}</p><div class="mono" style="margin-top:auto;font-size:11px;letter-spacing:.12em;text-transform:uppercase;color:var(--lime);">{e(t)}</div></div>' for n,o,q,f,t in fam)
S.append(dark(2,'The Family','— Four stats, one question each','Borrowed from three sports.<br>Built on our house rules.','The Clutch family',f'<div style="display:flex;gap:12px;flex:1;min-height:0;">{cards}</div>','A bad shot, in every stat, is a broken house rule: a tee shot out of play · an approach from 160 yards and in off the green · a chip, pitch or bunker shot off the green · a miss from 6 feet and in · a three-putt.'))
# 3 clutch rating
rows=''.join(trow([i,e(p['name']),f"{p['cr']:.2f}",p['rounds']]) for i,p in enumerate(top('cr'),1))
S.append(paper(3,'Clutch Rating','— 1 · The floor','How many holes did he keep?','Clutch Rating per 18 holes',
f'''<div style="display:flex;gap:14px;flex:1;min-height:0;"><div class="card sp" style="flex:1;"><div class="kick" style="color:var(--g700);font-size:9px;margin-bottom:9px;">What we found</div>
<p class="bd" style="margin-bottom:9px;">A raw count of comebacks has <b>no link</b> to scoring (0.00): it rewards the trouble as much as the rescue. Clutch Rating counts the clean holes first, so it tracks the score against the field at <b>0.71</b> on tour and <b>0.82</b> at Abu Dhabi.</p>
<p class="bd" style="margin-bottom:9px;">Measured in the first four events, it predicted scoring in the last four (0.41–0.48) <b>better than scoring itself did</b> (0.30–0.33).</p>
<p class="bd">Every bad shot costs about <b>0.6 of a stroke</b>; players come back about 6 times in 10 whatever the round. Rounds are decided by how often the test comes.</p></div>
<div class="card sp" style="flex:1;"><div class="kick" style="color:var(--g700);font-size:9px;margin-bottom:8px;">Leaders · 12 rounds or more</div><table class="tb"><tr><th>#</th><th>Player</th><th>Rating</th><th>Rounds</th></tr>{rows}</table><p class="bd" style="font-size:12px;margin-top:9px;">At 16 rounds or more Hideki Matsuyama leads: 19 rounds, no hole lost after a bad shot.</p></div></div>''',
'Per 18 holes; comebacks above the odds take full credit, expected comebacks ¾ (RC, 18 Nov). Tour average 14.8.'))
# 4 comeback factor
rows=''.join(trow([i,e(p['name']),f"{p['cf']:.0f}",p['rounds']]) for i,p in enumerate(top('cf'),1))
S.append(paper(4,'Comeback Factor','— 2 · The rescue','After a bad shot, did he<br>beat the odds?','100 = the tour from the same spots',
f'''<div style="display:flex;gap:14px;flex:1;min-height:0;"><div class="card sp" style="flex:1;"><div class="kick" style="color:var(--g700);font-size:9px;margin-bottom:8px;">How often the tour still makes par</div><table class="tb"><tr><th></th><th>After the bad shot</th><th>Par or better</th></tr>
<tr><td></td><td>Chip off the green into the fairway, 1 left</td><td style="color:var(--red6);font-weight:700">10%</td></tr>
<tr><td></td><td>Penalty off the tee, 2 left</td><td style="color:var(--red6);font-weight:700">15%</td></tr>
<tr><td></td><td>Tee shot in a recovery lie, 3 left</td><td>71%</td></tr>
<tr><td></td><td>Tee shot in a bunker, 3 left</td><td>77%</td></tr>
<tr><td></td><td>Approach short on the fairway, 2 left</td><td style="color:var(--g700);font-weight:700">81%</td></tr></table>
<p class="bd" style="font-size:12px;margin-top:10px;">The deficit decides the odds, so every comeback is graded against them. A missed short putt is decided on the spot, so the Factor lives in the long game and the short game.</p></div>
<div class="card sp" style="flex:1;"><div class="kick" style="color:var(--g700);font-size:9px;margin-bottom:8px;">Leaders · 12 rounds or more</div><table class="tb"><tr><th>#</th><th>Player</th><th>Factor</th><th>Rounds</th></tr>{rows}</table><p class="bd" style="font-size:12px;margin-top:9px;">Kevin Roy turns bad shots into par 22% more often than the tour from the same spots.</p></div></div>''',
'8,024 tests in 113 situations (bad-shot type × lie × distance × shots left for par); small groups pulled toward their type average.'))
# 5 rule plus minus rules
S.append(paper(5,'Rule Plus/Minus','— 3 · The rule','Break a rule near the hole<br>and it costs twice as much.','Strokes vs the field, same hole, same day',
'<div style="display:flex;gap:14px;flex:1;min-height:0;"><div class="card sp" style="flex:1.15;"><div class="kick" style="color:var(--g700);font-size:9px;margin-bottom:12px;">On / off: per hole, against the field</div>'+
bar('Every rule kept','+0.15',15,'var(--g500)','var(--g700)')+bar('One rule broken','−0.48',48,'var(--red)','var(--red6)')+
'<div class="kick" style="color:var(--g700);font-size:9px;margin:16px 0 12px;">What each broken rule costs</div>'+
bar('Tee shot out of play','−0.38',37,'var(--bog)','var(--bogT)')+bar('Approach 160 in, off the green','−0.43',42,'var(--bog)','var(--bogT)')+bar('Miss from 6 ft and in','−0.84',82,'var(--red)','var(--red6)')+bar('Chip, pitch or bunker shot off the green','−0.99',97,'var(--red)','var(--red6)')+bar('Three-putt','−1.02',100,'var(--red)','var(--red6)')+
'''</div><div class="card sp" style="flex:1;background:var(--g950);border-color:var(--g800);"><div class="kick" style="color:var(--lime4);font-size:9px;margin-bottom:9px;">What it proves</div><p class="bdw" style="font-size:13.5px;margin-bottom:10px;">The rules nearest the hole are the most expensive to break: a three-putt or a chip off the green costs about <b style="color:#fff;">twice</b> a missed green or a tee shot out of play.</p><p class="bdw" style="font-size:13.5px;margin-bottom:10px;">That is the order the house rules already put them in: <b style="color:#fff;">inside 6 feet is sacred</b> is rule 1.</p><p class="bdw" style="font-size:13.5px;">Every house rule now has a price in strokes a player can see.</p></div></div>''',
'+ = better than the field. Field = every made-cut player on that hole in that round. 34,308 holes.'))
# 6 rule pm players
pmc=sorted(PL,key=lambda p:-p['pmc'])[:5]; pmt=sorted(PL,key=lambda p:-p['pmt'])[:5]
r1=''.join(trow([i,e(p['name']),f"+{p['pmc']:.2f}"]) for i,p in enumerate(pmc,1)); r2=''.join(trow([i,e(p['name']),f"{p['pmt']:+.2f}".replace('-','−')]) for i,p in enumerate(pmt,1))
S.append(paper(6,'Rule Plus/Minus Players','— 3 · The rule, by player','Who scores when the rules<br>hold, who survives when they don’t.','Per hole, vs the field',
f'''<div style="display:flex;gap:14px;flex:1;min-height:0;"><div class="card sp" style="flex:1;"><div class="kick" style="color:var(--g700);font-size:9px;margin-bottom:8px;">Best on clean holes (rules kept)</div><table class="tb"><tr><th>#</th><th>Player</th><th>+/− a hole</th></tr>{r1}</table><p class="bd" style="font-size:12px;margin-top:9px;">Tour average +0.15. These players turn a kept rule into birdies.</p></div>
<div class="card sp" style="flex:1;"><div class="kick" style="color:var(--g700);font-size:9px;margin-bottom:8px;">Best on test holes (a rule broken)</div><table class="tb"><tr><th>#</th><th>Player</th><th>+/− a hole</th></tr>{r2}</table><p class="bd" style="font-size:12px;margin-top:9px;">Tour average −0.48. These players lose the least when a rule breaks.</p></div></div>''',
'12 rounds or more. Knapp and Gotterup are in the top 5 of both lists.'))
# 7 SAC how
R=D['rep']
S.append(paper(7,'Strokes Above The Cut','— 4 · The total','How many strokes does he<br>add over a cut-line player?','Baseball’s wins above replacement',
f'''<div style="display:flex;gap:14px;flex:1;min-height:0;"><div class="card sp" style="flex:1.1;"><div class="kick" style="color:var(--g700);font-size:9px;margin-bottom:9px;">The cut-line player</div><p class="bd" style="margin-bottom:12px;">Baseball measures a player against a free replacement off the bench. Ours is the player at the bottom of the weekend: <b>the 50th-and-worse finishers</b>, 1.5 strokes a round worse than the field, with {R['tests']:.1f} bad shots and {R['bird']:.1f} birdies a round.</p>
<table class="tb"><tr><th></th><th>Part, per round</th><th>Worth</th></tr>
<tr><td></td><td>Avoidance · each bad shot fewer</td><td>0.63</td></tr><tr><td></td><td>Comeback Factor · each comeback above the odds</td><td>1.27</td></tr><tr><td></td><td>Damage · each lost hole fewer</td><td>1.18</td></tr><tr><td></td><td>Birdies · each one more</td><td>1.00</td></tr></table></div>
<div class="card sp" style="flex:1;background:var(--g950);border-color:var(--g800);"><div class="kick" style="color:var(--lime4);font-size:9px;margin-bottom:9px;">Why it matters</div><p class="bdw" style="font-size:13.5px;margin-bottom:10px;">It is the only one of the four that counts the <b style="color:#fff;">ceiling</b>: birdies. Added up, it tracks each player’s real strokes over the cut line at <b style="color:#fff;">0.88</b>.</p><p class="bdw" style="font-size:13.5px;margin-bottom:10px;">Golf has its own runs-per-win: about <b style="color:#fff;">10 strokes an event</b> separate the middle of the weekend field from the winner.</p><p class="bdw" style="font-size:13.5px;">The cut-line player sits about 6 strokes an event below the middle, so a winner’s week is about <b style="color:#fff;">4 strokes a round</b> above the cut. Bridgeman averages 3.1.</p></div></div>''',
'Stroke values from the data: a bad shot vs a clean hole 0.63; a converted test vs one that was not 1.27; a lost hole vs a bogey saved 1.18. Median made-cut finisher to 10th: 5.6 strokes an event; to the winner 10.4.'))
# 8 SAC leaders
rows=''.join(trow([i,e(p['name']),f"{p['sac']:.2f}",f"{p['av']:+.2f}",f"{p['cfs']:+.2f}",f"{p['dm']:+.2f}",f"{p['bd']:+.2f}"]).replace('+-','−').replace('>-','>−') for i,p in enumerate(top('sac',5),1))
S.append(dark(8,'Strokes Above The Cut Leaders','— 4 · The total, by player','Bridgeman adds three strokes<br>a round over the cut line.','12 rounds or more',
f'<table class="tb tbw" style="font-size:12.5px;"><tr><th>#</th><th>Player</th><th>Above the cut</th><th>Avoidance</th><th>Comeback</th><th>Damage</th><th>Birdies</th></tr>{rows}</table>',
'Strokes a round above the cut-line player. Birdies are the biggest part for the leaders; Matsuyama, the floor leader at 16 rounds, ranks 24th here because he makes fewer birdies.'))
# 9 all four
best=sorted(PL,key=lambda p:p['r_cr']+p['r_cf']+p['r_pm']+p['r_sac'])[:10]
rows=''.join(f"<tr><td>{i}</td><td>{e(p['name'])}</td><td>{p['r_cr']}</td><td>{p['r_cf']}</td><td>{p['r_pm']}</td><td>{p['r_sac']}</td><td>{p['rounds']}</td></tr>" for i,p in enumerate(best,1))
S.append(paper(9,'All Four','— The four together','Knapp is the only player<br>top 13 in all four.','Rank among 76 players',
f'''<div style="display:flex;gap:14px;flex:1;min-height:0;"><div class="card sp" style="flex:1.2;"><table class="tb"><tr><th>#</th><th>Player</th><th>Clutch</th><th>Comeback</th><th>+/−</th><th>Above the cut</th><th>Rounds</th></tr>{rows}</table></div>
<div class="card sp" style="flex:1;"><div class="kick" style="color:var(--g700);font-size:9px;margin-bottom:9px;">Three kinds of great</div><p class="bd" style="margin-bottom:9px;"><b>The complete player:</b> Knapp, Harry Hall, Gotterup. Top 15 on every list.</p><p class="bd" style="margin-bottom:9px;"><b>The front-runners:</b> Scheffler and Bridgeman, 1st and 2nd on plus/minus and above the cut, 47th–48th on Comeback Factor. They rarely need one.</p><p class="bd"><b>The floor keepers:</b> Matsuyama and Kevin Roy. Top 3 on Comeback Factor, lower on Strokes Above The Cut: fewer birdies. The coaching for them is the ceiling.</p></div></div>''',
'Ordered by the sum of the four ranks. +/− = total plus/minus a round against the field.'))
# 10 philosophy
S.append(dark(10,'Our Philosophy','— What the four say together','Keep the rules, make the<br>birdies, rescue the rest.','For our players',
'''<div style="display:flex;gap:12px;flex:1;min-height:0;">
<div class="blw" style="flex:1;"><div class="kick" style="color:var(--lime4);font-size:9px;margin-bottom:9px;">1 · The rules are worth strokes</div><p class="bdw" style="font-size:13px;">Rule Plus/Minus prices every house rule. The ones nearest the hole cost the most, which is why practice starts inside 6 feet.</p></div>
<div class="blw" style="flex:1;"><div class="kick" style="color:var(--lime4);font-size:9px;margin-bottom:9px;">2 · Avoid first, rescue second</div><p class="bdw" style="font-size:13px;">Clutch Rating and Comeback Factor together: fewer tests beat better comebacks, but a player who beats the odds after a bad shot saves the round. Decide before the tee, not after the miss.</p></div>
<div class="blw" style="flex:1;"><div class="kick" style="color:var(--lime4);font-size:9px;margin-bottom:9px;">3 · Raise the floor, then the ceiling</div><p class="bdw" style="font-size:13px;">Strokes Above The Cut shows the birdies the floor stats leave out. A floor keeper's next stroke is a birdie; a birdie maker's is a kept rule.</p></div></div>
<div class="blw" style="margin-top:12px;background:color-mix(in oklch,var(--lime) 12%,transparent);border-color:var(--lime6);"><div class="kick" style="color:var(--lime);font-size:9px;margin-bottom:6px;">How a season report could read (mock-up, not built)</div><p class="mono" style="font-size:14px;color:#fff;">Clutch Rating 15.5 · Comeback Factor 108 · Rule +/− +0.18 kept / −0.40 broken · +2.1 above the cut</p></div>''',
'Internal for now (RC, 18 Nov): the four stats are a tour study; nothing here is on a player report or a post yet.'))
# 11 limits + questions
S.append(dark(11,'Limits and Questions','— Before any of it is named','Early on players.<br>Solid on rounds.','For RC',
'''<div style="display:flex;gap:12px;flex:1;min-height:0;"><div class="blw" style="flex:1;"><div class="kick" style="color:var(--lime4);font-size:9px;margin-bottom:9px;">Limits</div><p class="bdw" style="font-size:12.5px;margin-bottom:8px;">8 early-season events; player boards rest on 12 to 25 rounds. Made-cut rounds only, so the true cut-line player is estimated from the bottom of the weekend field. The PGA feed marks no fringe. Stroke values come from this data and will move with a full season.</p><p class="bdw" style="font-size:12.5px;">Round-level findings held on the Abu Dhabi field (0.82); the player boards need a season.</p></div>
<div class="blw" style="flex:1.2;"><div class="kick" style="color:var(--lime4);font-size:9px;margin-bottom:9px;">Questions</div>
<p class="bdw" style="font-size:12.5px;margin-bottom:7px;"><b style="color:#fff;">1 · Instagram (yes, RC 18 Nov).</b> Rule Plus/Minus as a nameless post: “The rule that costs the most to break is the closest to the hole.”</p>
<p class="bdw" style="font-size:12.5px;margin-bottom:7px;"><b style="color:#fff;">2 · Missed-cut rounds.</b> Add them when the pull resumes, so the cut-line player is measured, not estimated.</p>
<p class="bdw" style="font-size:12.5px;"><b style="color:#fff;">3 · Our players.</b> Should a Season Report carry the four stats once the season confirms them?</p></div></div>'''))
out=head+'<deck-stage width="1056" height="816" no-rail>\n'+'\n'.join(S)+'\n</deck-stage>\n</body>\n</html>\n'
open('/home/user/rc-greenlight/deliverables/The Clutch Family - Four Stats 2026.html','w').write(out.replace('Clutch Rating · Tour Study','The Clutch Family'))
print('ok')
