import json,html
F=json.load(open('final.json')); e=html.escape
WCB=0.75
import collections as _C
_rd=json.load(open('rounds.json')); _SP=_C.defaultdict(list)
for _a in _rd: _SP[_a['pid']].append(_a)
_nm={x['name']:x for x in F['board']}
for x in F['board']: x['rating']=x['clean']+WCB*x['cb']-x['lost']
F['board'].sort(key=lambda x:-x['rating'])
head=open('../head.html').read().replace('Kiril Engeli Poretti · State of the Game','Clutch Rating · Tour Study')
css='''<style>
.tb{width:100%;border-collapse:collapse;font-size:12px}
.tb th{font-family:var(--fm);font-size:8.6px;letter-spacing:.1em;text-transform:uppercase;color:var(--ink5);font-weight:600;text-align:right;padding:0 6px 6px;border-bottom:1px solid var(--bs)}
.tb th:first-child,.tb th:nth-child(2){text-align:left}
.tb td{padding:5px 6px;border-bottom:1px solid var(--bs);text-align:right;font-family:var(--fm);font-variant-numeric:tabular-nums;color:var(--ink9)}
.tb td:first-child{text-align:left;color:var(--ink5);width:24px}.tb td:nth-child(2){text-align:left;font-family:var(--fs);font-weight:600}
.tb tr:last-child td{border-bottom:0}
.tbw th{color:var(--g300);border-color:var(--bi)}.tbw td{color:#fff;border-color:var(--bi)}.tbw td:first-child{color:var(--g300)}
.bar{display:flex;align-items:center;gap:10px;margin-bottom:7px}
.bar .l{width:230px;font-size:12.5px;color:var(--ink7)}
.bar .t{flex:1;height:18px;background:var(--paper2);border-radius:3px;overflow:hidden}
.bar .v{width:52px;text-align:right;font-family:var(--fm);font-weight:700;font-size:12.5px}
</style>'''
head=head.replace('</head>',css+'</head>')
lock='<div class="lock"><div><div class="wm"><span style="color:#fff;">RCGreen</span><span style="color:var(--g400);">light</span></div><div class="desc" style="color:var(--g300);">Every number ends with a choice</div></div></div>'
def paper(n,label,kick,title,right,body,fn):
    return f'''<section data-label="{label}" data-screen-label="{n:02d}" style="background:var(--paper);color:var(--ink9);"><div style="position:absolute;inset:0;padding:40px 52px 30px;display:flex;flex-direction:column;"><div class="hd"><div><div class="kick" style="color:var(--g700);margin-bottom:10px;">{kick}</div><h2 class="h2">{title}</h2></div><div class="kick" style="color:var(--ink5);text-align:right;">{right}</div></div>{body}<div class="fn" style="margin-top:auto;padding-top:10px;">{fn}</div></div></section>'''
def dark(n,label,kick,title,right,body,fn=''):
    return f'''<section data-label="{label}" data-screen-label="{n:02d}" style="background:var(--g950);color:#fff;"><div style="position:absolute;inset:0;padding:44px 56px 36px;display:flex;flex-direction:column;"><div class="hdd"><div><div class="kick" style="color:var(--lime4);margin-bottom:10px;">{kick}</div><h2 class="h2w">{title}</h2></div><div class="kick" style="color:var(--g300);text-align:right;">{right}</div></div>{body}<div class="fnw" style="margin-top:auto;padding-top:10px;">{fn}</div></div></section>'''
def bar(l,v,w,col,vcol=None):
    return f'<div class="bar"><span class="l">{l}</span><div class="t"><div style="width:{w}%;height:100%;background:{col};"></div></div><span class="v" style="color:{vcol or "var(--ink9)"};">{v}</span></div>'
D=json.load(open('four.json')); PL=D['pl']
def top(key,n=5): return sorted(PL,key=lambda p:-p[key])[:n]
def trow(cells,bold=2): return '<tr>'+''.join(f'<td{" style=\"font-weight:700\"" if i==bold else ""}>{c}</td>' for i,c in enumerate(cells))+'</tr>'
SS=json.load(open('season5.json')); DP=json.load(open('dpw.json'))
def tbl(head,rows,dark_=False):
    h=''.join(f'<th>{x}</th>' for x in head)
    r=''.join('<tr>'+''.join(f'<td{" style=\"font-weight:700\"" if j==2 else ""}>{c}</td>' for j,c in enumerate(row))+'</tr>' for row in rows)
    return f'<table class="tb{" tbw" if dark_ else ""}"><tr>{h}</tr>{r}</table>'
def card(kick,inner,flex=1,extra=''):
    return f'<div class="card sp" style="flex:{flex};{extra}"><div class="kick" style="color:var(--g700);font-size:9px;margin-bottom:8px;">{kick}</div>{inner}</div>'
def note(t): return f'<p class="bd" style="font-size:11.5px;margin-top:8px;">{t}</p>'
T5=lambda key:sorted(PL,key=lambda p:-p[key])[:5]
S=[]
S.append(f'''<section data-label="Cover" data-screen-label="01" style="background:var(--g950);color:#fff;display:flex;flex-direction:column;justify-content:space-between;">
<svg class="ctour" viewBox="0 0 1056 816" fill="none" aria-hidden="true" style="opacity:.12;"><ellipse cx="830" cy="180" rx="520" ry="330" stroke="#5BD891" stroke-width="1.2"/><ellipse cx="830" cy="180" rx="400" ry="240" stroke="#5BD891" stroke-width="1.1"/><ellipse cx="200" cy="700" rx="380" ry="250" stroke="#B4EA32" stroke-width="1.1"/></svg>
<div style="position:relative;padding:52px 64px 0;display:flex;justify-content:space-between;align-items:flex-start;">{lock}<div class="kick" style="color:var(--g200);border:1px solid var(--bi);border-radius:999px;padding:9px 17px;">Internal · 18 November 2026</div></div>
<div style="position:relative;padding:0 64px;"><div class="kick" style="color:var(--lime4);margin-bottom:20px;">The Clutch Factor Family</div>
<h1 class="dsp" style="font-size:80px;line-height:.93;color:#fff;margin-bottom:24px;">Every way a round<br>is kept, rescued<br><span style="color:var(--lime);">or given away.</span></h1>
<p style="font-size:17px;line-height:1.45;color:var(--g200);max-width:720px;">Today's tour study in one place: the season boards through Austin, the four new stats built on our house rules, the second-tour check, and the next ideas from the NBA and NFL. Top 5 players on every stat.</p></div>
<div style="position:relative;padding:0 64px 44px;display:flex;gap:14px;">
<div class="blw" style="flex:1;"><div class="kick" style="color:var(--g300);font-size:9px;margin-bottom:7px;">Season stats</div><div class="big mono" style="font-size:36px;color:#fff;">170</div><div class="fnw" style="margin-top:4px;">players, PGA Tour through Austin</div></div>
<div class="blw" style="flex:1;"><div class="kick" style="color:var(--g300);font-size:9px;margin-bottom:7px;">Shot by shot</div><div class="big mono" style="font-size:36px;color:#fff;">2,186</div><div class="fnw" style="margin-top:4px;">rounds: 8 PGA events + Abu Dhabi</div></div>
<div class="blw" style="flex:1;"><div class="kick" style="color:var(--g300);font-size:9px;margin-bottom:7px;">Holes graded</div><div class="big mono" style="font-size:36px;color:#fff;">39,348</div><div class="fnw" style="margin-top:4px;">against the house rules</div></div>
<div class="blw" style="flex:1;"><div class="kick" style="color:var(--g300);font-size:9px;margin-bottom:7px;">Clutch stats</div><div class="big mono" style="font-size:36px;color:var(--lime);">10</div><div class="fnw" style="margin-top:4px;">four of them new today</div></div></div></section>''')
# 2 family map
fam=[('Clutch Rating','The umbrella: clean + ¾ comebacks − lost, per 18','NEW'),('Comeback Factor','Comebacks graded by the odds from the spot · 100 = tour','NEW'),('Rule Plus/Minus','Strokes vs the field, rules kept vs broken','NEW'),('Strokes Above The Cut','Total strokes over a cut-line player','NEW'),
('Clutch Factor Dominance','A round that never needed to be clutch','PUBLISHED'),('Clutch Factor Ball Striking','Par or better after trouble','PUBLISHED'),('Clutch Factor Putting','Par putts from 5 ft and out','PUBLISHED'),('Clutch Factor Damage Control','Trouble held to bogey','PUBLISHED'),('Clutch Factor Response','The three holes after a bogey','PUBLISHED'),('Clutch Factor Closing','The last nine within 3 of the lead','PUBLISHED'),('Season boards','Recovery · short game · birdie and par putts','PGATOUR.COM')]
items=''.join(f'<div class="blw" style="padding:9px 12px;"><div class="mono" style="font-size:8.4px;letter-spacing:.14em;color:{"var(--lime)" if t=="NEW" else "var(--g300)"};margin-bottom:4px;">{t}</div><div class="dsp" style="font-size:14px;color:#fff;margin-bottom:3px;">{e(n)}</div><p class="bdw" style="font-size:11px;">{e(d)}</p></div>' for n,d,t in fam)
S.append(dark(2,'The Family','— One family, internally','The Clutch Factor Family.','RC, 18 Nov',
f'<div style="display:grid;grid-template-columns:repeat(4,1fr);gap:9px;">{items}</div>',
'Published Clutch Factor names stay as they are on reports. Internally they are one family; a rename ships as one house-rules rev once a full season confirms the new stats. A bad shot, in every new stat, is a broken house rule.'))
# 3 season boards
r=SS['recovery']; s=SS['shortgame']; p=SS['putting']
S.append(paper(3,'Season Boards','— PGA Tour season, through Austin · 170 players','Recovery, short game,<br>birdie and par putts.','pgatour.com season stats',
'<div style="display:flex;gap:12px;flex:1;min-height:0;">'+
card('Recovery artist · greens after a missed fairway',tbl(['#','Player','Greens','Rough 100+'],[[i+1,e(a),b_,c] for i,(a,b_,c) in enumerate(r)])+note('Tour 51.7% and 49\' 9". Koepka hits the most greens of the five.'))+
card('Short game · around the green',tbl(['#','Player','Proximity','Scrambling'],[[i+1,e(a),b_,c] for i,(a,b_,c) in enumerate(s)])+note('Tour 7\' 9" and 59.4%.'))+
card('Birdie and par putts',tbl(['#','Player','Birdie conv.','5–10 ft'],[[i+1,e(a),b_,c] for i,(a,b_,c) in enumerate(p)])+note('Tour 31.4% and 57.2%. 5–10 ft stands in for par putts.'))+'</div>',
'Each board blends two pgatour.com season stats, counted equally. Recovery: GIR from other than fairway + approach proximity from the rough over 100 yd. Short game: proximity around the green + scrambling. Putts: birdie-or-better conversion + made from 5–10 ft.'))
# 4 season leaders
S.append(paper(4,'Season Leaders','— The season’s best, through Austin','Scheffler leads scoring.<br>Brown avoids bogeys best.','pgatour.com season stats',
'<div style="display:flex;gap:12px;flex:1;min-height:0;">'+
card('Scoring average',tbl(['#','Player','Average'],[[i+1,e(a),b_] for i,(a,b_) in enumerate(SS['scoring'])])+note('Tour 70.94.'))+
card('Bogey avoidance · the season’s floor',tbl(['#','Player','Bogey holes'],[[i+1,e(a),b_] for i,(a,b_) in enumerate(SS['bogey'])])+note('Tour 15.5%. The closest season stat to Clutch Rating.'))+
card('Who is on both',f'<p class="bd" style="margin-bottom:9px;"><b>Scheffler and Kohles</b> are top 3 on both: they score and they rarely give a hole away.</p><p class="bd">Neither has enough rounds in our 8 saved events to reach the shot-by-shot boards (Scheffler 14, Kohles 4), which is the case for the full-season pull.</p>')+'</div>',
'Through the Austin Championship, Nov 15. Every tracked round, missed cuts included.'))
# 5 clutch rating
S.append(paper(5,'Clutch Rating','— New · the floor','How many holes did he keep?','8 PGA events · 12 rounds or more',
'<div style="display:flex;gap:12px;flex:1;min-height:0;">'+
card('What it found',f'<p class="bd" style="margin-bottom:9px;">Counting comebacks alone tells you <b>nothing</b>: rounds with the most comebacks scored the same as rounds with the fewest. Counting clean holes first fixes it: in the quarter of rounds with the <b>highest</b> rating, players beat the field by about <b>2 strokes</b>; in the <b>lowest</b> quarter they lost to it by <b>2½</b>.</p><p class="bd" style="margin-bottom:9px;">It also looks ahead: players in the top half on Clutch Rating in the first four events beat the field by about <b>half a stroke a round</b> in the last four; the bottom half lost to it. Their own early scores sorted the later results <b>far less well</b>.</p><p class="bd">Each bad shot costs about half a stroke; players still make par about 6 times in 10, whatever the round.</p>')+
card('Top 5',tbl(['#','Player','Rating','Rounds'],[[i+1,e(q['name']),f"{q['cr']:.2f}",q['rounds']] for i,q in enumerate(T5('cr'))])+note('The rating reads like holes kept out of 18: 16 means about 16 holes kept. At 16 rounds or more Matsuyama leads, with no hole lost after a bad shot in 19 rounds.'))+'</div>',
'Clean + ¾ × expected comebacks + comebacks above the odds − lost, per 18. Tour average 14.8.'))
# 6 weight
S.append(paper(6,'The Weight','— Decided today','A clean hole counts more<br>than a rescue.','Comeback weight tested',
'<div style="display:flex;gap:12px;flex:1;min-height:0;">'+
card('Every weight we tried',tbl(['','Comeback counts as','Best vs worst rounds','Each week’s winner, rank in his field','Rewards fewer bad shots'],[['','¾ of a clean hole (chosen)','4.5 strokes apart','1, 2, 6, 8, 11, 13','Strongly'],['','1 clean hole','4.0','1, 4, 4, 6, 14, 19','Fairly'],['','1¼ clean holes','4.3','1, 4, 6, 13, 24, 32','Weakly'],['','1½ clean holes','3.6','1, 5, 5, 26, 30, 45','Barely']]),1.4)+
card('Why ¾',f'<p class="bd" style="margin-bottom:9px;">RC: “3/4 is probably better and rewards less stressful holes.”</p><p class="bd" style="margin-bottom:9px;">Heavier weights reward the trouble that made the comeback: at 1.25 two winners fall to 24th and 32nd.</p><p class="bd">On the Abu Dhabi field ¾ also sorted good rounds from bad better than counting a comeback as a full hole. The harder shot gets its credit from Comeback Factor instead.</p>')+'</div>',
'Best vs worst rounds = how many strokes, against the field, separate the quarter of rounds each weighting rates highest from the quarter it rates lowest. Bigger is better.'))
# 7 comeback factor
S.append(paper(7,'Comeback Factor','— New · the rescue','After a bad shot, did he<br>beat the odds?','100 = the tour from the same spots',
'<div style="display:flex;gap:12px;flex:1;min-height:0;">'+
card('How often the tour still makes par',tbl(['','After the bad shot','Par or better'],[['','Chip off the green into the fairway, 1 left','10%'],['','Penalty off the tee, 2 left','15%'],['','Tee shot in a recovery lie, 3 left','71%'],['','Tee shot in a bunker, 3 left','77%'],['','Approach short on the fairway, 2 left','81%']])+note('A missed short putt is decided on the spot, so the Factor lives in the long and short game.'))+
card('Top 5',tbl(['#','Player','Factor','Rounds'],[[i+1,e(q['name']),f"{q['cf']:.0f}",q['rounds']] for i,q in enumerate(T5('cf'))])+note('Kevin Roy makes par after a bad shot 22% more often than the tour from the same spots.'))+'</div>',
'8,024 tests in 113 situations (bad-shot type × lie × distance × shots left for par). RC: “I like Comebacks / Comeback Index” → named Comeback Factor.'))
# 8 rule pm
pmc=sorted(PL,key=lambda q:-q['pmc'])[:5]; pmt=sorted(PL,key=lambda q:-q['pmt'])[:5]
S.append(paper(8,'Rule Plus/Minus','— New · the rule (from the NBA)','Break a rule near the hole<br>and it costs twice as much.','Strokes vs the field, same hole, same day',
'<div style="display:flex;gap:12px;flex:1;min-height:0;">'+
card('What each broken rule costs',tbl(['','Rule broken','Strokes lost vs field'],[['','Tee shot out of play','−0.38'],['','Approach 160 in, off the green','−0.43'],['','Miss from 6 ft and in','−0.84'],['','Chip, pitch or bunker shot off the green','−0.99'],['','Three-putt','−1.02']])+note('Every rule kept: +0.15 a hole. One broken: −0.48.'),1.15)+
card('Top 5 · rules kept',tbl(['#','Player','Strokes vs field, a hole'],[[i+1,e(q['name']),f"+{q['pmc']:.2f}"] for i,q in enumerate(pmc)])+note('Tour average +0.15: a stroke gained every 7 clean holes. Scheffler gains one every 4.'))+
card('Top 5 · a rule broken',tbl(['#','Player','Strokes vs field, a hole'],[[i+1,e(q['name']),f"{q['pmt']:.2f}".replace('-','−')] for i,q in enumerate(pmt)])+note('Tour average −0.48: half a stroke lost each time a rule breaks. These players lose about a quarter.'))+'</div>',
'The nameless Instagram carousel of this slide is built (4 slides) and waits on RC’s OK.'))
# 9 SAC
S.append(paper(9,'Strokes Above The Cut','— New · the total (from baseball’s WAR)','How many strokes over<br>a cut-line player?','12 rounds or more',
'<div style="display:flex;gap:12px;flex:1;min-height:0;">'+
card('How it is built',tbl(['','Part, per round','Worth'],[['','Avoidance · each bad shot fewer','0.63'],['','Comeback Factor · each comeback above the odds','1.27'],['','Damage · each lost hole fewer','1.18'],['','Birdies · each one more','1.00']])+note('The cut-line player = the 50th-and-worse finishers, 1.5 strokes a round worse than the field. It lands within about a third of a stroke a round of each player’s real strokes over the cut. A winner’s week is about 4 strokes a round above the cut.'),1.15)+
card('Top 5',tbl(['#','Player','Above the cut','Birdies part'],[[i+1,e(q['name']),f"{q['sac']:.2f}",f"+{q['bd']:.2f}"] for i,q in enumerate(T5('sac'))])+note('The only one of the four that counts the ceiling: birdies.'))+'</div>',
'Stroke values come from the data and will move with a full season.'))
# 10 all four
best=sorted(PL,key=lambda q:q['r_cr']+q['r_cf']+q['r_pm']+q['r_sac'])[:5]
S.append(dark(10,'All Four','— The four new stats together','Knapp is the only player<br>top 13 in all four.','Ranks among 76 players',
'<div style="display:flex;gap:12px;flex:1;min-height:0;"><div style="flex:1.2;">'+tbl(['#','Player','Clutch','Comeback','+/−','Above the cut'],[[i+1,e(q['name']),q['r_cr'],q['r_cf'],q['r_pm'],q['r_sac']] for i,q in enumerate(best)],True)+'</div>'
'<div class="blw" style="flex:1;"><div class="kick" style="color:var(--lime4);font-size:9px;margin-bottom:9px;">Three kinds of great</div><p class="bdw" style="font-size:12.5px;margin-bottom:8px;"><b style="color:#fff;">Complete:</b> Knapp, Harry Hall, Gotterup, top 15 on every list.</p><p class="bdw" style="font-size:12.5px;margin-bottom:8px;"><b style="color:#fff;">Front-runners:</b> Scheffler and Bridgeman, 1st and 2nd on plus/minus and above the cut, 47th–48th on Comeback Factor. They rarely need one.</p><p class="bdw" style="font-size:12.5px;"><b style="color:#fff;">Floor keepers:</b> Matsuyama and Kevin Roy, top 3 on Comeback Factor, lower on birdies.</p></div></div>',
'Ordered by the sum of the four ranks.'))
# 11 second tour
S.append(paper(11,'Second Tour','— The check on another tour','Abu Dhabi: the same pattern,<br>stronger.','70 made-cut players · 280 rounds',
'<div style="display:flex;gap:12px;flex:1;min-height:0;">'+
card('PGA Tour vs Abu Dhabi',tbl(['','Per round','PGA · 8 events','Abu Dhabi'],[['','Best vs worst quarter of rounds by rating','4.6 strokes apart','6.1 strokes apart'],['','Most vs fewest comebacks','no difference','2.4 strokes worse'],['','Bad shots a round','4.2','4.0'],['','Bad shots still saved for par','61%','53%'],['','What each bad shot costs','0.6 strokes','1.0 stroke'],['','Top 10 vs rest · rating','15.6 · 14.7','15.8 · 14.4']]),1.3)+
card('Top 5 · Clutch Rating, Abu Dhabi',tbl(['#','Player','Rating','To par'],[[i+1,e(x[1]),f"{x[0]:.2f}",('−' if x[7]<0 else '+')+str(abs(x[7]))] for i,x in enumerate(DP['pl'][:5])])+note('The winner, Jon Rahm (−23), is 4th of 70.'))+'</div>',
'The DP feed marks the fringe (off the green); the PGA feed does not. The BMW PGA capture (round 1 only) is not counted.'))
# 12 research
ideas=[('NFL · Success rate','Shot Success Rate','A shot is a success if it keeps the hole on par track by the tour’s own odds. One number for every shot, not just the bad ones.','Best rounds beat the worst by 4 strokes.'),
('NFL · Completion % over expected','Greens Over Expected','Greens hit against what the tour hits from the same distance and lie. Separates the hard week from the bad week.','Best rounds beat the worst by 2 strokes.'),
('NFL · Fourth-down decision bot','The Go Line, graded','Every par-5 go and every lay-up graded by expected strokes, like a go-for-it chart. House rule 2 already has the go line.','Going beats laying up by about 0.4 a hole.'),
('NFL/NBA · Win probability and leverage','Leverage-weighted Clutch','Weight each hole by how much it moves the chance of winning: Sunday’s back nine near the lead counts most. The grown-up Clutch Factor Closing.','Contenders lose 2.5 strokes of their edge on Sunday.'),
('NBA · Dean Oliver’s Four Factors','Golf’s Four Factors','Tee in play, greens, scrambling, putts per green hit: our stress chain, each weighted by what it is worth in strokes.','Putts per green hit carries the most weight.'),
('NBA · PDO and luck regression','Putting luck','Putts holed over expected from 15 ft+ swing a week and fall back. Splits the repeatable from the lucky so a hot week is not mistaken for a new level.','Long putts are mostly luck; short putts repeat.')]
cards=''.join(f'<div class="blw" style="padding:10px 12px;"><div class="mono" style="font-size:8.2px;letter-spacing:.12em;color:var(--g300);margin-bottom:4px;">{e(a)}</div><div class="dsp" style="font-size:14.5px;color:#fff;margin-bottom:4px;">{e(b_)}</div><p class="bdw" style="font-size:11px;margin-bottom:5px;">{e(c)}</p><p class="mono" style="font-size:9px;color:var(--lime4);">{e(d)}</p></div>' for a,b_,c,d in ideas)
S.append(dark(12,'Next Ideas','— From the NBA and NFL, studied today','Six more ideas,<br>each tested below.','Research, 18 Nov',f'<div style="display:grid;grid-template-columns:repeat(3,1fr);gap:9px;">{cards}</div>',
'Each built on the 8 saved PGA events (1,906 rounds, 131,484 shots) from one table: the tour’s expected strokes to hole out from every lie and distance. Results on the next six slides.'))
ID=json.load(open('ideas.json'))
def nm(x): return e(x)
sr=ID['sr_top']; cat=ID['sr_cat']
S.append(paper(13,'Shot Success Rate','— Idea 1 · from the NFL’s success rate','Six shots in ten beat<br>the tour’s average shot.','Every shot, graded against the tour',
'<div style="display:flex;gap:12px;flex:1;min-height:0;">'+
card('What we found',f'<p class="bd" style="margin-bottom:9px;">A shot is a <b>success</b> when it leaves the ball no worse than the tour’s average shot from the same lie and distance. Tour players succeed on <b>{ID["sr_tour"]*100:.0f}%</b> of shots.</p>'+tbl(['','Shot','Success'],[['','Putts',f"{cat['putt']*100:.0f}%"],['','Tee shots, par 4s and 5s',f"{cat['tee']*100:.0f}%"],['','Approaches',f"{cat['approach']*100:.0f}%"],['','Chips, pitches, bunker shots',f"{cat['short']*100:.0f}%"]])+note('In the quarter of rounds with the highest success rate, players beat the field by <b>2 strokes</b>; in the lowest quarter they lost to it by 2. One number, every shot.'),1.15)+
card('Top 5 · 12 rounds or more',tbl(['#','Player','Success'],[[i+1,nm(n),f"{v*100:.1f}%"] for i,(v,n) in enumerate(sr)])+note('The best players are only about three points above the tour. Golf is won on a few shots a round.'))+'</div>',
'Expected strokes to hole out from every lie (tee, fairway, rough, sand, recovery, green) and distance band, from the 8 events themselves. A success = strokes gained of zero or better on that shot.'))
g=ID['goe_top']
S.append(paper(14,'Greens Over Expected','— Idea 2 · from the NFL’s completion % over expected','Greens hit, against the<br>greens the shot allowed.','Approaches from 50 to 250 yards',
'<div style="display:flex;gap:12px;flex:1;min-height:0;">'+
card('What we found',f'<p class="bd" style="margin-bottom:9px;">From <b>150–175 yards</b> the tour finds the green <b>{ID["goe_ex"]["fw150"][0]*100:.0f}%</b> of the time from the fairway and <b>{ID["goe_ex"]["rough150"][0]*100:.0f}%</b> from the rough. A 60% week from the rough is a good week; from the fairway it is not.</p><p class="bd">The best quarter of rounds on this stat beat the field by about <b>1 stroke</b>; the worst lost to it by 1. That is half the swing of success rate, because the putter still decides what a green is worth.</p>')+
card('Top 5 · greens above expected, per round',tbl(['#','Player','Extra greens a round','Approaches'],[[i+1,nm(n),f"+{v:.2f}",c] for i,(v,n,c) in enumerate(g)])+note('Daniel Berger finds about one green a round more than the tour would from the same shots.'))+'</div>',
'Expected = the tour’s green rate by lie and 25-yard band. Par-3 tee shots included; greenside shots inside 50 yards are the short game.'))
go=ID['go']
rows=[[k.split()[0],k.split()[1],v[0],v[1],f"{v[2]:+.2f}".replace('-','−'),(f"{v[3]:+.2f}".replace('-','−') if v[3] is not None else '—')] for k,v in go.items() if v[0]>=50 and v[1]>=15]
S.append(paper(15,'The Go Line, Graded','— Idea 3 · from the NFL’s fourth-down bot','On tour, going for a par 5<br>beats laying up.','Par-5 second shots, 200–300 yards',
'<div style="display:flex;gap:12px;flex:1;min-height:0;">'+
card('Hole score to par: go vs lay-up',tbl(['From','Yards','Went','Laid up','Go','Lay-up'],rows)+note('Going = the second shot finished inside 50 yards. Tour players go far more often than they lay up, and score about four tenths of a stroke better when they do.'),1.3)+
card('Top 5 · par-5 second shots, strokes gained a shot',tbl(['#','Player','Strokes gained a shot','Shots'],[[i+1,nm(n),f"+{v:.2f}",c] for i,(v,n,c) in enumerate(ID['go_top'])])+note('Decision and execution together, 15 shots or more. Adam Scott gains about a stroke for every six par-5 second shots.'))+'</div>',
'A tour finding, not a rule change: lay-ups are often forced (a hazard, a bad lie), so part of the gap is the situation. Our rule 2 stays as written for our players: go at 40% greens from the band, or when the miss finishes inside 40 yards.'))
S.append(paper(16,'Leverage','— Idea 4 · from win probability and leverage','Sunday takes back most<br>of a contender’s edge.','Final rounds started within 3 of the lead',
'<div style="display:flex;gap:12px;flex:1;min-height:0;">'+
card('What we found',f'<p class="bd" style="margin-bottom:9px;">{ID["lev_n"]} players started a final round within 3 of the lead. Through three rounds they averaged <b>{-ID["lev_r13"]:.2f} strokes better</b> than the field a round. On Sunday they were <b>{ID["lev_r4"]:.2f} worse</b>.</p><p class="bd">Part of that is a hot start returning to normal; part is pressure. Either way, the final round is where the edge is won or lost, and where a leverage-weighted Clutch Factor Closing would count most.</p>')+
card('Top 5 Sunday closes · one round each',tbl(['#','Player','Strokes better than field'],[[i+1,nm(n),f"{v:.1f}"] for i,(v,n,c) in enumerate(ID['lev_top'])])+note('Gotterup (Sony), Morikawa (Pebble) and Echavarria (Cognizant) won those weeks.'))+'</div>',
'Leaders and gaps from the cards of every made-cut player. One round each: a season of Sundays is needed before this is a player stat.'))
ff=ID['ff_share']
S.append(paper(17,'Four Factors','— Idea 5 · from Dean Oliver’s Four Factors','Rule 5’s chain, priced:<br>the putter weighs most.','Each factor’s share of a round’s score',
'<div style="display:flex;gap:12px;flex:1;min-height:0;">'+
card('What each factor is worth',tbl(['','Factor','Share','Tour average'],[['','Tee shots in play',f"{ff[0]*100:.0f}%",f"{ID['ff_mu'][0]*100:.0f}%"],['','Greens in regulation',f"{ff[1]*100:.0f}%",f"{ID['ff_mu'][1]*18:.1f} of 18"],['','Scrambling',f"{ff[2]*100:.0f}%",f"{ID['ff_mu'][2]*100:.0f}%"],['','Putts per green hit',f"{ff[3]*100:.0f}%",f"{ID['ff_mu'][3]:.2f}"]])+note(f'Together the four account for about <b>7 in 10</b> of the strokes that separate a good round from a bad one. The tee shot’s value runs through the greens: once greens are counted, it adds almost nothing on its own. That is rule 5’s chain: the earliest link is the cause.'),1.2)+
card('Top 5 · strokes better than the field from the four',tbl(['#','Player','Strokes better than field, a round'],[[i+1,nm(n),f"{v:.2f}"] for i,(v,n) in enumerate(ID['ff_top'])]))+'</div>',
'Share = how much of the difference between rounds each factor accounts for, with all four measured together on 1,906 rounds. In play off the tee = no penalty, no bunker, no recovery lie.'))
lr=ID['luck_rel']
S.append(paper(18,'Putting Luck','— Idea 6 · from the NBA’s luck measures','Long putts are mostly luck.<br>Short putts repeat.','Putts holed over expected',
'<div style="display:flex;gap:12px;flex:1;min-height:0;">'+
card('Does it carry over?',f'<p class="bd" style="margin-bottom:9px;">We split the 40 regular players into hot and cold putters over the first four events, then watched the last four. <b>Inside 15 feet</b>, the hot putters stayed ahead of the cold ones. <b>From 15 feet and beyond</b>, hot and cold finished level: the hot streak disappeared.</p><p class="bd">A hot week from long range should not change the plan. A good week from short range is a skill to protect: inside 6 feet is sacred.</p>')+
card('Top 5 · inside 15 ft, holed over expected a round',tbl(['#','Player','Extra putts holed, a round'],[[i+1,nm(n),f"+{v:.2f}"] for i,(v,n) in enumerate(ID['luck_short_top'])])+note('The repeatable one.'))+
card('Top 5 · 15 ft and beyond',tbl(['#','Player','Extra putts holed, a round'],[[i+1,nm(n),f"+{v:.2f}"] for i,(v,n) in enumerate(ID['luck_long_top'])])+note('Mostly luck: expect it to fall back.'))+'</div>',
'Expected = the tour’s make rate by distance band. Carry-over among players with 12+ rounds and 40+ putts in each half.'))
# 13 decisions
S.append(paper(19,'Decisions','— Where today landed','Decided, and still open.','RC, 18 Nov',
'<div style="display:flex;gap:12px;flex:1;min-height:0;">'+
card('Decided',f'<p class="bd" style="margin-bottom:6px;">· All of it is the <b>Clutch Factor Family</b>, internally.</p><p class="bd" style="margin-bottom:6px;">· Clutch Rating weights a comeback at <b>¾</b> of a clean hole.</p><p class="bd" style="margin-bottom:6px;">· The comeback stat is <b>Comeback Factor</b>.</p><p class="bd" style="margin-bottom:6px;">· The total is <b>Strokes Above The Cut</b>.</p><p class="bd" style="margin-bottom:6px;">· Internal tour study only; posts stay nameless.</p><p class="bd">· The Rule Plus/Minus carousel is built; it posts on your OK.</p>')+
card('Still open',f'<p class="bd" style="margin-bottom:6px;">· The full-season pull (paused).</p><p class="bd" style="margin-bottom:6px;">· Missed-cut rounds, so the cut-line player is measured, not estimated.</p><p class="bd" style="margin-bottom:6px;">· The new stats on a Season Report for our players.</p><p class="bd" style="margin-bottom:6px;">· The published Clutch Factor names, folded into the family in one rev.</p><p class="bd">· Which of the six new ideas join the family.</p>')+'</div>',
'Files: research/season-2026/clutch-rating/ (scripts), deliverables/ (decks).'))
out=head.replace('Clutch Rating · Tour Study','Clutch Factor Family')+'<deck-stage width="1056" height="816" no-rail>\n'+'\n'.join(S)+'\n</deck-stage>\n</body>\n</html>\n'
open('/home/user/rc-greenlight/deliverables/Clutch Factor Family - 2026 Tour Study.html','w').write(out)
print('ok')
