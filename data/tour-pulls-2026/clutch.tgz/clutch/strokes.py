import json,os,re,collections,statistics as S
B='/tmp/claude-0/-home-user/c0cfce94-7d29-53ae-a568-1ec015f2a64a/scratchpad/season-pga/'
EV=['R2026006','R2026002','R2026004','R2026003','R2026005','R2026007','R2026010','R2026457']
def yd(s):
    s=(s or '').strip()
    if not s: return None
    m=re.match(r'^([\d,.]+) yds?$',s)
    if m: return float(m.group(1).replace(',',''))
    ft=re.search(r'([\d.]+) ft',s); inch=re.search(r'([\d.]+) in',s)
    if ft or inch: return ((float(ft.group(1)) if ft else 0)+(float(inch.group(1)) if inch else 0)/12)/3
    return None
def lc(n):
    n=(n or '').replace('Left ','').replace('Right ','')
    if n in('Tee Box',): return 'Tee'
    if n=='Green': return 'Green'
    if 'Bunker' in n: return 'Sand'
    if n=='Fairway': return 'Fairway'
    if n in('Rough','Intermediate','Primary Rough','Intermediate Rough'): return 'Rough'
    if n=='Water': return 'Water'
    if not n: return ''
    return 'Recovery'
REC=('Recovery','Water')
out=[]
for e in EV:
    lb={p['id']:p for p in json.load(open(B+e+'/leaderboard.json'))['data']['players']}
    for f in sorted(os.listdir(B+e+'/raw')):
        pid,rnd=f[:-5].split('-'); d=json.load(open(B+e+'/raw/'+f))['data']; holes=d['holes']
        if len(holes)!=18 or any(s['strokeType']=='STROKE' and not s.get('finalStroke') and not s.get('toLocation') for h in holes for s in h['strokes']): continue
        nm=lb.get(pid,{}).get('displayName',pid); pos=lb.get(pid,{}).get('position')
        for h in holes:
            par=int(h['par']); score=int(h['score']); hy=float(h['yardage'])
            st=[s for s in h['strokes'] if s['strokeType']!='DROP']
            prev=hy; used=0; seq=[]
            for i,s in enumerate(st):
                if s['strokeType']=='PENALTY': continue
                frm=lc(s.get('fromLocation')); n=int(s['strokeNumber'])
                start=hy if (frm=='Tee' and n==1) else prev
                rem=yd(s.get('distanceRemaining')); holed=bool(s.get('finalStroke'))
                nxt=st[i+1] if i+1<len(st) else None; pen=int(nxt is not None and nxt['strokeType']=='PENALTY')
                to='Hole' if holed else lc(s.get('toLocation'))
                seq.append(dict(n=n,frm=frm,start=start,to=to,end=0 if holed else rem,pen=pen))
                if rem is not None: prev=rem
            # strokes remaining from each shot = score - (stroke number) + 1
            for k in seq: k['left']=score-k['n']+1
            out.append(dict(ev=e,pid=pid,name=nm,pos=pos,rnd=rnd,hole=h['holeNumber'],par=par,score=score,yards=hy,shots=seq))
json.dump(out,open('holeshots.json','w')); print(len(out))
