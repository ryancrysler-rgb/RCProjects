import json,collections,statistics as S,math
H=json.load(open('holes.json')); T=json.load(open('tests.json')); rd=json.load(open('rounds.json'))
MIN=12
def corr(x,y):
    mx,my=S.mean(x),S.mean(y); return sum((a-mx)*(b-my) for a,b in zip(x,y))/math.sqrt(sum((a-mx)**2 for a in x)*sum((b-my)**2 for b in y))
def posn(p):
    try: return int(str(p).replace('T',''))
    except: return 999
K=lambda a:(a['ev'],a['pid'],a['rnd'])
X=collections.defaultdict(float); A=collections.Counter(); NT=collections.Counter(); B=collections.Counter()
for t in T: k=(t['ev'],t['pid'],t['rnd']); X[k]+=t['x']; A[k]+=t['cb']; NT[k]+=1
F=collections.defaultdict(list)
for h in H: F[(h['ev'],h['rnd'],h['hole'])].append(h['rel'])
fm={k:S.mean(v) for k,v in F.items()}
PM=collections.defaultdict(lambda:[0,0,0,0])  # clean pm sum, clean n, test pm sum, test n
for h in H:
    pm=fm[(h['ev'],h['rnd'],h['hole'])]-h['rel']; k=(h['ev'],h['pid'],h['rnd'])
    if h['rel']<0: B[k]+=1
    if h['bad']: PM[k][2]+=pm; PM[k][3]+=1
    else: PM[k][0]+=pm; PM[k][1]+=1
for a in rd:
    k=K(a); a['x']=X[k]; a['cbx']=A[k]-X[k]; a['bird']=B[k]; a['pm']=PM[k]
rep=[a for a in rd if posn(a['pos'])>=50]; r={k:S.mean(a[k] for a in rep) for k in ['tests','cbx','lost','bird','vs']}
VT,VC,VL=0.634,1.27,1.18
P=collections.defaultdict(list)
for a in rd: P[a['pid']].append(a)
pl=[]
for pid,l in P.items():
    if len(l)<MIN: continue
    n=len(l); m=lambda k:sum(a[k] for a in l)/n
    cr=m('clean')+.75*m('x')+(m('cb')-m('x'))-m('lost')
    xs=sum(a['x'] for a in l); cf=100*sum(a['cb'] for a in l)/xs if xs else 0
    cs=sum(a['pm'][0] for a in l); cn=sum(a['pm'][1] for a in l); ts=sum(a['pm'][2] for a in l); tn=sum(a['pm'][3] for a in l)
    sac=(r['tests']-m('tests'))*VT+(m('cbx')-r['cbx'])*VC+(r['lost']-m('lost'))*VL+(m('bird')-r['bird'])
    pl.append(dict(name=l[0]['name'],rounds=n,cr=cr,cf=cf,tests=sum(a['tests'] for a in l),pm=(cs+ts)/n,pmc=cs/cn,pmt=ts/tn if tn else 0,sac=sac,
                   av=(r['tests']-m('tests'))*VT,cfs=(m('cbx')-r['cbx'])*VC,dm=(r['lost']-m('lost'))*VL,bd=m('bird')-r['bird'],act=r['vs']-m('vs')))
for key in ['cr','cf','pm','sac']:
    for i,p in enumerate(sorted(pl,key=lambda p:-p[key]),1): p['r_'+key]=i
print('players',len(pl),'corr sac vs actual',round(corr([p['sac'] for p in pl],[p['act'] for p in pl]),3))
for key in ['cr','cf','pm','sac']:
    print(key,[(p['name'],round(p[key],2)) for p in sorted(pl,key=lambda p:-p[key])[:6]])
for p in sorted(pl,key=lambda p:p['r_cr']+p['r_cf']+p['r_pm']+p['r_sac'])[:10]: print(' all-four',p['name'],p['r_cr'],p['r_cf'],p['r_pm'],p['r_sac'],p['rounds'])
print('pmc',[(p['name'],round(p['pmc'],2)) for p in sorted(pl,key=lambda p:-p['pmc'])[:5]]); print('pmt',[(p['name'],round(p['pmt'],2)) for p in sorted(pl,key=lambda p:-p['pmt'])[:5]])
json.dump(dict(pl=pl,rep=r),open('four.json','w'))
