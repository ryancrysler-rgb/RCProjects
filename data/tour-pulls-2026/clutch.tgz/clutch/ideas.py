import json,collections,statistics as S,math,bisect
import numpy as np
HS=json.load(open('holeshots.json'))
GB=[1,2,3,4,5,6,8,10,13,16,20,25,30,40,60,90,1e9]; YB=[10,20,30,40,50,75,100,125,150,175,200,225,250,300,350,400,450,500,1e9]
def band(lie,d):
    if lie=='Green': return ('G',bisect.bisect_left(GB,d*3))
    return (lie,bisect.bisect_left(YB,d))
def L(l): return 'Recovery' if l in('Water','') else l
def corr(x,y):
    mx,my=S.mean(x),S.mean(y); return sum((a-mx)*(b-my) for a,b in zip(x,y))/math.sqrt(sum((a-mx)**2 for a in x)*sum((b-my)**2 for b in y))
# expected strokes
acc=collections.defaultdict(list)
for h in HS:
    for k in h['shots']:
        if k['start'] is None: continue
        acc[band(L(k['frm']),k['start'])].append(k['left'])
E={b:S.mean(v) for b,v in acc.items()}
def Ex(lie,d):
    b=band(L(lie),d)
    if b in E: return E[b]
    return None
# per-shot SG
shots=[]
for h in HS:
    sq=h['shots']
    for i,k in enumerate(sq):
        if k['start'] is None: continue
        e0=Ex(k['frm'],k['start'])
        if i+1<len(sq):
            nx=sq[i+1]
            if nx['start'] is None: continue
            e1=Ex(nx['frm'],nx['start'])
        else: e1=0
        if e0 is None or e1 is None: continue
        sg=e0-e1-1-k['pen']
        cat='putt' if k['frm']=='Green' else ('tee' if k['frm']=='Tee' and h['par']>=4 else ('short' if k['start']<=50 else 'approach'))
        shots.append(dict(ev=h['ev'],pid=h['pid'],name=h['name'],rnd=h['rnd'],hole=h['hole'],par=h['par'],n=k['n'],cat=cat,sg=sg,frm=L(k['frm']),start=k['start'],to=k['to'],end=k['end'],h=h))
print('shots',len(shots),'mean sg',round(S.mean(s['sg'] for s in shots),4))
# round score vs field
RS=collections.defaultdict(int); 
for h in HS: RS[(h['ev'],h['pid'],h['rnd'])]+=h['score']-h['par']
FM=collections.defaultdict(list)
for (e,p,r),v in RS.items(): FM[(e,r)].append(v)
VS={k:v-S.mean(FM[(k[0],k[2])]) for k,v in RS.items()}
NAME={h['pid']:h['name'] for h in HS}
RNDS=collections.Counter((h['pid']) for h in HS if h['hole']==1)
ELIG=lambda pid:RNDS[pid]>=12
R={}
# 1 success rate
SR=collections.defaultdict(lambda:[0,0]); SRc=collections.defaultdict(lambda:collections.defaultdict(lambda:[0,0])); SRr=collections.defaultdict(lambda:[0,0])
for s in shots:
    ok=int(s['sg']>=0); SR[s['pid']][0]+=ok; SR[s['pid']][1]+=1; SRc[s['cat']][s['pid']][0]+=ok; SRc[s['cat']][s['pid']][1]+=1
    k=(s['ev'],s['pid'],s['rnd']); SRr[k][0]+=ok; SRr[k][1]+=1
tour={c:sum(v[0] for v in d.values())/sum(v[1] for v in d.values()) for c,d in SRc.items()}
allr=sum(v[0] for v in SR.values())/sum(v[1] for v in SR.values())
ks=[k for k in SRr if k in VS]; R['sr_corr']=corr([SRr[k][0]/SRr[k][1] for k in ks],[-VS[k] for k in ks])
R['sr_tour']=allr; R['sr_cat']=tour
R['sr_top']=sorted([(SR[p][0]/SR[p][1],NAME[p]) for p in SR if ELIG(p)],reverse=True)[:5]
print('1 success',round(allr,3),{c:round(v,3) for c,v in tour.items()},'corr',round(R['sr_corr'],2),R['sr_top'])
# 2 greens over expected
gk=collections.defaultdict(lambda:[0,0])
cand=[s for s in shots if s['frm']!='Green' and 50<s['start']<=250]
for s in cand: gk[band(s['frm'],s['start'])][0]+= int(s['to'] in('Green','Hole')); gk[band(s['frm'],s['start'])][1]+=1
GOE=collections.defaultdict(float); GN=collections.Counter(); GOEr=collections.defaultdict(float)
for s in cand:
    a,n=gk[band(s['frm'],s['start'])]; x=a/n; g=int(s['to'] in('Green','Hole'))
    GOE[s['pid']]+=g-x; GN[s['pid']]+=1; GOEr[(s['ev'],s['pid'],s['rnd'])]+=g-x
ks=[k for k in VS]; R['goe_corr']=corr([GOEr.get(k,0) for k in ks],[-VS[k] for k in ks])
R['goe_top']=sorted([(GOE[p]/RNDS[p],NAME[p],GN[p]) for p in GOE if ELIG(p)],reverse=True)[:5]
fw=[(k,v[0]/v[1],v[1]) for k,v in gk.items() if v[1]>=150]
R['goe_ex']={'fw150':[round(v,3) for k,v,n in fw if k==('Fairway',bisect.bisect_left(YB,160))],'rough150':[round(v,3) for k,v,n in fw if k==('Rough',bisect.bisect_left(YB,160))]}
print('2 GOE corr',round(R['goe_corr'],2),[(n,round(v,2),c) for v,n,c in R['goe_top']],R['goe_ex'])
# 3 go line: par-5 second shot from fairway/rough 200-300
P5=[s for s in shots if s['par']==5 and s['n']==2 and s['frm'] in('Fairway','Rough') and 200<s['start']<=300 and s['end'] is not None]
tab=collections.defaultdict(lambda:{'go':[],'lay':[]})
for s in P5:
    b=int((s['start']-200)//25)*25+200
    tab[(s['frm'],b)]['go' if s['end']<=50 else 'lay'].append(s['h']['score']-5)
R['go']={f"{k[0]} {k[1]}-{k[1]+25}":(len(v['go']),len(v['lay']),round(S.mean(v['go']),2) if v['go'] else None,round(S.mean(v['lay']),2) if v['lay'] else None) for k,v in sorted(tab.items())}
print('3 go',R['go'])
P5p=collections.defaultdict(list)
for s in P5: P5p[s['pid']].append(s['sg'])
R['go_top']=sorted([(S.mean(v),NAME[p],len(v)) for p,v in P5p.items() if len(v)>=15 and ELIG(p)],reverse=True)[:5]
print('   top',R['go_top'])
# 4 leverage: final-round contenders
by=collections.defaultdict(dict)
for (e,p,r),v in RS.items(): by[(e,p)][r]=v
cont=[]
for e in set(k[0] for k in RS):
    tot={p:sum(d[r] for r in('1','2','3')) for (ee,p),d in by.items() if ee==e and all(r in d for r in('1','2','3','4'))}
    if not tot: continue
    lead=min(tot.values())
    for p,t in tot.items():
        if t-lead<=3: cont.append((e,p,t-lead,VS[(e,p,'4')],S.mean(VS[(e,p,r)] for r in('1','2','3'))))
R['lev_n']=len(cont); R['lev_r4']=S.mean(c[3] for c in cont); R['lev_r13']=S.mean(c[4] for c in cont)
CP=collections.defaultdict(list)
for c in cont: CP[c[1]].append(c)
R['lev_top']=sorted([(S.mean(-c[3] for c in v),NAME[p],len(v)) for p,v in CP.items()],reverse=True)[:5]
print('4 contenders',len(cont),'R4 vs field',round(R['lev_r4'],2),'their R1-3',round(R['lev_r13'],2),R['lev_top'])
# 5 four factors per round
F=collections.defaultdict(lambda:dict(tee=0,teen=0,gir=0,holes=0,scr=0,miss=0,putt_gir=0))
for h in HS:
    k=(h['ev'],h['pid'],h['rnd']); f=F[k]; f['holes']+=1; sq=h['shots']
    if h['par']>=4 and sq:
        t=sq[0]; nxt=sq[1]['frm'] if len(sq)>1 else 'Fairway'
        f['teen']+=1; f['tee']+=int(not t['pen'] and L(t['to']) not in('Recovery','Sand') and L(nxt) not in('Recovery','Sand'))
    gir=any((k2['to'] in('Green','Hole')) and k2['n']<=h['par']-2 for k2 in sq)
    if gir:
        f['gir']+=1; f['putt_gir']+=sum(1 for k2 in sq if k2['frm']=='Green')
    else:
        f['miss']+=1; f['scr']+=int(h['score']<=h['par'])
ks=[k for k in F if k in VS and F[k]['teen'] and F[k]['gir'] and F[k]['miss']]
X=np.array([[F[k]['tee']/F[k]['teen'],F[k]['gir']/18,F[k]['scr']/F[k]['miss'],F[k]['putt_gir']/F[k]['gir']] for k in ks]); y=np.array([-VS[k] for k in ks])
mu=X.mean(0); sd=X.std(0); Z=(X-mu)/sd; A=np.c_[Z,np.ones(len(Z))]; coef,*_=np.linalg.lstsq(A,y,rcond=None)
pred=A@coef; r2=1-((y-pred)**2).sum()/((y-y.mean())**2).sum()
R['ff_coef']=[round(c,3) for c in coef[:4]]; R['ff_r2']=r2; R['ff_mu']=mu.tolist(); R['ff_sd']=sd.tolist()
share=np.abs(coef[:4])/np.abs(coef[:4]).sum(); R['ff_share']=share.tolist()
print('5 four factors coef per sd',R['ff_coef'],'share',[round(x,2) for x in share],'r2',round(r2,2),'means',[round(x,3) for x in mu],'sd',[round(x,3) for x in sd])
PF=collections.defaultdict(list)
for i,k in enumerate(ks): PF[k[1]].append(pred[i]-coef[4])
R['ff_top']=sorted([(S.mean(v),NAME[p]) for p,v in PF.items() if ELIG(p)],reverse=True)[:5]
print('   top',R['ff_top'])
# 6 putting luck
pk=collections.defaultdict(lambda:[0,0])
putts=[s for s in shots if s['frm']=='Green']
fb=lambda d:bisect.bisect_left(GB,d*3)
for s in putts: pk[fb(s['start'])][0]+=int(s['to']=='Hole'); pk[fb(s['start'])][1]+=1
order=['R2026006','R2026002','R2026004','R2026003','R2026005','R2026007','R2026010','R2026457']; first=set(order[:4])
half=collections.defaultdict(lambda:collections.defaultdict(lambda:[0.0,0]))
for s in putts:
    a,n=pk[fb(s['start'])]; ox=int(s['to']=='Hole')-a/n; zone='long' if s['start']*3>=15 else 'short'
    hk=(s['pid'],0 if s['ev'] in first else 1,zone); half[hk]['x'][0]+=ox; half[hk]['x'][1]+=1
rel={}
for zone in ['short','long']:
    xs=[];ys=[]
    for p in set(k[0] for k in half):
        a=half[(p,0,zone)]['x']; b=half[(p,1,zone)]['x']
        if RNDS[p]>=12 and a[1]>=40 and b[1]>=40: xs.append(a[0]/a[1]); ys.append(b[0]/b[1])
    rel[zone]=(round(corr(xs,ys),2),len(xs))
R['luck_rel']=rel
LP=collections.defaultdict(float); SP=collections.defaultdict(float)
for s in putts:
    a,n=pk[fb(s['start'])]; ox=int(s['to']=='Hole')-a/n
    if s['start']*3>=15: LP[s['pid']]+=ox
    else: SP[s['pid']]+=ox
R['luck_long_top']=sorted([(LP[p]/RNDS[p],NAME[p]) for p in LP if ELIG(p)],reverse=True)[:5]
R['luck_short_top']=sorted([(SP[p]/RNDS[p],NAME[p]) for p in SP if ELIG(p)],reverse=True)[:5]
print('6 luck reliability',rel,'long top',R['luck_long_top'],'short top',R['luck_short_top'])
json.dump(R,open('ideas.json','w'),default=float)
