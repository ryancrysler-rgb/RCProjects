import json,collections,statistics as S,math,random
rows=json.load(open('holes.json'))
R=collections.defaultdict(list)
for r in rows: R[(r['ev'],r['pid'],r['rnd'])].append(r)
def agg(hs):
    c=collections.Counter(h['cls'] for h in hs); n=len(hs)
    tests=c['comeback']+c['bogey saved']+c['lost']
    return dict(n=n,clean=c['clean'],cb=c['comeback'],bs=c['bogey saved'],lost=c['lost'],quiet=c['quiet bogey']+c['quiet double'],tests=tests,rel=sum(h['rel'] for h in hs))
rd=[]
for k,hs in R.items():
    a=agg(hs); a.update(ev=k[0],pid=k[1],rnd=k[2],name=hs[0]['name'],pos=hs[0]['pos']); rd.append(a)
# field mean per event-round
fm=collections.defaultdict(list)
for a in rd: fm[(a['ev'],a['rnd'])].append(a['rel'])
for a in rd: a['vs']=a['rel']-S.mean(fm[(a['ev'],a['rnd'])])
def corr(x,y):
    mx,my=S.mean(x),S.mean(y); sx=math.sqrt(sum((a-mx)**2 for a in x)); sy=math.sqrt(sum((b-my)**2 for b in y)); return sum((a-mx)*(b-my) for a,b in zip(x,y))/(sx*sy)
vs=[a['vs'] for a in rd]
M={'kept (par or better)':lambda a:a['clean']+a['cb'],'clean holes':lambda a:a['clean'],'tests (holes with a bad shot)':lambda a:a['tests'],'comebacks':lambda a:a['cb'],'comeback rate':lambda a:a['cb']/a['tests'] if a['tests'] else None,'lost (double+) after a bad shot':lambda a:a['lost']}
print('ROUND LEVEL (n=%d): correlation with score vs field that round (negative = lower score)'%len(rd))
for k,f in M.items():
    p=[(f(a),a['vs']) for a in rd if f(a) is not None]; print(' ',k,round(corr([x for x,_ in p],[y for _,y in p]),2))
# tests explain: regress vs on clean & cb rate? show by tests bucket
print('BY TESTS IN A ROUND: rounds, avg vs field, avg comeback rate')
B=collections.defaultdict(list)
for a in rd: B[min(a['tests'],9)].append(a)
for t in sorted(B): print(' ',t,len(B[t]),round(S.mean(a['vs'] for a in B[t]),2),round(S.mean(a['cb']/a['tests'] for a in B[t]) if t else 0,2))
# winners vs field (player-event)
PE=collections.defaultdict(list)
for a in rd: PE[(a['ev'],a['pid'])].append(a)
def pe(lst):
    n=sum(a['n'] for a in lst); t=sum(a['tests'] for a in lst)
    return dict(rounds=len(lst),clean18=sum(a['clean'] for a in lst)/n*18,tests18=t/n*18,cbr=sum(a['cb'] for a in lst)/t if t else 0,kept18=sum(a['clean']+a['cb'] for a in lst)/n*18,lost18=sum(a['lost'] for a in lst)/n*18,bs=sum(a['bs'] for a in lst)/t if t else 0)
W=[];F=[]
print('WINNERS (4 counted rounds) vs FIELD')
for (ev,pid),lst in PE.items():
    x=pe(lst)
    if lst[0]['pos']=='1' and len(lst)==4: W.append(x); print('  ',ev,lst[0]['name'],{k:round(v,2) for k,v in x.items()})
    elif len(lst)==4: F.append(x)
for nm,G in [('winners',W),('field',F)]:
    print(' ',nm,len(G),{k:round(S.mean(g[k] for g in G),2) for k in ['clean18','tests18','cbr','bs','kept18','lost18']})
# top 10 finishers vs rest
def posn(p):
    try: return int(str(p).replace('T',''))
    except: return 999
T10=[pe(l) for (ev,pid),l in PE.items() if len(l)==4 and posn(l[0]['pos'])<=10]
REST=[pe(l) for (ev,pid),l in PE.items() if len(l)==4 and posn(l[0]['pos'])>10]
for nm,G in [('top 10',T10),('11th+',REST)]: print(' ',nm,len(G),{k:round(S.mean(g[k] for g in G),2) for k in ['clean18','tests18','cbr','kept18','lost18']})
# reliability: split events into two halves per player, correlate
P=collections.defaultdict(lambda: collections.defaultdict(list))
evs=sorted(set(a['ev'] for a in rd))
half={e:i%2 for i,e in enumerate(evs)}
for a in rd: P[a['pid']][half[a['ev']]].append(a)
for key in ['clean18','tests18','cbr','kept18']:
    xs=[];ys=[]
    for pid,h in P.items():
        if sum(a['n'] for a in h[0])>=108 and sum(a['n'] for a in h[1])>=108:
            xs.append(pe(h[0])[key]); ys.append(pe(h[1])[key])
    print('SPLIT-HALF reliability',key,len(xs),round(corr(xs,ys),2))
# season board
SP=collections.defaultdict(list)
for a in rd: SP[a['pid']].append(a)
board=[]
for pid,l in SP.items():
    if len(l)>=16:
        x=pe(l); x['name']=l[0]['name']; x['events']=len(set(a['ev'] for a in l)); x['tests']=sum(a['tests'] for a in l); x['cb']=sum(a['cb'] for a in l); x['vs']=S.mean(a['vs'] for a in l); board.append(x)
json.dump(board,open('board.json','w'))
print('BOARD players >=16 rounds:',len(board))
for key,lab,rev in [('kept18','KEPT/18',True),('cbr','COMEBACK RATE',True),('clean18','CLEAN/18',True),('tests18','FEWEST TESTS',False)]:
    print('--',lab)
    for i,x in enumerate(sorted(board,key=lambda x:-x[key] if rev else x[key])[:10],1):
        print('  ',i,x['name'],x['rounds'],'rds', 'kept',round(x['kept18'],2),'clean',round(x['clean18'],2),'tests',round(x['tests18'],2),'cb%',round(x['cbr']*100,1),'(%d/%d)'%(x['cb'],x['tests']),'lost',round(x['lost18'],2),'vs field',round(x['vs'],2))
json.dump(rd,open('rounds.json','w'))
