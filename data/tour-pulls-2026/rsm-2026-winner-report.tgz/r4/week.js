// The winner's week: page 2 over all four rounds (R1 Plantation from the 10th, R2-R4 Seaside).
const path=require('path'),fs=require('fs');const ROOT='/home/user/rc-greenlight';const A=f=>require(path.join(ROOT,'automation',f));
const SC=A('shot-csv.js'),SR=A('summary-rules.js'),SLOT=A('data-slot.js'),BC=A('bag-clubs.js');
const BAG=JSON.parse(fs.readFileSync(__dirname+'/bag.json','utf8'));const S=__dirname+'/..';
const R=[[1,'889',10,68,72],[2,'776',1,65,70],[3,'776',1,68,70],[4,'776',1,65,70]];
const rounds=R.map(([n,cid,st])=>{const H=SC.parse(fs.readFileSync(`${S}/51003-r${n}.csv`,'utf8')).holes;H._bag=BC.apply(H,BAG.bag);
 const c=JSON.parse(fs.readFileSync(`${S}/pull/cs${n}.json`,'utf8')).data.courses.find(x=>x.courseId===cid);
 for(const h of H){const fh=c.holes.find(x=>x.holeNumber===h.hole);if(fh&&fh.par===h.par)h.vfld=String(Math.round((fh.scoringAverage-h.score)*1000)/1000);}
 return {n,holes:H,source:'files',order:Array.from({length:18},(_,i)=>((st-1+i)%18)+1)};});
const P=SR.page(rounds,{units:'yd',wedgeMaxYd:BAG.wedgeMaxYd});
P.notes=P.notes.map(n=>/stored files/.test(n)?'R1–R4: pgatour.com (R2026493; R1 Plantation par 72 from the 10th, R2–R4 Seaside par 70), every hole matching the card (68-65-68-65, −16); field = each course’s hole averages that round; the playoff is not in the shot data':n).filter(n=>!/playing order from hole/.test(n));
P.notes.push('clubs: a standard tour set at TrackMan tour-average carries, an estimate (no set makeup read)');
for(const g of P.groups)for(const r of g.rules)for(const row of r.rows)if(/^Misses on the long side/.test(row.label||'')){row.label='Misses long / open side';row.why='no pins';}
P.notes=P.notes.filter(n=>!/^not measured: the long side/.test(n)&&!/^long par 4s: a reading/.test(n));
const t2=fs.readFileSync(path.join(ROOT,'automation/tournament-summary.template.html'),'utf8');
fs.writeFileSync(__dirname+'/week.html',SLOT.fill(t2,{player:'Marco Penge',event:'RSM Classic 2026 · The winner’s week',rounds:4,roundNumbers:[1,2,3,4],scores:[68,65,68,65],total:266,par:282,facets:{},holes:[],swot:{},rulesPage:P},'tournament summary'));
console.log(P.read.headline,'|',JSON.stringify(P.read.next));
const { chromium } = require('playwright');
(async()=>{const b=await chromium.launch();const p=await b.newPage({viewport:{width:1000,height:1300},deviceScaleFactor:2});
 await p.goto('file://'+__dirname+'/week.html');await p.waitForTimeout(1500);
 await p.addStyleTag({content:'#savepdf{display:none!important} #sheet{display:none!important}'});
 await p.evaluate(()=>{const s=document.querySelector('#sheet2');const box=[...s.querySelectorAll('div')].find(e=>/Clutch Factor Damage Control/.test(e.textContent)&&e.children.length===2&&getComputedStyle(e).overflow==='hidden');const inner=box.children[1];const z=Math.min(1,(box.clientHeight-box.children[0].offsetHeight-4)/inner.scrollHeight);inner.style.zoom=z;});
 await (await p.$('#sheet2')).screenshot({path:__dirname+'/week.png'});
 await p.emulateMedia({media:'print'});await p.pdf({path:__dirname+'/week.pdf',width:'8.5in',height:'11in',printBackground:true});await b.close();})();
