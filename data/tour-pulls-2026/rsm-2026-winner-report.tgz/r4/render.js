const { launch, serve, context } = require('/home/user/rc-greenlight/tools/tests/_lib');
const fs=require('fs');const { chromium } = require('playwright');
(async()=>{const srv=await serve(),b=await launch();
 for (const [pid,name] of [['51003','Marco Penge']]){
 const D=__dirname+'/'+pid, N=name+' - RSM Classic R4 - Raw';
 const html=fs.readFileSync(D+'/'+N+'.html','utf8').replace(/file:\/\/\/home\/user\/rc-greenlight/g,srv.origin);
 const tmp='/home/user/rc-greenlight/.tmp-r4-'+pid+'.html'; fs.writeFileSync(tmp,html);
 const c=await context(b,{width:900,height:1150});const p=await c.newPage();const errs=[];p.on('pageerror',e=>errs.push(e.message));
 await p.goto(srv.origin+'/.tmp-r4-'+pid+'.html',{waitUntil:'networkidle'});await p.waitForTimeout(1500);
 const info=await p.evaluate(()=>{const s=document.querySelector('.sheet')||document.body;const box=s.getBoundingClientRect();const over=[];
  s.querySelectorAll('*').forEach(e=>{const r=e.getBoundingClientRect();if(r.height&&e.children.length===0&&(r.bottom>box.bottom+1||e.scrollWidth>e.clientWidth+2&&getComputedStyle(e).overflow==='hidden'))over.push((e.textContent||'').slice(0,40));});
  return {h:box.height,w:box.width,over:over.slice(0,8),fit:[...document.documentElement.classList].join(' ')};});
 console.log(pid,JSON.stringify(info),errs);
 await p.screenshot({path:D+'/sheet.png',fullPage:true});
 await p.emulateMedia({media:'print'});await p.pdf({path:D+'/raw.pdf',preferCSSPageSize:true,printBackground:true});
 fs.unlinkSync(tmp);await c.close();
 const q=await (await chromium.launch()).newPage({viewport:{width:1000,height:1300},deviceScaleFactor:2});
 await q.goto('file://'+D+'/p2.html');await q.waitForTimeout(1500);
 await q.addStyleTag({content:'#savepdf{display:none!important} #sheet{display:none!important}'});
 await (await q.$('#sheet2')).screenshot({path:D+'/p2.png'});
 await q.emulateMedia({media:'print'});await q.pdf({path:D+'/p2.pdf',width:'8.5in',height:'11in',printBackground:true});
 await q.context().browser().close();}
 await b.close();await srv.close();})();
