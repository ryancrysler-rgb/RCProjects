const path=require('path'),fs=require('fs');const ROOT='/home/user/rc-greenlight';const A=f=>require(path.join(ROOT,'automation',f));
const SC=A('shot-csv.js'),M=A('metrics.js'),RP=A('round-patterns.js'),RB=A('raw-report-builder.js'),DG=A('decision-gained.js');
const o=JSON.parse(fs.readFileSync('dg.json','utf8'));
const R=[1,2,3,4].map(r=>SC.parse(fs.readFileSync('r'+r+'.csv','utf8')).holes);const H=R[3];
const FLD={};o.course.forEach(c=>{FLD[c.hole]=Math.round((c.avg_4-c.par)*100)/100;});
const hill=Object.keys(o.player_scores).find(k=>(o.main.find(p=>String(p.player_num)===k)||{}).name==='Hill, Calum');
const LOW={};for(let h=1;h<=18;h++)LOW[h]=o.player_scores[hill]['4'][String(h)];
H.forEach(h=>{const f=FLD[h.hole];h.field=(f>0?'+':'')+f;const v=Math.round((f-(h.score-h.par))*100)/100;h.vfld=v===0?'E':(v>0?'+'+v:String(v));const d=LOW[h.hole]-h.score;h.vldr=d===0?'E':(d>0?'+'+d:String(d));});
const sm=M.summary(H);const p=RP.patterns(H,{startHole:1,fieldToPar:FLD});p.response=M.clutchFactorResponse(H,{order:p.order});p.closing=M.clutchFactorClosing(H,{behind:0,order:p.order,fieldToPar:FLD});
const bands=RB.ladderCounts([].concat(...R.slice(0,3)),'yd').map(b=>({lo:b.lo,hi:(b.hi===Infinity||b.hi==null)?null:b.hi,made:b.made,att:b.n})).filter(b=>b.att>0);console.log('ladder bands',JSON.stringify(bands));const good=DG.goodBands(bands);const dg=DG.decisions(H,{girBands:bands,good,tour:true});const ib=DG.inBand(H,good);
const ai=JSON.parse(fs.readFileSync('ai.json','utf8'));
const rd=RB.buildRawReportData({player:'Jon Rahm',event:'Abu Dhabi Aldar Championship 2026 · Round 4',par:72,round:{score:67,toPar:'−5',note:'Won · −23'},
 putts:sm.putts.value,birdies:sm.counts.birdies,holes:H,plan:null,facets:null,summary:sm,patterns:p,
 totals:{fw:sm.fairways.display,par:72,yards:H.reduce((a,h)=>a+(h.yards||0),0)||'',gir:sm.gir.display,putts:sm.putts.value,flags:''},
 footnote:ai.footnote,identity:'RC Greenlight · Raw',decisionGained:dg,inBand:ib,bandsFrom:3,ai});
rd.compKind='low';rd.finalRound=true;
fs.writeFileSync('rd.json',JSON.stringify(rd));
const tpl=fs.readFileSync(path.join(ROOT,'automation/raw-report.template.html'),'utf8');
const out=tpl.replace('<!--__DATA_SLOT__-->','<script>window.__REPORT_DATA='+JSON.stringify(rd).replace(/</g,'\\u003c')+';</script>').replace(/__SITE_URL__/g,'file://'+ROOT);
fs.writeFileSync('Jon Rahm - Abu Dhabi 2026 R4 - Raw.html',out);
console.log('topBottom',JSON.stringify(rd.topBottom&&{best:rd.topBottom.best,worst:rd.topBottom.worst}).slice(0,300));console.log('decision',JSON.stringify(rd.decision));console.log('clutch',JSON.stringify(rd.clutch));
