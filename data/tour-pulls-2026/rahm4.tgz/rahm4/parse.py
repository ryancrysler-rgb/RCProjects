import re,csv,sys
src=open('/root/.claude/uploads/c0cfce94-7d29-53ae-a568-1ec015f2a64a/90eccac7-Jon_Rahm_-_Abu_Dhabi_R1-R4_-_shot_by_shot.txt').read()
H='Hole,Par,Score,Shot,Category,Club,Start Lie,End Lie,Start Distance,Putt Distance,Shot Distance,Proximity,Penalty,Hole Yardage'.split(',')
def ft(s):
    m=re.match(r'([\d.]+)\s*(ft|in)',s); v=float(m.group(1)); return v/12 if m.group(2)=='in' else v
parts=re.split(r'ROUND (\d) · ',src)[1:]
for i in range(0,len(parts),2):
    R=parts[i]; body=parts[i+1]; rows=[]
    for hm in re.finditer(r'Hole (\d+) · Par (\d) · (\d+) yd · (\d+) \(',body):
        h,par,yds,sc=map(int,hm.groups())
        seg=body[hm.end():]; nxt=re.search(r'\nHole \d+ ·|\n====',seg); seg=seg[:nxt.start() if nxt else len(seg)]
        for sm in re.finditer(r'^\s+(\d+)\. (.+)$',seg,re.M):
            n=int(sm.group(1)); t=sm.group(2).strip()
            if t.startswith('Penalty'):
                rows.append([h,par,sc,n,'Penalty','','Rough','Tee','','','','','yes',f'{yds} yds']); continue
            m=re.match(r'Putt from ([\d.]+ (?:ft|in)) (?:-> ([\d.]+ (?:ft|in))|- HOLED)',t)
            if m:
                a=ft(m.group(1)); b=ft(m.group(2)) if m.group(2) else 0
                rows.append([h,par,sc,n,'Putt','','Green','In the hole' if not m.group(2) else 'Green',f'{a:.1f} ft',f'{a:.1f} ft','',f'{b:.1f} ft','no',f'{yds} yds']); continue
            m=re.match(r'(?:Tee shot|From ([a-z ]+)) \((\d+) yd\) -> ([A-Za-z ]+?), ([\d.]+ (?:yd|ft|in)) left',t)
            assert m,(R,h,t)
            lie='Tee' if t.startswith('Tee') else m.group(1).title()
            start=int(m.group(2)); end=m.group(3).strip(); left=m.group(4)
            cat='Tee Shot' if lie=='Tee' and par>3 else ('Around Green' if start<50 and lie!='Tee' else 'Approach')
            v=float(left.split()[0]); prox=f'{v} ft' if left.endswith('ft') else (f'{v/12:.1f} ft' if left.endswith('in') else f'{left.split()[0]} yds')
            q=re.search(r'(\d+)-yard drive',seg[sm.end():sm.end()+400]) if lie=='Tee' else None
            rows.append([h,par,sc,n,cat,'',lie,end,f'{start} yds','',(q.group(1)+' yds') if q else '',prox,'no',f'{yds} yds'])
    with open(f'r{R}.csv','w',newline='') as f: w=csv.writer(f); w.writerow(H); w.writerows(rows)
    from collections import Counter
    c=Counter(r[0] for r in rows); s={r[0]:r[2] for r in rows}
    print('R'+R,len(rows),'shots, holes',len(c),'total',sum(s.values()),'bad',[h for h in s if c[h]!=s[h]])
