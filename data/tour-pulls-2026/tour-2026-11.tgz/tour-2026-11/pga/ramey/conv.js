/* Austin 2026 winner (R2026558, 47983), rounds 1-4 from the transcribed compact files: same conversion as ../convert2.js
 * (surface lies, PENALTY = a stroke, DROP not; every hole = its score, round = card). */
'use strict';
const fs = require('fs'); const E = '/home/user/rc-greenlight/automation/';
const PGA = require(E + 'pgatour-adapter.js'), LIV = require(E + 'liv-adapter.js');
function surface(name, code) { const n = String(name || ''), c = String(code || '').toUpperCase();
  if (c === 'OTB' || /^tee box$/i.test(n)) return 'Tee'; if (/bunker/i.test(n)) return 'Bunker'; if (/fairway/i.test(n)) return 'Fairway';
  if (/green/i.test(n)) return 'Green'; if (/rough/i.test(n)) return 'Rough'; if (!n && !c) return ''; return 'Other'; }
const fmt = (yd, onGreen) => (yd == null ? '' : onGreen ? (Math.round(yd * 3 * 10) / 10) + ' ft' : (Math.round(yd * 10) / 10) + ' yds');
const COLS = ['Hole','Par','Score','Shot','Category','Club','Start Lie','End Lie','Start Distance','Putt Distance','Shot Distance','Proximity','Penalty','Hole Yardage'];
const CARD = { 1: 68, 2: 68, 3: 67, 4: 65 };
for (const rnd of [1, 2, 3, 4]) {
  const holes = JSON.parse(fs.readFileSync('r' + rnd + '.json', 'utf8'));
  const out = [COLS.join(',')], problems = []; let total = 0;
  for (const h of holes) {
    const score = +h.score, par = +h.par; total += score;
    let prevLie = 'Tee', prevRem = +h.yardage, n = 0, pens = 0;
    for (const a of h.strokes) {
      const s = { strokeType: a[0], distance: a[1], distanceRemaining: a[2], fromLocation: a[3], fromLocationCode: a[4], toLocation: a[5], toLocationCode: a[6], finalStroke: a[7] };
      if (s.strokeType === 'DROP') { prevLie = surface(s.toLocation, s.toLocationCode) || prevLie; prevRem = PGA.toYards(s.distanceRemaining); continue; }
      n++;
      if (s.strokeType === 'PENALTY') { pens++; out.push([h.holeNumber, par, score, n, 'Penalty', '', prevLie, 'Drop', '', '', '', '', 'yes', h.yardage + ' yds'].join(',')); continue; }
      const start = surface(s.fromLocation, s.fromLocationCode) || prevLie;
      const holed = !!s.finalStroke && !s.distanceRemaining;
      const end = holed ? 'In The Hole' : surface(s.toLocation, s.toLocationCode);
      const onGreen = start === 'Green';
      const startYd = n === 1 && start === 'Tee' ? +h.yardage : prevRem;
      const rem = holed ? 0 : PGA.toYards(s.distanceRemaining);
      const shot = PGA.toYards(s.distance);
      const cat = LIV.categoryOf(start, n, par, startYd);
      out.push([h.holeNumber, par, score, n, cat, '', start, end || 'Other', fmt(startYd, onGreen), onGreen ? fmt(startYd, true) : '', fmt(shot, onGreen), holed ? '' : fmt(rem, end === 'Green'), 'no', h.yardage + ' yds'].join(','));
      prevLie = end || prevLie; prevRem = rem;
    }
    if (n !== score) problems.push('H' + h.holeNumber + ': ' + n + ' strokes, score ' + score);
  }
  if (holes.length !== 18) problems.push(holes.length + ' holes');
  if (total !== CARD[rnd]) problems.push('sum ' + total + ' card ' + CARD[rnd]);
  fs.writeFileSync('r' + rnd + '.csv', out.join('\n') + '\n');
  fs.writeFileSync('Chad Ramey - Austin Championship R' + rnd + ' - shot by shot.csv', out.join('\n') + '\n');
  console.log('R' + rnd, 'start H' + holes[0].holeNumber, 'sum', total, 'card', CARD[rnd], 'problems', problems.length ? problems : 'none');
}
