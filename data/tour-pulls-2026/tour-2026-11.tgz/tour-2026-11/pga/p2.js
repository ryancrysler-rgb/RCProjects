/* Page 2 — Trace Crowe vs the house rules, round 1 (house rules v18.2, literal). No clubs in the feed and no published stock
 * yardages, so rules 01 and 06 read "not measured" (the engine's own wording); rule 02 reads every shot from 150 yd in, off the
 * green (the owner's field-study reading for a file with no clubs, 2026-11-09), labelled as such.
 * RULE 10, COUNTED AS THE RAW COUNTS A PAR-5 GO: summary-rules counts any second shot that misses the green as a lay-up; a second
 * shot that finished inside 40 yd is a go (round-patterns "went", house rules v16 go line), not a lay-up. Both of his were goes
 * (23 and 7 yd away), so there was no lay-up to grade. The engine fix is a next-rev item (rev-history 2026-11-13). */
'use strict';
const fs = require('fs');
const E = '/home/user/rc-greenlight/automation/';
const SC = require(E + 'shot-csv.js'), SR = require(E + 'summary-rules.js'), SLOT = require(E + 'data-slot.js');
const H = SC.parse(fs.readFileSync(__dirname + '/Trace Crowe - Austin Championship R1 - shot by shot.csv', 'utf8')).holes;
const order = [10, 11, 12, 13, 14, 15, 16, 17, 18, 1, 2, 3, 4, 5, 6, 7, 8, 9];
const rounds = [{ n: 1, holes: H, source: 'files', order }];
const P = SR.page(rounds, { units: 'yd', wedgeMaxYd: 150 });
const nn = P.groups[0].rules, ranked = P.groups[1].rules;
const r2 = nn.find((r) => r.n === 2);
r2.rows.forEach((row) => { if (row.label === 'Wedge shots on the green') row.label = 'Shots from 150 yd in, off the green, on the green (no clubs in the feed)'; });
// LITERAL: a wedge is PW/GW/SW/LW and the feed names no club, so rule 02 is not graded (as the Raw sheet says); the 150-yd count is a reading only.
r2.rows[0] = { kind: 'na', label: 'The grade', why: 'no clubs in the feed' };
const g2 = P.graded.findIndex((g) => g.n === 2); if (g2 >= 0) P.graded.splice(g2, 1);
{ const gr = P.graded.reduce((t, g) => [t[0] + (g.kept || 0), t[1] + (g.graded || 0)], [0, 0]);
  P.read.headline = 'The non-negotiables held ' + gr[0] + ' of ' + gr[1] + ' round grades (rule 02 not graded: no clubs in the feed).'; }
const h10 = ranked.find((r) => /^10 /.test(r.name));
let lay = [0, 0];
H.filter((h) => +h.par === 5).forEach((h) => { const s2 = h.shots[1], s3 = h.shots[2];
  if (!s2 || !s3 || s2.penalty || s2.holed || /green/i.test(s2.endLie) || s3.isPutt) return;
  const left = s3.startYd != null ? s3.startYd : null; if (left != null && left < 40) return;   // a go that missed inside 40 yd
  lay[1]++; if (/^fairway$/i.test(s3.startLie)) lay[0]++; });
h10.rows = [{ kind: 'rate', label: 'Par-5 lay-ups in the fairway (a second shot left inside 40 yd is a go)', good: true, cells: [lay[1] ? lay[0] + '/' + lay[1] : '—'], week: lay, weekPct: lay[1] ? Math.round(100 * lay[0] / lay[1]) : null }];
P.notes = P.notes.map((n) => /stored files/.test(n) ? 'R1: pgatour.com shot data (R2026558), every hole adding up to the official card (62)' : n)
  .map((n) => /playing order from hole 1/.test(n) ? 'playing order from the 10th, where the round started' : n);
P.notes.push('No clubs in the PGA TOUR feed and no published stock yardages: rule 01 and rule 6 are not measured; rule 02 reads every shot from 150 yd in, off the green');
P.notes.push('Rule 10: both par-5 second shots that missed the green were goes that finished 23 and 7 yd away, so there was no lay-up to grade');
const tpl = fs.readFileSync(E + 'tournament-summary.template.html', 'utf8');
fs.writeFileSync(__dirname + '/p2.html', SLOT.fill(tpl, { player: 'Trace Crowe', event: 'Austin Championship 2026 · Round 1', rounds: 1, roundNumbers: [1], scores: [62], total: 62, par: 72, facets: {}, holes: [], swot: {}, rulesPage: P }, 'tournament summary'));
console.log(P.read.headline, '|', JSON.stringify(P.read.next), '|', P.levels.map((x) => x.level).join(' '), '| rule10', lay);
