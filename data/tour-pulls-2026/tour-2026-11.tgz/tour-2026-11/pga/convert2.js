/* Austin Championship 2026 (pgatour.com R2026558), round 1, the round-1 leader only (owner 2026-11-09: "i only want to pull the leader
 * from each round"). Same conversion as wwt/convert.js: surface lies, PENALTY = a stroke, DROP not; every hole = its score, round = card. */
'use strict';
const fs = require('fs');
const E = '/home/user/rc-greenlight/automation/';
const PGA = require(E + 'pgatour-adapter.js'), LIV = require(E + 'liv-adapter.js');
const D = __dirname;
function surface(name, code) {
  const n = String(name || ''), c = String(code || '').toUpperCase();
  if (c === 'OTB' || /^tee box$/i.test(n)) return 'Tee';
  if (/bunker/i.test(n)) return 'Bunker'; if (/fairway/i.test(n)) return 'Fairway'; if (/green/i.test(n)) return 'Green'; if (/rough/i.test(n)) return 'Rough';
  if (!n && !c) return ''; return 'Other';
}
const fmt = (yd, onGreen) => (yd == null ? '' : onGreen ? (Math.round(yd * 3 * 10) / 10) + ' ft' : (Math.round(yd * 10) / 10) + ' yds');
const COLS = ['Hole', 'Par', 'Score', 'Shot', 'Category', 'Club', 'Start Lie', 'End Lie', 'Start Distance', 'Putt Distance', 'Shot Distance', 'Proximity', 'Penalty', 'Hole Yardage'];
const lb = JSON.parse(fs.readFileSync(D + '/leaderboard-r2.json')).data.players;
const pid = process.argv[2], rnd = process.argv[3] || '1';
const p = lb.find((x) => x.id === pid);
const data = JSON.parse(fs.readFileSync(D + '/raw-' + pid + '-' + rnd + '.json')).data;
const out = [COLS.join(',')], problems = [], card = {};
let total = 0;
for (const h of data.holes) {
  const score = +h.score, par = +h.par; total += score; card[h.holeNumber] = { par, score, yards: +h.yardage };
  let prevLie = 'Tee', prevRem = +h.yardage, n = 0, pens = 0;
  for (const s of h.strokes) {
    if (s.strokeType === 'DROP') continue;
    n++;
    if (s.strokeType === 'PENALTY') { pens++; out.push([h.holeNumber, par, score, n, 'Penalty', '', prevLie, 'Drop', '', '', '', '', 'yes', h.yardage + ' yds'].join(',')); continue; }
    if (s.strokeType !== 'STROKE') problems.push('H' + h.holeNumber + ' unknown strokeType ' + s.strokeType);
    const start = surface(s.fromLocation, s.fromLocationCode) || prevLie;
    const holed = !!s.finalStroke && !s.distanceRemaining;
    const end = holed ? 'In The Hole' : surface(s.toLocation, s.toLocationCode);
    const onGreen = start === 'Green';
    const startYd = n === 1 && start === 'Tee' ? +h.yardage : prevRem;
    const rem = holed ? 0 : PGA.toYards(s.distanceRemaining);
    const shot = PGA.toYards(s.distance);
    const cat = LIV.categoryOf(start, n, par, startYd);
    out.push([h.holeNumber, par, score, n, cat, '', start, end || 'Other', fmt(startYd, onGreen), onGreen ? fmt(startYd, true) : '', fmt(shot, onGreen), holed ? '' : fmt(rem, end === 'Green'), 'no', h.yardage + ' yds'].join(','));
    prevLie = end || prevLie; prevRem = rem;
  }
  const lastHoled = h.strokes.filter((s) => s.strokeType === 'STROKE').slice(-1)[0];
  if (!lastHoled || !lastHoled.finalStroke) problems.push('H' + h.holeNumber + ' last stroke is not marked holed');
  if (n !== score) problems.push('H' + h.holeNumber + ': ' + n + ' strokes (' + pens + ' penalty), score ' + score);
}
const official = +p.rounds[+rnd - 1];
if (data.holes.length !== 18) problems.push(data.holes.length + ' holes in the feed');
if (total !== official) problems.push('holes add to ' + total + ', card ' + official);
const name = p.displayName + ' - Austin Championship R' + rnd + ' - shot by shot.csv';
fs.writeFileSync(D + '/' + name, out.join('\n') + '\n');
fs.writeFileSync(D + '/card-' + pid + '-' + rnd + '.json', JSON.stringify({ player: p.displayName, round: +rnd, start: data.holes[0].holeNumber, total, official, card }, null, 1));
console.log(p.displayName, 'R' + rnd, 'start H' + data.holes[0].holeNumber, 'holes', data.holes.length, 'sum', total, 'card', official, '| problems', problems.length ? problems : 'none');
