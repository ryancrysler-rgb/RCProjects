const path=require('path'),fs=require('fs');const ROOT='/home/user/rc-greenlight';const A=f=>require(path.join(ROOT,'automation',f));
const SC=A('shot-csv.js'),M=A('metrics.js'),RP=A('round-patterns.js'),RB=A('raw-report-builder.js'),BC=A('bag-clubs.js');
const T=require('../../tour-avg-bag.js');const BAGX=T.bag(['Driver','5W','3i','4i','5i','6i','7i','8i','9i','PW']);
const H=SC.parse(fs.readFileSync('../Trace Crowe - Austin Championship R3 - shot by shot.csv','utf8')).holes;H._bag=BC.apply(H,BAGX);
const sm=M.summary(H);const p=RP.patterns(H,{startHole:1});p.response=M.clutchFactorResponse(H,{order:p.order});p.closing=M.clutchFactorClosing(H,{behind:0,order:p.order});
const ai=fs.existsSync('ai.json')?JSON.parse(fs.readFileSync('ai.json','utf8')):{decisions:Object.fromEntries(Array.from({length:18},(_,i)=>[String(i+1),'x'])),footnote:'x'};
const rd=RB.buildRawReportData({player:'Trace Crowe',event:'Austin Championship 2026 · Round 3',par:72,round:{score:71,toPar:'−1',note:'Leads after round 3 · −14'},
 putts:sm.putts.value,birdies:sm.counts.birdies,holes:H,plan:null,facets:null,summary:sm,patterns:p,wedgeMaxYd:T.WEDGE_MAX,
 totals:{fw:sm.fairways.display,par:72,yards:H.reduce((a,h)=>a+(h.yards||0),0)||'',gir:sm.gir.display,putts:sm.putts.value,flags:''},
 footnote:ai.footnote,identity:'RC Greenlight · Raw',decisionGained:null,inBand:null,bandsFrom:null,ai,bag:BAGX});
fs.writeFileSync('rd.json',JSON.stringify(rd));
const tpl=fs.readFileSync(path.join(ROOT,'automation/raw-report.template.html'),'utf8');
fs.writeFileSync('Trace Crowe - Austin Championship R3 - Raw.html',tpl.replace('<!--__DATA_SLOT__-->','<script>window.__REPORT_DATA='+JSON.stringify(rd).replace(/</g,'\\u003c')+';</script>').replace(/__SITE_URL__/g,'file://'+ROOT));
if(process.argv[2]==='dump'){console.log(JSON.stringify(rd.rules.map(r=>[r.n,r.state,r.detail])));console.log('dom',JSON.stringify(rd.clutch));console.log('top',JSON.stringify(rd.topBottom));
 console.log('bag',H._bag.rows.map(r=>'H'+r.hole+'.'+r.shot+' '+r.club+' '+r.d).join(' | '));
 H.forEach(h=>console.log('H'+h.hole,'p'+h.par,'s'+h.score,h.shots.map(s=>(s.club||'')+':'+s.startLie+'>'+s.endLie+' '+(s.startYd!=null?Math.round(s.startYd)+'y':(s.startFt!=null?s.startFt+'ft':''))).join(' | ')));}
