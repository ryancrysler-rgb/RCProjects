/* TOUR-AVERAGE BAG (owner 2026-11-13: "Yes let's go with tour average for now"). For a player whose set makeup is known but
 * whose own yardages are not published, each club in the set takes the TrackMan PGA Tour average carry (Golf Monthly's table,
 * "Data: Trackman"), used as the club's one number. An ESTIMATE, labelled so on every page. TrackMan lists no wedge below the
 * PW, so the PW (142) is the only wedge with a number: every shot inside it reads as a wedge, which rule 02 counts the same. */
'use strict';
const AVG = { Driver: 282, '3W': 249, '5W': 236, Hybrid: 231, '3i': 218, '4i': 209, '5i': 199, '6i': 188, '7i': 176, '8i': 164, '9i': 152, PW: 142 };
function bag(names) { return { units: 'yd', clubs: names.map((n) => ({ name: n, total: AVG[n], tee: /Driver|W$/.test(n) })) }; }
module.exports = { AVG, bag, WEDGE_MAX: 142 };
