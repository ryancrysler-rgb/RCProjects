#!/usr/bin/env python3
"""Record the shot data behind the AI Shot Commentary panel.

You drive, this records. Guessing at button labels from the outside kept
missing the view; you can reach it in seconds. So this opens a browser,
captures every data response and websocket message while you click through
the commentary, and works out what's in them once you close the window.

Runs accumulate. Each run saves into its own folder and the analysis reads
every folder, so covering holes 1-10 now and 11-18 later still produces one
complete spreadsheet.

The commentary lines are rendered from structured records -- the site's own
translation bundle formats them as "Shot {{shotNumber}}" and
"{{distance,metresToYards}}" -- so the feed behind them carries the shot
number, distance and surface as fields, not just prose.
"""
from __future__ import annotations

import argparse
import base64
import gzip
import hashlib
import json
import re
import subprocess
import sys
import time
import zlib
from pathlib import Path
from typing import Any

from playwright.sync_api import Response, sync_playwright

import snappy_lite

HERE = Path(__file__).parent
DEFAULT_URL = (
    "https://www.europeantour.com/dpworld-tour/amgen-irish-open-2026/leaderboard?round=1"
)

NOISE = re.compile(
    r"onetrust|doubleverify|doubleclick|googlesyndication|googletagmanager|"
    r"google-analytics|adservice|safeframe|criteo|teads|prebid|aditude|"
    r"amazon-adsystem|/locales?/|l10n|sentry|chartbeat|permutive",
    re.I,
)


# Ad networks: blocked outright in the capture window. They carry no golf
# data, and on a busy live day they are much of what the page spends its time
# loading.
ADS = re.compile(
    r"doubleclick|googlesyndication|adservice|safeframe|criteo|teads|prebid|"
    r"aditude|amazon-adsystem|doubleverify|presage|yellowblue",
    re.I,
)


def wanted(response) -> bool:
    """Whether a response could hold data worth keeping.

    Reading a body is a round trip to the browser. Doing it for every image,
    script, font and video segment the page loads is what made the capture
    crawl on a final-round Sunday, so only the page's own data calls are read.
    """
    if NOISE.search(response.url):
        return False
    if response.request.resource_type not in ("xhr", "fetch"):
        return False
    content_type = ((response.headers or {}).get("content-type") or "").lower()
    return not content_type.startswith(("image/", "video/", "audio/", "font/", "text/html", "text/css"))


def slugify(url: str) -> str:
    return re.sub(r"[^A-Za-z0-9]+", "_", url.split("?")[0])[-70:].strip("_")


def event_slug(url: str) -> str:
    """The event's name from its leaderboard URL.

    .../dpworld-tour/bmw-pga-championship-2026/leaderboard -> bmw-pga-championship-2026
    """
    parts = [p for p in url.split("?")[0].split("/") if p]
    for index, part in enumerate(parts):
        if part in ("leaderboard", "scores", "results") and index:
            return parts[index - 1]
    return parts[-1] if parts else "unknown-event"


def clean_url(text: str) -> str | None:
    """The first web address in whatever was pasted."""
    match = re.search(r"https?://\S+", text)
    return match.group(0).rstrip(".,)") if match else None


def clean_round(text: str, default: str) -> str:
    """The round number typed, ignoring any prompt text pasted with it.

    Takes the last number on the line, since pasted prompt text such as
    "[Enter for 1]" comes before the actual answer.
    """
    answer = text.split(">")[-1]
    numbers = re.findall(r"\d+", answer)
    return numbers[-1] if numbers else default


def clean_name(text: str) -> str | None:
    """The surname typed, ignoring any prompt text pasted with it."""
    answer = text.split(">")[-1]
    words = re.findall(r"[A-Za-z][A-Za-z'\-]*", answer)
    words = [w for w in words if w.lower() not in {"enter", "press", "for", "or", "type", "it"}]
    return words[-1] if words else None


def last_url(captured: Path) -> str | None:
    """The URL used by the most recent capture, as the obvious default."""
    runs = sorted(captured.glob("run_*/_run_info.json"))
    if not runs:
        return None
    try:
        return json.loads(runs[-1].read_text(encoding="utf-8")).get("url")
    except Exception:
        return None


def collect_payloads(captured_dir: Path) -> list[tuple[str, Any]]:
    """Load every payload from every run, this one and any before it."""
    files = sorted(captured_dir.glob("run_*/*.json"))
    files += sorted((captured_dir / "bodies").glob("*.json"))  # older layout
    payloads = []
    for path in files:
        if path.name.startswith("_"):
            continue
        try:
            payloads.append((path.name, json.loads(path.read_text(encoding="utf-8"))))
        except Exception:
            continue
    return payloads


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    parser.add_argument("--url", default=DEFAULT_URL)
    parser.add_argument("--minutes", type=float, default=45.0,
                        help="Safety limit if the window is left open (default 45).")
    args = parser.parse_args()

    out = HERE / "captured"

    # Shot records carry holeNo and strokeNo but neither an event nor a round,
    # so both are recorded here. Without them every event's hole 1 shot 1
    # would pile up indistinguishably.
    # Answers get pasted with surrounding text -- a whole line of instructions,
    # prompt and all -- so pull out just the part wanted rather than taking the
    # input verbatim. Anything else would end up in a folder name.
    print("Paste the leaderboard page for the event you want.")
    print(f"  [Enter for: {last_url(out) or args.url}]")
    url = clean_url(input("> ")) or last_url(out) or args.url

    event = event_slug(url)
    print(f"\nEvent: {event}")

    default_round = (re.search(r"round=(\d+)", url) or [None, "1"])[1]
    round_no = clean_round(input(f"Which round? Type a number, or press Enter for {default_round} > "),
                           default_round)
    url = re.sub(r"round=\d+", f"round={round_no}", url)
    if "round=" not in url:
        url += ("&" if "?" in url else "?") + f"round={round_no}"

    player = clean_name(input("Player surname? Type it, or press Enter for Canter > ")) or "Canter"
    print(f"\nCapturing {event}, round {round_no}, looking for {player}.\n")

    safe = re.sub(r"[^A-Za-z0-9_-]+", "-", f"{event}_r{round_no}").strip("-")
    run_dir = out / f"run_{time.strftime('%Y%m%d_%H%M%S')}_{safe}"
    run_dir.mkdir(parents=True, exist_ok=True)
    (run_dir / "_run_info.json").write_text(
        json.dumps({"event": event, "round": round_no, "url": url, "player": player,
                    "captured": time.strftime("%Y-%m-%d %H:%M:%S")}, indent=2),
        encoding="utf-8",
    )

    previous = len(collect_payloads(out))
    if previous:
        print(f"Found {previous} payloads from earlier runs -- this run adds to them.\n")

    captured: list[dict[str, Any]] = []
    seen: set[str] = set()

    def record(url: str, payload: Any, kind: str) -> None:
        # These are GraphQL persisted queries: the hole is in the POST body,
        # not the URL, so every hole comes back from the same address. De-
        # duplicate on content, or holes 2-18 look like repeats and vanish.
        body = json.dumps(payload, indent=2)
        fingerprint = hashlib.sha1(body.encode("utf-8")).hexdigest()
        if fingerprint in seen:
            return
        seen.add(fingerprint)

        (run_dir / f"{len(captured):03d}_{slugify(url)}.json").write_text(body, encoding="utf-8")
        captured.append({"url": url, "kind": kind})
        if isinstance(payload, dict) and isinstance(payload.get("data"), dict):
            print(f"   <- {', '.join(payload['data'].keys())}")

    def on_response(response: Response) -> None:
        if not wanted(response):
            return
        try:
            payload = response.json()
        except Exception:
            return
        record(response.url, payload, "http")

    ws_log = run_dir / "_ws_frames.jsonl"
    ws_count = [0]
    subscriptions: dict[str, str] = {}

    def decode_frame(payload: Any) -> str | None:
        """Get text out of a frame, compressed or binary though it may be.

        This feed sends Snappy-compressed UTF-16LE JSON, which is what the
        binary frames are; the other codecs are kept as cheap fallbacks.
        """
        if isinstance(payload, str):
            return payload
        if not isinstance(payload, (bytes, bytearray)):
            return None
        raw = bytes(payload)
        text = snappy_lite.decode_text(raw, partial=True)
        if text and text.lstrip().startswith(("{", "[")):
            return text
        for attempt in (
            lambda b: b.decode("utf-8"),
            lambda b: b.decode("utf-16-le"),
            lambda b: zlib.decompress(b).decode("utf-8"),
            lambda b: zlib.decompress(b, -zlib.MAX_WBITS).decode("utf-8"),
            lambda b: gzip.decompress(b).decode("utf-8"),
        ):
            try:
                return attempt(raw)
            except Exception:
                continue
        return None

    def on_websocket(ws) -> None:
        print(f"   websocket opened: {ws.url[:90]}")

        def handle(payload: Any, direction: str) -> None:
            # Never drop a frame silently: the shot feed streams through here,
            # and an unreadable frame still needs to be kept whole as evidence.
            ws_count[0] += 1
            text = decode_frame(payload)
            entry: dict[str, Any] = {"direction": direction, "url": ws.url}

            if isinstance(payload, (bytes, bytearray)):
                raw = bytes(payload)
                # Store the entire frame, not a preview: a truncated frame
                # can be identified but never fully decoded afterwards.
                entry.update({"bytes": len(raw), "base64": base64.b64encode(raw).decode()})

            if text is None:
                entry["undecodable"] = True
            else:
                entry["text"] = text[:400_000]
                try:
                    parsed = json.loads(text)
                except Exception:
                    parsed = None
                if parsed is not None:
                    # A sent "start" names the operation; received frames only
                    # carry its id, so keep the mapping to label them.
                    if direction == "sent" and parsed.get("type") == "start":
                        operation = parsed.get("operationName", "?")
                        subscriptions[str(parsed.get("id"))] = operation
                        print(f"   subscribed: {operation}")
                    elif direction == "received":
                        operation = subscriptions.get(str(parsed.get("id")))
                        if operation:
                            entry["operation"] = operation
                            parsed["_operation"] = operation
                    record(ws.url, parsed, f"ws-{direction}")

            with open(ws_log, "a", encoding="utf-8") as handle_:
                handle_.write(json.dumps(entry) + "\n")
            if ws_count[0] % 25 == 0:
                print(f"   ...{ws_count[0]} websocket frames")

        # framesent carries the subscription, which says what to ask for.
        ws.on("framereceived", lambda payload: handle(payload, "received"))
        ws.on("framesent", lambda payload: handle(payload, "sent"))

    with sync_playwright() as playwright:
        browser = playwright.chromium.launch(headless=False)
        context = browser.new_context(
            user_agent=(
                "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 "
                "(KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36"
            ),
            viewport={"width": 1500, "height": 950},
        )
        context.route(ADS, lambda route: route.abort())
        page = context.new_page()
        page.on("response", on_response)
        page.on("websocket", on_websocket)

        page.goto(url, wait_until="domcontentloaded", timeout=60_000)
        for selector in ("#onetrust-accept-btn-handler", "button:has-text('Accept All')"):
            try:
                page.click(selector, timeout=5_000)
                break
            except Exception:
                pass

        print("\n" + "=" * 64)
        print("  YOUR TURN -- in the browser window that just opened:")
        print()
        print("   1. Click on Laurie Canter")
        print("   2. Open the Scorecard, and click hole 1")
        print("   3. Open the AI SHOT COMMENTARY panel -- THIS IS THE ONE")
        print("      THAT MATTERS. Expand it so the lines are visible, and")
        print("      scroll it to the bottom so every shot loads.")
        print("   4. Step through the holes with the > arrow, pausing a")
        print("      moment on each so its shots load")
        print()
        print("  TAKE AS LONG AS YOU LIKE. Nothing is timing you.")
        print("  When you're done -- or want a break -- just CLOSE THE")
        print("  BROWSER WINDOW. Run this again later to add more holes.")
        print("=" * 64 + "\n")

        deadline = time.time() + args.minutes * 60
        while time.time() < deadline and not page.is_closed():
            try:
                page.wait_for_timeout(1_000)
            except Exception:
                break  # window closed mid-wait
        print(f"\nFinished. {len(captured)} new payloads this run.")

        try:
            context.close()
            browser.close()
        except Exception:
            pass

    (run_dir / "_manifest.json").write_text(json.dumps(captured, indent=2), encoding="utf-8")

    # Finish by running the real build, so a capture always leaves the proper
    # spreadsheet behind. This used to run its own rough analysis and write it
    # to SHOT_BY_SHOT.csv -- the deliverable's name -- in a different format,
    # so committing straight after a capture pushed the raw dump instead.
    print("\nBuilding the spreadsheet...\n")
    result = subprocess.run(
        [sys.executable, str(HERE / "build_shots.py")],
        stdin=subprocess.DEVNULL, capture_output=True, text=True, cwd=str(HERE),
    )
    report = (result.stdout or "").replace("Press Enter to close...", "").rstrip()
    print(report or result.stderr)
    built = result.returncode == 0 and "shots -> SHOT_BY_SHOT.csv" in report
    if not built:
        print("\nThe build did not finish. Run SEND DATA TO CLAUDE and push --")
        print("Claude can then read exactly what was captured.")
    else:
        print("\nDone. Check the line for this round says it matches the site's")
        print("scorecard, then commit and push.")
    input("\nPress Enter to close... ")
    return 0 if built else 1


if __name__ == "__main__":
    try:
        raise SystemExit(main())
    except Exception as exc:
        print(f"\nSomething went wrong: {type(exc).__name__}: {exc}")
        input("\nPress Enter to close... ")
        raise SystemExit(1)
