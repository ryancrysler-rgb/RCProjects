#!/usr/bin/env python3
"""Turn captured websocket frames into a shot-by-shot spreadsheet.

Two subscriptions carry the data and each holds half the picture:

  subscribeToGolfMedia3DShots         ball positions -- hole, stroke, x/z,
                                      surface, distance to pin
  subscribeToGolfTournamentTeamsShotFeed
                                      the event feed -- shot number, time,
                                      surface moved from, hole score

The event feed carries no hole number (each frame covers one hole), so the
positions lead and events are joined onto them by stroke number and the
distances, which both feeds report identically.
"""
from __future__ import annotations

import glob
import json
from pathlib import Path

import find_shots

HERE = Path(__file__).parent

METRES_TO_YARDS = 1.0936132983377078

# Read off the site's own commentary: every shot whose text says "finds the
# rough" carries ORO, and so on, across hundreds of shots. Codes are not
# abbreviations of the names -- OST reads as Rough too -- so each is mapped
# only where the commentary agreed, with the sample size noted.
SURFACES = {
    "OTB": "Tee",
    "OFW": "Fairway",              # 34/34 "fairway"
    "OGR": "Green",                # 41/42 "green"
    "ORO": "Rough",                # 18/18 "rough"
    "OIR": "Intermediate Rough",   # 6/6  "intermediate rough"
    "OCO": "Fringe",               # 3/3  "fringe"
    "ONA": "Native Area",          # 2/2  "native area"
    "OST": "Fairway Bunker",       # 3/3 "fairway bunker" -- overrides an
                                   # earlier by-eye reading of "rough"
    "OWA": "Water",                # followed at once by a penalty drop
    "OGS": "Greenside Bunker",     # 4 say "greenside bunker"; the next shot
                                   # is a bunker shot in 5/5
}
# Still unmapped, on one ambiguous sighting each: ODO, OBU. They stay raw in
# the lieCode columns.


def surface(code: str | None) -> str:
    return SURFACES.get(code, "") if code else ""


def yards(metres: float | None) -> float | None:
    return round(metres * METRES_TO_YARDS, 1) if isinstance(metres, (int, float)) else None


def declared(run_dir: Path) -> dict:
    """What the capture recorded about itself: its event and round."""
    info = run_dir / "_run_info.json"
    if info.exists():
        try:
            return json.loads(info.read_text(encoding="utf-8"))
        except Exception:
            pass
    return {}


def assign_rounds(runs: list[dict]) -> None:
    """Give every capture a round, by date when it was not told one.

    Numbering runs within an event, never across them: a new event's first
    round is round 1 even though its date is later than every round of the
    last one.
    """
    for event in {r["event"] for r in runs}:
        in_event = [r for r in runs if r["event"] == event]
        by_date = {r["date"]: r["round"] for r in in_event if r["round"] and r["date"]}
        known = {int(r["round"]) for r in in_event if r["round"] and r["round"].isdigit()}

        for run in sorted((r for r in in_event if not r["round"]), key=lambda r: r["date"] or ""):
            if run["date"] and run["date"] in by_date:
                run["round"] = by_date[run["date"]]      # same day as a known round
                continue
            number = 1
            while number in known:
                number += 1
            run["round"] = str(number)
            known.add(number)
            if run["date"]:
                by_date[run["date"]] = run["round"]


def feed(payload: dict, name: str):
    """One of the Event Centre's data sets from a captured payload.

    The same data arrives two ways. Over the websocket it is a subscription,
    "subscribeTo<Name>" under payload.data; over plain HTTP -- which the
    Event Centre switched to for finished rounds in version 6.0.130 -- it is
    a query, "get<Name>" under data. Both carry the same records.
    """
    for data in ((payload.get("payload") or {}).get("data") or {}, payload.get("data") or {}):
        if isinstance(data, dict):
            for key in (f"subscribeTo{name}", f"get{name}"):
                if data.get(key) is not None:
                    return data[key]
    return None


def official_scorecards(payload: dict) -> list[tuple]:
    """The site's own per-round scorecards in a group-scores response.

    Returns (playerId, roundNo, holesThrough, {hole: strokes}) for each player
    and round. These come from the same Event Centre and name players by the
    same ids as the shot feed, so they can check -- and arbitrate -- the shots.
    """
    found = []
    for data in (payload.get("data") or {}, (payload.get("payload") or {}).get("data") or {}):
        if not isinstance(data, dict):
            continue
        for key in ("getGolfTournamentGroupScores", "subscribeToGolfTournamentGroupScores"):
            groups = data.get(key)
            if groups is None:
                continue
            for group in groups if isinstance(groups, list) else [groups]:
                if not isinstance(group, dict):
                    continue
                for score in group.get("roundScores") or []:
                    holes = {h.get("holeNumber"): h.get("holeStrokes")
                             for h in score.get("holes") or [] if h.get("holeStrokes")}
                    thru = (score.get("holesThrough") or {}).get("value") or len(holes)
                    for player in group.get("players") or []:
                        found.append((player.get("id"), str(score.get("roundNo")), thru, holes))
    return found


def pick_hole_versions(run: dict, scorecards: dict) -> tuple[list[dict], list[str]]:
    """Keep one version of each hole when a capture holds two.

    The Event Centre opens on a player's latest round and only switches when
    the round is changed, so a capture labelled round 2 can also hold a hole
    from round 3 -- with nothing in the records to say so. A hole's versions
    are told apart by the seqNum of its tee position, and the one kept is the
    version whose stroke count matches the site's scorecard for the labelled
    round (failing that, the version viewed last).
    """
    versions: dict[tuple, dict] = {}
    for index, records in enumerate(run["frames3d"]):
        by_hole: dict[tuple, list] = {}
        for record in records:
            golfer = (record.get("player") or {}).get("id") or record.get("teamId")
            by_hole.setdefault((golfer, record.get("holeNo")), []).append(record)
        for key, recs in by_hole.items():
            tee = next((r.get("seqNum") for r in recs if r.get("strokeNo") == 0), None)
            versions.setdefault(key, {}).setdefault(tee, []).append((index, recs))

    def strokes(entries) -> int:
        return max((r.get("strokeNo") or 0) for _, recs in entries for r in recs)

    kept, lost = [], []
    for (golfer, hole), by_tee in versions.items():
        teed = {tee: entries for tee, entries in by_tee.items() if tee is not None}
        if len(teed) <= 1:
            kept += [r for entries in by_tee.values() for _, recs in entries for r in recs]
            continue
        card = scorecards.get((run["event"], golfer, run["round"]), {}).get(hole)
        matching = [tee for tee, entries in teed.items() if card is not None and strokes(entries) == card]
        if len(matching) == 1:
            chosen, reason = matching[0], f"the site's round {run['round']} card has {card}"
        else:
            chosen = max(teed, key=lambda tee: max(i for i, _ in teed[tee]))
            reason = "no scorecard to decide, so kept the version viewed last"
        for tee, entries in by_tee.items():
            if tee == chosen or tee is None:
                kept += [r for _, recs in entries for r in recs]
            else:
                lost.append(f"{run['event']} round {run['round']} hole {hole}: ignored a second "
                            f"version ({strokes(entries)} strokes) -- {reason}")
    return kept, lost


def load_feeds(captured: Path):
    """Return ball positions and event frames, each tagged with its round.

    Grouping matters twice over: an event carries no hole number, but every
    event in one frame shares a hole; and no record carries a round at all,
    so the round comes from the folder it was captured into.
    """
    runs = []
    for run_dir in sorted(captured.glob("run_*")):
        if not run_dir.is_dir():
            continue
        info = declared(run_dir)
        run = {"event": info.get("event"), "course": None,
               "round": str(info["round"]) if info.get("round") else None,
               "date": None, "positions": [], "frames": [], "frames3d": [], "scores": [],
               "name": run_dir.name}
        for path in sorted(run_dir.glob("*.json")):
            if path.name.startswith("_"):
                continue
            try:
                payload = json.loads(path.read_text(encoding="utf-8"))
            except Exception:
                continue
            if not isinstance(payload, dict):
                continue
            run["scores"] += official_scorecards(payload)
            records = feed(payload, "GolfMedia3DShots") or []
            if records:
                run["frames3d"].append(records)
            for record in records:
                if run["course"] is None and record.get("courseId") is not None:
                    run["course"] = record["courseId"]
            frame = feed(payload, "GolfTournamentTeamsShotFeed") or []
            if frame:
                run["frames"].append(frame)
                for event in frame:
                    stamp = event.get("timestamp")
                    if stamp and (run["date"] is None or stamp[:10] < run["date"]):
                        run["date"] = stamp[:10]
        # An unlabelled capture still names its course in every shot record,
        # and a course belongs to one event -- far better than lumping every
        # unlabelled capture under one name and merging two tournaments.
        if not run["event"]:
            run["event"] = f"course-{run['course']}" if run["course"] is not None else "unknown-event"
        runs.append(run)

    assign_rounds(runs)

    # The most complete scorecard seen for each player and round.
    best: dict[tuple, tuple] = {}
    for run in runs:
        for player, round_no, thru, holes in run["scores"]:
            key = (run["event"], player, round_no)
            if key not in best or thru >= best[key][0]:
                best[key] = (thru, holes)
    scorecards = {key: holes for key, (thru, holes) in best.items()}

    dropped: list[str] = []
    for run in runs:
        run["positions"], lost = pick_hole_versions(run, scorecards)
        dropped += lost

    positions, event_frames = [], []
    for run in runs:
        key = (run["event"], run["round"])
        for record in run["positions"]:
            positions.append({**record, "_event": run["event"], "_round": run["round"]})
        for frame in run["frames"]:
            event_frames.append((key, frame))
    return positions, event_frames, scorecards, dropped


YARDS_TO_METRES = 1 / METRES_TO_YARDS


def load_course_names(captured: Path) -> dict:
    """courseId -> course name, from the getGolfTournament responses captured.

    Matters at multi-course events like the Dunhill Links, where a player's
    rounds are on St Andrews, Carnoustie and Kingsbarns in turn.
    """
    names: dict = {}
    for path in sorted(captured.glob("run_*/*.json")):
        if path.name.startswith("_"):
            continue
        try:
            payload = json.loads(path.read_text(encoding="utf-8"))
        except Exception:
            continue
        if not isinstance(payload, dict):
            continue
        tournament = (payload.get("data") or {}).get("getGolfTournament") or {}
        for course in tournament.get("golfCourses") or []:
            if course.get("id") is not None and course.get("name"):
                names[course["id"]] = course["name"]
    return names


def load_player_names(captured: Path) -> dict:
    """playerId -> name, from anywhere a capture names a player.

    The HTTP form of the shot feed carries only the player's id, so rows built
    from it need the name found elsewhere: the websocket form's displayName,
    or the group scorecards, which name every player in the group.
    """
    names: dict = {}
    for path in sorted(captured.glob("run_*/*.json")):
        if path.name.startswith("_"):
            continue
        try:
            payload = json.loads(path.read_text(encoding="utf-8"))
        except Exception:
            continue
        if not isinstance(payload, dict):
            continue
        for record in feed(payload, "GolfMedia3DShots") or []:
            player = record.get("player") or {}
            if player.get("id") is not None and player.get("displayName"):
                names[player["id"]] = player["displayName"]
        groups = feed(payload, "GolfTournamentGroupScores") or []
        for group in groups if isinstance(groups, list) else [groups]:
            for player in (group.get("players") or []) if isinstance(group, dict) else []:
                full = " ".join(x for x in (player.get("firstName"), player.get("lastName")) if x)
                if player.get("id") is not None and full:
                    names.setdefault(player["id"], full)
    return names


def load_commentary(captured: Path) -> dict[tuple, str]:
    """The site's AI commentary line for each shot, keyed by event/round/player/hole/shot.

    Keyed by event as well as round: hole 1 shot 1 of round 2 exists at every
    tournament, so a key without the event silently mixes them. And by player:
    with two players captured at one event, a key without the player handed
    one player's lines to the other (Abu Dhabi, Rahm and Puig).
    """
    lines: dict[tuple, str] = {}
    for run_dir in sorted(captured.glob("run_*")):
        if not run_dir.is_dir():
            continue
        event = declared(run_dir).get("event") or "unknown-event"
        for path in sorted(run_dir.glob("*.json")):
            if path.name.startswith("_"):
                continue
            try:
                payload = json.loads(path.read_text(encoding="utf-8"))
            except Exception:
                continue
            if not isinstance(payload, dict):
                continue
            commentary = feed(payload, "GolfCommentary")
            if not isinstance(commentary, dict):
                continue
            round_no = str(commentary.get("roundNo"))
            for hole in commentary.get("holes") or []:
                for shot in hole.get("shots") or []:
                    text = (shot.get("comments") or {}).get("en")
                    if text:
                        lines[(event, round_no, shot.get("playerId"), hole.get("holeNo"), shot.get("shotNo"))] = text
    return lines


def load_manual(path: Path) -> list[dict]:
    """Shots transcribed from the on-screen commentary, for missed holes.

    Kept apart from the feed and marked as such: the commentary rounds its
    numbers ("a twelve-footer", "an inch") and never gives coordinates, so
    these rows are not interchangeable with captured ones.
    """
    if not path.exists():
        return []
    try:
        entries = json.loads(path.read_text(encoding="utf-8")).get("shots", [])
    except Exception:
        return []

    rows = []
    for entry in entries:
        row = {"source": "commentary"}
        row.update({k: v for k, v in entry.items() if not k.startswith("_")})
        for field in ("shotDistance", "distanceToPin"):
            value = row.get(f"{field}_yds")
            if isinstance(value, (int, float)):
                row[f"{field}_m"] = round(value * YARDS_TO_METRES, 2)
        rows.append(row)
    return rows


def who(row: dict):
    """The golfer a row belongs to.

    Keyed on the individual rather than the team: at a pro-am such as the
    Dunhill Links a team is a pro and an amateur partner, and keying on it
    would let the partner's shots and hole scores land on the pro's card.
    """
    return row.get("playerId") or row.get("teamId")


def merge_corrections(rows: list[dict]) -> list[dict]:
    """Fold a relocated ball into the shot it belongs to.

    The feed sometimes re-records where a ball lies after the fact -- a
    corrected lie, or relief with no penalty -- as a second record with the
    same stroke number and isBallDrop set. It is not a stroke, so counting it
    as one inflates the hole's score. Keep one row: the shot as played, ending
    at the corrected position. Penalty drops are real strokes and untouched.
    """
    groups: dict[tuple, list[dict]] = {}
    for row in rows:
        key = (row.get("event"), row.get("round"), who(row), row.get("hole"), row.get("shot"))
        groups.setdefault(key, []).append(row)

    merged = []
    for group in groups.values():
        if len(group) == 1:
            only = group[0]
            # The only ball recorded for a stroke is the ball played, whatever its flag says. The feed sometimes
            # tags it provisional and never marks it selected; readers that drop an unselected provisional would
            # lose the stroke (the hole's count still matches the card with it in).
            if only.get("isProvisional") and not only.get("isProvisionalSelected"):
                only["isProvisionalSelected"] = True
                only["note"] = ((only.get("note") or "") + "; " if only.get("note") else "") + \
                    "the only ball recorded for this stroke is flagged provisional; marked played here"
            merged.append(only)
            continue
        group.sort(key=lambda r: r.get("seqNum") or 0)

        # A provisional ball: two balls off the same stroke, one abandoned.
        # The feed marks the one carried on with isProvisionalSelected; the
        # other was never played and is not a stroke. When it marks neither,
        # the original stands -- a provisional only counts once put in play --
        # and the original is the first ball hit. provisionalIndex does not
        # say which that is: Abu Dhabi r1 hole 11 hit index 2 first, and the
        # commentary confirms it was the ball played.
        balls = [r for r in group if r.get("isProvisional")]
        if len(balls) > 1:
            flagged = [r for r in balls if r.get("isProvisionalSelected")]
            chosen = flagged or sorted(balls, key=lambda r: r.get("seqNum") or 0)[:1]
            dropped = [r for r in balls if r not in chosen]
            group = [r for r in group if r not in dropped]
            for ball in dropped:
                where = ball.get("lieAfterShot") or ball.get("lieAfterShotCode") or "?"
                chosen[0]["note"] = (f"provisional ball also hit ({ball.get('shotDistance_yds')} yds, "
                                     f"{where}); original found and played")
            if not flagged:
                # Readers of this file (RC Greenlight's tour reader among them)
                # drop a provisional whose isProvisionalSelected is false as a
                # ball not played on. Mark the one kept, and say it was ours.
                chosen[0]["isProvisionalSelected"] = True
                chosen[0]["note"] += ("; the feed flagged neither ball as played, so the first ball "
                                      "hit is marked played here")
            if len(group) == 1:
                merged.append(group[0])
                continue

        played = dict(group[0])
        for later in group[1:]:
            if later.get("isBallDrop") and later.get("eventType") != "Penalty":
                for field in ("x", "z", "lieAfterShot", "lieAfterShotCode",
                              "distanceToPin_yds", "distanceToPin_m"):
                    if later.get(field) not in (None, ""):
                        played[field] = later[field]
                played["note"] = "ball position corrected after the shot (no penalty)"
            else:
                merged.append(later)      # not a correction -- keep as its own row
        merged.append(played)
    return merged


def fill_stroke_gaps(rows: list[dict], events: dict[tuple, dict]) -> list[dict]:
    """Add a row for every stroke the feed counted but never positioned.

    Strokes are numbered, and the holed ball carries the hole's final number,
    but a penalty -- an unplayable lie, say -- can take a number without ever
    producing a ball position. Without a row for it the hole reads a stroke
    short. The event feed sometimes has an entry for the missing stroke, and
    that is used where it exists.
    """
    holes: dict[tuple, list[dict]] = {}
    for row in rows:
        if row.get("source") == "commentary":
            continue
        holes.setdefault((row.get("event"), row.get("round"), who(row), row.get("hole")), []).append(row)

    added = []
    for (event, round_no, golfer, hole), in_hole in holes.items():
        numbers = {r.get("shot") for r in in_hole}
        last = max(n for n in numbers if isinstance(n, int))
        template = in_hole[0]
        for missing in range(1, last):
            if missing in numbers:
                continue
            info = events.get(((event, round_no), golfer, hole, missing), {})
            added.append({
                "event": event, "round": round_no,
                "player": template.get("player"), "playerId": template.get("playerId"),
                "teamId": template.get("teamId"), "course": template.get("course"),
                "hole": hole, "shot": missing,
                "eventType": info.get("eventType"), "timestamp": info.get("timestamp"),
                "source": "feed",
                "note": "stroke counted by the feed with no ball position (e.g. a penalty)",
            })
    return rows + added


def event_key(shot_no, shot_distance, distance_to_pin) -> tuple:
    """Join key shared by both feeds: stroke number plus its two distances."""
    def near(value):
        return round(value, 4) if isinstance(value, (int, float)) else None
    return (shot_no, near(shot_distance), near(distance_to_pin))


def main() -> int:
    positions, event_frames, scorecards, dropped = load_feeds(HERE / "captured")
    if not positions:
        print("No 3D shot records found. Run GET SHOT BY SHOT first.")
        try:
            input("\nPress Enter to close... ")
        except EOFError:
            pass
        return 1

    # Work out each event frame's hole by matching one of its shots to a
    # position record, then key every event in that frame by (hole, shot).
    positions_by_key = {
        ((p["_event"], p["_round"]), *event_key(p.get("strokeNo"), p.get("shotDistance"), p.get("distanceToPin"))): p
        for p in positions
    }
    by_hole_shot: dict[tuple, dict] = {}
    unplaced = 0
    for key, frame in event_frames:
        hole = golfer = None
        for event in frame:
            match = positions_by_key.get(
                (key, *event_key(event.get("shotNo"), event.get("shotDistance"), event.get("distanceToPin")))
            )
            if match and match.get("holeNo"):
                hole = match["holeNo"]
                # The HTTP form of this feed carries no playerId, so the
                # golfer comes from the position record the frame matched.
                golfer = (match.get("player") or {}).get("id") or match.get("teamId")
                break
        if hole is None:
            unplaced += 1
            continue
        for event in frame:
            who_ = event.get("playerId") or golfer or event.get("teamId")
            by_hole_shot.setdefault((key, who_, hole, event.get("shotNo")), {}).update(event)

    commentary = load_commentary(HERE / "captured")
    course_names = load_course_names(HERE / "captured")
    player_names = load_player_names(HERE / "captured")
    rows, seen = [], set()
    for record in positions:
        stroke = record.get("strokeNo")
        # strokeNo 0 is where the ball started, not a shot that was played.
        if stroke in (None, 0):
            continue
        player = record.get("player") or {}
        event = by_hole_shot.get(
            ((record["_event"], record["_round"]), (record.get("player") or {}).get("id") or record.get("teamId"),
             record.get("holeNo"), stroke), {}
        )

        row = {
            "event": record["_event"],
            "round": record["_round"],
            "player": player.get("displayName") or player_names.get(player.get("id")),
            "playerId": player.get("id"),
            "teamId": record.get("teamId"),
            "course": course_names.get(record.get("courseId"), record.get("courseId")),
            "hole": record.get("holeNo"),
            "shot": stroke,
            "shotDistance_yds": yards(record.get("shotDistance")),
            "distanceToPin_yds": yards(record.get("distanceToPin")),
            "shotDistance_m": round(record.get("shotDistance"), 2) if isinstance(record.get("shotDistance"), (int, float)) else None,
            "distanceToPin_m": round(record.get("distanceToPin"), 2) if isinstance(record.get("distanceToPin"), (int, float)) else None,
            "lieAfterShot": surface(record.get("surfaceTypeCode")),
            "lieAfterShotCode": record.get("surfaceTypeCode"),
            "lieBeforeShot": surface(event.get("prevSurfaceTypeCode")),
            "lieBeforeShotCode": event.get("prevSurfaceTypeCode"),
            "ballHoled": record.get("ballHoled"),
            "eventType": event.get("eventType"),
            "holeScore": event.get("holeScore"),
            "timestamp": event.get("timestamp"),
            "isProvisional": record.get("isProvisional"),
            "provisionalIndex": record.get("provisionalIndex"),
            "isProvisionalSelected": record.get("isProvisionalSelected"),
            "isBallDrop": record.get("isBallDrop"),
            "x": record.get("x"),
            "z": record.get("z"),
            "seqNum": record.get("seqNum"),
            "commentary": commentary.get(
                (record["_event"], record["_round"], player.get("id"), record.get("holeNo"), stroke), ""
            ),
        }
        # The same shot seen in two payloads is one row -- but only for the same
        # golfer: seqNum counts each player's own records, so two players share
        # (hole, shot, seqNum) all the time and one of them must not vanish.
        fingerprint = (row["event"], row["round"], who(row), row["hole"], row["shot"], row["seqNum"])
        if fingerprint in seen:
            continue
        seen.add(fingerprint)
        rows.append(row)

    # Commentary rows only fill holes the feed never delivered. If a hole is
    # later captured properly, its transcribed version drops out by itself.
    captured_holes = {(r["event"], r["round"], r["hole"]) for r in rows}
    manual = [
        m for m in load_manual(HERE / "manual_shots.json")
        if (m.get("event"), m.get("round"), m.get("hole")) not in captured_holes
    ]
    for row in rows:
        row.setdefault("source", "feed")
    rows += manual

    # Hand-typed rows carry no course; take it from the round's captured shots
    # when the round was played on just one.
    courses: dict[tuple, set] = {}
    for row in rows:
        if row.get("course") not in (None, ""):
            courses.setdefault((row.get("event"), row.get("round")), set()).add(row["course"])
    for row in rows:
        if row.get("course") in (None, ""):
            known = courses.get((row.get("event"), row.get("round")), set())
            if len(known) == 1:
                row["course"] = next(iter(known))

    rows = merge_corrections(rows)
    rows = fill_stroke_gaps(rows, by_hole_shot)
    rows.sort(key=lambda r: (r["event"], r["round"], r["hole"] or 0, r["shot"] or 0))
    out = HERE / "SHOT_BY_SHOT.csv"
    find_shots.write_csv(rows, out)

    # A file per event as well, so one tournament can be opened on its own
    # without filtering a combined sheet.
    for event in sorted({r["event"] for r in rows}):
        in_event = [r for r in rows if r["event"] == event]
        find_shots.write_csv(in_event, HERE / f"SHOT_BY_SHOT_{event}.csv")

    matched = sum(1 for r in rows if r.get("eventType"))
    with_text = sum(1 for r in rows if r.get("commentary"))
    print(f"  text   : {with_text}/{len(rows)} shots have their commentary line")
    if manual:
        holes = sorted({m["hole"] for m in manual})
        print(f"  note   : {len(manual)} shots on hole(s) {holes} come from the commentary,")
        print(f"           not the feed -- marked source=commentary")
    print(f"{len(rows)} shots -> {out.name}")
    people = sorted({(r.get("player"), r.get("teamId")) for r in rows if r.get("player")})
    print("  player : " + "; ".join(f"{name} (team {team})" for name, team in people))
    print(f"  events : {matched}/{len(rows)} shots matched to the event feed")
    if unplaced:
        print(f"  note   : {unplaced} event frame(s) could not be placed on a hole")
    for line in dropped:
        print(f"  note   : {line}")

    # Hand-typed rows carry a name but no id; borrow it from the feed rows.
    ids = {(r.get("event"), r.get("player")): r.get("playerId") for r in rows if r.get("playerId")}
    for row in rows:
        if not row.get("playerId"):
            row["playerId"] = ids.get((row.get("event"), row.get("player")))

    for event in sorted({r["event"] for r in rows}):
        in_event = [r for r in rows if r["event"] == event]
        print(f"\n  {event}  ->  SHOT_BY_SHOT_{event}.csv")
        for round_no in sorted({r["round"] for r in in_event}):
            in_round = [r for r in in_event if r["round"] == round_no]
            holes = sorted({r["hole"] for r in in_round if r["hole"]})
            missing = [h for h in range(1, 19) if h not in holes]
            golfers = sorted({r.get("player") for r in in_round if r.get("player")})
            names = "" if len(golfers) <= 1 else "  [" + ", ".join(golfers) + "]"
            line = f"    round {round_no}: {len(in_round):3d} shots, {len(holes)} holes{names}"
            print(line + (f"  MISSING {missing}" if missing else ""))
            for player_id in sorted({r.get("playerId") for r in in_round if r.get("playerId")}):
                card = scorecards.get((event, player_id, round_no))
                if not card:
                    continue
                counts = {}
                for r in in_round:
                    if r.get("playerId") == player_id:
                        counts[r["hole"]] = counts.get(r["hole"], 0) + 1
                # Holes not captured yet are already listed as MISSING; only a
                # hole that is present but disagrees is a problem worth naming.
                wrong = [f"{h} (site {card[h]}, sheet {counts[h]})"
                         for h in sorted(card) if h in counts and counts[h] != card[h]]
                checked = [h for h in card if h in counts]
                if wrong:
                    print(f"      DIFFERS from the site's scorecard on hole {', '.join(wrong)}")
                elif len(checked) == len(card):
                    print(f"      matches the site's scorecard on all {len(card)} holes ({sum(card.values())})")
                else:
                    print(f"      matches the site's scorecard on the {len(checked)} holes captured so far")
    try:
        input("\nPress Enter to close... ")
    except EOFError:
        pass
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
