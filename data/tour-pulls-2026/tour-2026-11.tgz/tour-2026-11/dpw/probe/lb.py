import json, os, sys, re
from playwright.sync_api import sync_playwright
out = sys.argv[2]
os.makedirs(out, exist_ok=True)
url = sys.argv[1]
with sync_playwright() as pw:
    opts = {"headless": True, "executable_path": "/opt/pw-browsers/chromium-1243/chrome-linux64/chrome"}
    if os.environ.get("HTTPS_PROXY"): opts["proxy"] = {"server": os.environ["HTTPS_PROXY"]}
    b = pw.chromium.launch(**opts)
    ctx = b.new_context(viewport={"width":1400,"height":900}, user_agent="Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36")
    p = ctx.new_page()
    n=[0]
    def onr(r):
        if "api/sportdata" in r.url:
            try:
                body = r.text()
            except Exception: return
            n[0]+=1
            fn = f"{out}/{n[0]:03d}_" + re.sub(r'[^A-Za-z0-9]+','_', r.url.split('sportdata/')[1])[:120] + ".json"
            open(fn,"w").write(body)
            print(r.status, r.url)
    p.on("response", onr)
    p.goto(url, wait_until="domcontentloaded", timeout=60000)
    for s in ("#onetrust-accept-btn-handler",):
        try: p.click(s, timeout=5000)
        except Exception: pass
    p.wait_for_timeout(12000)
    print("TITLE", p.title(), p.url)
    open(f"{out}/page.txt","w").write(p.inner_text("body"))
    b.close()
