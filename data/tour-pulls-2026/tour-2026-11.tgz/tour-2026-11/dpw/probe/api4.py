import json, os, sys
from playwright.sync_api import sync_playwright
page_url = "https://www.europeantour.com/dpworld-tour/dp-world-tour-championship-dubai-2026/leaderboard?round=4"
urls = sys.argv[2:]; out = sys.argv[1]; os.makedirs(out, exist_ok=True)
with sync_playwright() as pw:
    opts = {"headless": True, "executable_path": "/opt/pw-browsers/chromium-1243/chrome-linux64/chrome"}
    if os.environ.get("HTTPS_PROXY"): opts["proxy"] = {"server": os.environ["HTTPS_PROXY"]}
    b = pw.chromium.launch(**opts)
    ctx = b.new_context(viewport={"width":1400,"height":900}, user_agent="Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36")
    p = ctx.new_page(); seen=[]
    def onr(r):
        if "europeantour.com/api" in r.url: seen.append(r.url)
    p.on("response", onr)
    p.goto(page_url, wait_until="domcontentloaded", timeout=60000)
    try: p.click("#onetrust-accept-btn-handler", timeout=8000)
    except Exception: pass
    p.wait_for_timeout(15000)
    print("seen:", *seen, sep="\n  ")
    open(f"{out}/page.txt","w").write(p.inner_text("body"))
    for i,u in enumerate(urls):
        s, body = p.evaluate("async u => {const r = await fetch(u,{credentials:'include'}); return [r.status, await r.text()]}", u)
        print(s, u, len(body))
        open(f"{out}/api_{i}.json","w").write(body)
    b.close()
