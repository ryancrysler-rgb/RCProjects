const fs=require('fs'), R='/home/user/rc-greenlight/automation/';
require(R+'pgatour-adapter.js'); require(R+'metrics.js'); require(R+'liv-adapter.js');
const DPW=require(R+'dpworld-adapter.js');
const N='Joost Luiten - DP World Tour Championship R1';
const sc=JSON.parse(fs.readFileSync(N+' - scorecard.json','utf8'));
const cardPar={},cardScores={},holeLengths={};
sc.holes.forEach(h=>{cardPar[h.hole]=h.par;cardScores[h.hole]=h.strokes;holeLengths[h.hole]=h.officialYardage;});
const text=fs.readFileSync(N+' - shot by shot.csv','utf8');
let res;
try { res=DPW.readCsv(text,{player:'Joost Luiten',round:1,units:'yd',cardPar,cardScores,holeLengths,holeLengthUnits:'yd'}); }
catch(e){ console.log('REFUSED', e.message, JSON.stringify(e.problems||e.details||null)); process.exit(1); }
console.log('ok',res.ok,'card',JSON.stringify(res.card)); console.log('meta',JSON.stringify(res.meta)); console.log('notes',JSON.stringify(res.notes));
console.log(Object.keys(res.holes[0]), JSON.stringify(res.holes[0]).slice(0,800));
fs.writeFileSync('probe/readcsv.json', JSON.stringify(res,null,1));
