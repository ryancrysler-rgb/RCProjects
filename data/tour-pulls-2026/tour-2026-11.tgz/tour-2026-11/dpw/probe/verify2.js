const fs=require('fs'), R='/home/user/rc-greenlight/automation/';
require(R+'pgatour-adapter.js'); require(R+'metrics.js'); require(R+'liv-adapter.js');
const DPW=require(R+'dpworld-adapter.js');
const [P,rnd]=process.argv.slice(2); const N=`${P} - DP World Tour Championship R${rnd}`;
const sc=JSON.parse(fs.readFileSync(N+' - scorecard.json','utf8'));
const cardPar={},cardScores={},holeLengths={};
sc.holes.forEach(h=>{cardPar[h.hole]=h.par;cardScores[h.hole]=h.strokes;holeLengths[h.hole]=h.officialYardage;});
try { const res=DPW.readCsv(fs.readFileSync(N+' - shot by shot.csv','utf8'),{player:P,round:+rnd,units:'yd',cardPar,cardScores,holeLengths,holeLengthUnits:'yd'});
  console.log('R'+rnd,'ok',res.ok,JSON.stringify(res.card),JSON.stringify(res.meta.parFrom),JSON.stringify(res.notes));
  fs.writeFileSync(`probe/readcsv_${P.replace(/ /g,'_')}_R${rnd}.json`,JSON.stringify(res,null,1));
} catch(e){ console.log('R'+rnd,'REFUSED',e.message,JSON.stringify(e.problems||null)); }
