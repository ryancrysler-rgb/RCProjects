import json, os, sys, re
from playwright.sync_api import sync_playwright
out = sys.argv[2]; os.makedirs(out, exist_ok=True)
with sync_playwright() as pw:
    opts = {"headless": True, "executable_path": "/opt/pw-browsers/chromium-1243/chrome-linux64/chrome"}
    if os.environ.get("HTTPS_PROXY"): opts["proxy"] = {"server": os.environ["HTTPS_PROXY"]}
    b = pw.chromium.launch(**opts)
    ctx = b.new_context(viewport={"width":1400,"height":900}, user_agent="Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36")
    p = ctx.new_page(); n=[0]
    def onr(r):
        if r.request.resource_type in ("xhr","fetch"):
            print(r.status, r.url[:200])
            try: body=r.text()
            except Exception: return
            n[0]+=1
            open(f"{out}/{n[0]:03d}.json","w").write(json.dumps({"url":r.url,"status":r.status,"body":body}))
    p.on("response", onr)
    p.goto(sys.argv[1], wait_until="domcontentloaded", timeout=60000)
    try: p.click("#onetrust-accept-btn-handler", timeout=8000)
    except Exception as e: print("no consent", e)
    p.wait_for_timeout(20000)
    p.mouse.wheel(0,3000); p.wait_for_timeout(5000)
    open(f"{out}/page.txt","w").write(p.inner_text("body"))
    p.screenshot(path=f"{out}/shot.png", full_page=False)
    b.close()
