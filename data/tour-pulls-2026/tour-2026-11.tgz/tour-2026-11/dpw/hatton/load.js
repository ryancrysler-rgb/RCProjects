const fs=require('fs');const E='/home/user/rc-greenlight/automation/';
global.METRICS=require(E+'metrics.js');global.LIV=require(E+'liv-adapter.js');const DW=require(E+'dpworld-adapter.js');
for (const r of [1,2,3,4]) {
  const card=JSON.parse(fs.readFileSync(__dirname+'/r'+r+'-scorecard.json','utf8'));
  const o=DW.readCsv(fs.readFileSync(__dirname+'/r'+r+'-raw.csv','utf8'),{player:'Tyrrell Hatton',round:r,units:'yd',cardPar:Object.fromEntries(card.holes.map(h=>[h.hole,h.par])),cardScores:Object.fromEntries(card.holes.map(h=>[h.hole,h.strokes])),holeLengths:Object.fromEntries(card.holes.map(h=>[h.hole,h.officialYardage])),holeLengthUnits:'yd'});
  fs.writeFileSync(__dirname+'/r'+r+'.csv',o.csv);
  const H=require(E+'shot-csv.js').parse(o.csv).holes;
  console.log('R'+r,o.ok,H.length,'holes',H.reduce((a,h)=>a+h.score,0),'card',card.strokes,'par',H.reduce((a,h)=>a+h.par,0),JSON.stringify(o.notes).slice(0,300));
}
