const { chromium } = require('playwright');
(async () => { const b = await chromium.launch(); const p = await b.newPage({ viewport: { width: 1000, height: 1300 }, deviceScaleFactor: 2 });
  await p.goto('file://' + __dirname + '/p2.html'); await p.waitForTimeout(1500);
  await p.addStyleTag({ content: '#savepdf{display:none!important} #sheet{display:none!important}' });
  await (await p.$('#sheet2')).screenshot({ path: __dirname + '/p2.png' });
  await p.emulateMedia({ media: 'print' }); await p.pdf({ path: __dirname + '/p2.pdf', width: '8.5in', height: '11in', printBackground: true });
  await b.close(); })();
