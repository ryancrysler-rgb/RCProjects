const fs=require('fs');const E='/home/user/rc-greenlight/automation/';
global.METRICS=require(E+'metrics.js');global.LIV=require(E+'liv-adapter.js');const DW=require(E+'dpworld-adapter.js');
const card=JSON.parse(fs.readFileSync(__dirname+'/Joost Luiten - DP World Tour Championship R1 - scorecard.json','utf8'));
const text=fs.readFileSync(__dirname+'/Joost Luiten - DP World Tour Championship R1 - shot by shot.csv','utf8');
function load(){ const out=DW.readCsv(text,{player:'Joost Luiten',round:1,units:'yd',cardPar:Object.fromEntries(card.holes.map(h=>[h.hole,h.par])),cardScores:Object.fromEntries(card.holes.map(h=>[h.hole,h.strokes])),holeLengths:Object.fromEntries(card.holes.map(h=>[h.hole,h.officialYardage])),holeLengthUnits:'yd'}); return out; }
module.exports={load,card};
if(require.main===module){const o=load();console.log(Object.keys(o));const H=o.holes||o.table||o;console.log(Array.isArray(H)?H.length:typeof H, JSON.stringify(Array.isArray(H)?H[0]:o).slice(0,700));}
