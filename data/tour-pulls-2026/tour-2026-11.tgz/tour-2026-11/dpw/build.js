const path=require('path'),fs=require('fs');const ROOT='/home/user/rc-greenlight';const A=f=>require(path.join(ROOT,'automation',f));
const SC=A('shot-csv.js'),M=A('metrics.js'),RP=A('round-patterns.js'),RB=A('raw-report-builder.js');
const H=SC.parse(fs.readFileSync('luiten-r1-table.csv','utf8')).holes;const BAGX=require('../tour-avg-bag.js').bag(JSON.parse(fs.readFileSync('p2spec.json','utf8')).bag.clubs.map(c=>c.name));H._bag=A('bag-clubs.js').apply(H,BAGX);
const sm=M.summary(H);const p=RP.patterns(H,{startHole:1});p.response=M.clutchFactorResponse(H,{order:p.order});p.closing=M.clutchFactorClosing(H,{behind:0,order:p.order});
const ai=JSON.parse(fs.readFileSync('ai.json','utf8'));
const rd=RB.buildRawReportData({player:'Joost Luiten',event:'DP World Tour Championship 2026 · Round 1',par:72,round:{score:67,toPar:'−5',note:'Leads after round 1'},
 putts:sm.putts.value,birdies:sm.counts.birdies,holes:H,plan:null,facets:null,summary:sm,patterns:p,
 totals:{fw:sm.fairways.display,par:72,yards:H.reduce((a,h)=>a+(h.yards||0),0)||'',gir:sm.gir.display,putts:sm.putts.value,flags:''},
 footnote:ai.footnote,identity:'RC Greenlight · Raw',decisionGained:null,inBand:null,bandsFrom:null,ai,bag:BAGX});
fs.writeFileSync('rd.json',JSON.stringify(rd));
const tpl=fs.readFileSync(path.join(ROOT,'automation/raw-report.template.html'),'utf8');
const out=tpl.replace('<!--__DATA_SLOT__-->','<script>window.__REPORT_DATA='+JSON.stringify(rd).replace(/</g,'\\u003c')+';</script>').replace(/__SITE_URL__/g,'file://'+ROOT);
fs.writeFileSync('Joost Luiten - DP World Tour Championship R1 - Raw.html',out);
console.log('rules',JSON.stringify(rd.rules.map(r=>[r.n,r.state])),'dom',JSON.stringify(rd.clutch.dominance),'bag',JSON.stringify(H._bag).slice(0,300));
