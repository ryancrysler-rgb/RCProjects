const path=require('path'),fs=require('fs');const ROOT='/home/user/rc-greenlight';const A=f=>require(path.join(ROOT,'automation',f));
const M=A('metrics.js'),RP=A('round-patterns.js'),RB=A('raw-report-builder.js');const BG=require('./bag.js');
const H=BG.holes(2);const sm=M.summary(H);const p=RP.patterns(H,{startHole:1});p.response=M.clutchFactorResponse(H,{order:p.order});p.closing=M.clutchFactorClosing(H,{behind:1,order:p.order});
const ai=JSON.parse(fs.readFileSync('ai.json','utf8'));
const rd=RB.buildRawReportData({player:'Rory McIlroy',event:'DP World Tour Championship 2026 · Round 2',par:72,round:{score:70,toPar:'−2',note:'Leads after round 2 · −5'},
 putts:sm.putts.value,birdies:sm.counts.birdies,holes:H,plan:null,facets:null,summary:sm,patterns:p,
 totals:{fw:sm.fairways.display,par:72,yards:H.reduce((a,h)=>a+(h.yards||0),0)||'',gir:sm.gir.display,putts:sm.putts.value,flags:''},
 footnote:ai.footnote,identity:'RC Greenlight · Raw',decisionGained:null,inBand:null,bandsFrom:null,ai,bag:BG.BAG});
fs.writeFileSync('rd.json',JSON.stringify(rd));
const tpl=fs.readFileSync(path.join(ROOT,'automation/raw-report.template.html'),'utf8');
fs.writeFileSync('Rory McIlroy - DP World Tour Championship R2 - Raw.html',tpl.replace('<!--__DATA_SLOT__-->','<script>window.__REPORT_DATA='+JSON.stringify(rd).replace(/</g,'\\u003c')+';</script>').replace(/__SITE_URL__/g,'file://'+ROOT));
console.log('rules',JSON.stringify(rd.rules.map(r=>[r.n,r.state])),'dom',JSON.stringify(rd.clutch&&rd.clutch.dominance&&rd.clutch.dominance.total));
