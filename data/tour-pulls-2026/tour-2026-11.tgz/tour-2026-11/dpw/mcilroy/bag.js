/* Rory McIlroy's bag, from his published stock yardages: Golf Monthly, "How Far Rory McIlroy Hits Every Club In The Bag", from
 * TaylorMade's video of 20 October 2022 — one number per club, read as the club's number (the source does not say carry or total).
 * The 2026 set changed (new irons, a Qi4D driver and 3-wood); no 2026 yardages are published, so these are the latest numbers.
 * Wedges by loft: PW 150, 54° = SW 125, 58° = LW 105 (no gap wedge is listed). */
'use strict';
const E = '/home/user/rc-greenlight/automation/';
const SC = require(E + 'shot-csv.js'), BC = require(E + 'bag-clubs.js'), fs = require('fs');
const BAG = { units: 'yd', clubs: [['Driver', 320], ['3W', 300], ['5W', 275], ['3i', 260], ['4i', 240], ['5i', 225], ['6i', 210], ['7i', 195], ['8i', 180], ['9i', 165],
  ['PW', 150], ['SW', 125], ['LW', 105]].map(([name, total]) => ({ name, total, tee: /Driver|W$/.test(name) })) };
const WEDGE_MAX = 150;
function holes(r) { const h = SC.parse(fs.readFileSync(__dirname + '/r' + r + '.csv', 'utf8')).holes; const res = BC.apply(h, BAG); h._bag = res; return h; }
module.exports = { BAG, WEDGE_MAX, holes };
