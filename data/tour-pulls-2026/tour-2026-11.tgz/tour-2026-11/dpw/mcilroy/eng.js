const path=require('path'),fs=require('fs');const A=f=>require(path.join('/home/user/rc-greenlight/automation',f));
const M=A('metrics.js'),RP=A('round-patterns.js'),NN=A('nn-grade.js'),RB=A('raw-report-builder.js');const BG=require('./bag.js');
for (const r of [1,2]) { const H=BG.holes(r);
const sm=M.summary(H);const p=RP.patterns(H,{startHole:1});p.response=M.clutchFactorResponse(H,{order:p.order});
console.log('=== R'+r, JSON.stringify(sm.card),'fw',sm.fairways.display,'gir',sm.gir.display,'putts',sm.putts.value,'scr',sm.scrambling.display,'sand',sm.sandSaves.display,'bc',sm.birdieConversion.display,JSON.stringify(sm.counts));
console.log('CF putt',JSON.stringify(sm.clutchFactorPutting.display),'bs',JSON.stringify(sm.clutchFactorBallStriking.display),JSON.stringify((sm.clutchFactorBallStriking.holes||[]).map(h=>h.hole+':'+h.cause+':'+h.toPar)),'dc',JSON.stringify(sm.clutchFactorDamageControl.display),'resp',JSON.stringify({a:p.response.att,s:p.response.stopped,an:p.response.answered}),'dom',JSON.stringify(M.clutchFactorDominance(H,{order:p.order})));
console.log('NN',JSON.stringify(NN.grade(H,{wedgeMaxYd:BG.WEDGE_MAX}).rules.map(x=>[x.n,x.state,x.level||'',(x.evidence||[]).slice(0,4)])));
console.log('p5',JSON.stringify(p.par5),'stretch',JSON.stringify(p.stretches),'mk',JSON.stringify(p.makers),'rt',JSON.stringify(p.roots));
console.log('bands',JSON.stringify(RB.ladderCounts(H,'yd').filter(b=>b.n).map(b=>b.label+' '+b.made+'/'+b.n)));
H.forEach(h=>console.log(' ',h.hole,'p'+h.par,h.score,h.shots.map(s=>s.isPutt?('putt '+s.startFt+(s.holed?' IN':'')):((s.club||'?')+' '+Math.round(s.startYd)+' '+s.startLie+'>'+s.endLie)).join(' | ')));
}
