const fs=require('fs');const E='/home/user/rc-greenlight/automation/';
global.METRICS=require(E+'metrics.js');global.LIV=require(E+'liv-adapter.js');const DW=require(E+'dpworld-adapter.js');
const P='/tmp/claude-0/-home-user/c0cfce94-7d29-53ae-a568-1ec015f2a64a/scratchpad/tour-2026-11/dpw/Rory McIlroy - DP World Tour Championship R';
for (const r of [1,2]) {
  const card=JSON.parse(fs.readFileSync(P+r+' - scorecard.json','utf8'));
  const o=DW.readCsv(fs.readFileSync(P+r+' - shot by shot.csv','utf8'),{player:'Rory McIlroy',round:r,units:'yd',cardPar:Object.fromEntries(card.holes.map(h=>[h.hole,h.par])),cardScores:Object.fromEntries(card.holes.map(h=>[h.hole,h.strokes])),holeLengths:Object.fromEntries(card.holes.map(h=>[h.hole,h.officialYardage])),holeLengthUnits:'yd'});
  fs.writeFileSync('r'+r+'.csv',o.csv);
  const H=require(E+'shot-csv.js').parse(o.csv).holes;
  console.log('R'+r,o.ok,o.meta.parFrom,H.length,'holes',H.reduce((a,h)=>a+h.score,0),'par',H.reduce((a,h)=>a+h.par,0),JSON.stringify(o.notes));
}
