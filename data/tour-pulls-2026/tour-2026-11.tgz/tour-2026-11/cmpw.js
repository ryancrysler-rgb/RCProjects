const fs=require('fs'),path=require('path');const E='/home/user/rc-greenlight/automation/';
const SC=require(E+'shot-csv.js'),SR=require(E+'summary-rules.js'),BC=require(E+'bag-clubs.js'),M=require(E+'metrics.js');
function load(dir){const spec=JSON.parse(fs.readFileSync(dir+'/p2spec.json','utf8'));
 const rounds=spec.rounds.map(r=>{const h=SC.parse(fs.readFileSync(path.resolve(dir,r.csv),'utf8')).holes;h._bag=BC.apply(h,spec.bag);return{n:r.n,holes:h,source:'files',order:r.order}});
 const P=SR.page(rounds,{units:'yd',wedgeMaxYd:spec.wedgeMaxYd});require('../page2fix.js').fix(P,rounds,spec.wedgeMaxYd);
 const out={};(P.groups||[]).forEach(g=>(g.rules||[]).forEach(r=>(r.rows||[]).forEach(w=>{out[r.name+' | '+w.label]=w.week+' ['+(w.cells||[]).join(' ')+']'})));
 const all=rounds.flatMap(r=>r.holes);const sm=M.summary(all);
 out['_FW']=sm.fairways.display;out['_GIR']=sm.gir.display;out['_putts']=sm.putts.value;out['_birdies']=sm.counts.birdies;
 return out;}
const R=load('pga/ramey'),H=load('dpw/hatton/final');
for(const k of new Set([...Object.keys(R),...Object.keys(H)]))console.log(k.padEnd(95),'| R',String(R[k]).padEnd(32),'| H',H[k]);
