/* Page 2 (the leader vs the house rules) on the engine itself (summary-rules v3, house rules v18.3): rule 10's go-not-lay-up and
 * rule 02's not-measured-without-clubs are the engine's own now; nothing here re-grades. Args: a JSON spec file. */
'use strict';
const fs = require('fs'), path = require('path');
const E = '/home/user/rc-greenlight/automation/';
const SC = require(E + 'shot-csv.js'), SR = require(E + 'summary-rules.js'), SLOT = require(E + 'data-slot.js'), BC = require(E + 'bag-clubs.js');
const spec = JSON.parse(fs.readFileSync(process.argv[2], 'utf8'));
const rounds = spec.rounds.map((r) => { const h = SC.parse(fs.readFileSync(r.csv, 'utf8')).holes; if (spec.bag) h._bag = BC.apply(h, spec.bag); return { n: r.n, holes: h, source: 'files', order: r.order || null }; });
const P = SR.page(rounds, { units: 'yd', wedgeMaxYd: spec.wedgeMaxYd || null });
if (spec.page2fix) require('/tmp/claude-0/-home-user/c0cfce94-7d29-53ae-a568-1ec015f2a64a/scratchpad/page2fix.js').fix(P, rounds, spec.wedgeMaxYd);
P.notes = P.notes.filter((n) => !/stored files|playing order from hole 1/.test(n)).concat(spec.notes || []);
const tpl = fs.readFileSync(E + 'tournament-summary.template.html', 'utf8');
fs.writeFileSync(spec.out, SLOT.fill(tpl, { player: spec.player, event: spec.event, rounds: rounds.length, roundNumbers: rounds.map((r) => r.n), scores: spec.scores, total: spec.scores.reduce((a, b) => a + b, 0), par: 72, facets: {}, holes: [], swot: {}, rulesPage: P }, 'tournament summary'));
console.log(P.read.headline, '|', P.levels.map((x) => x.level).join(' '));
