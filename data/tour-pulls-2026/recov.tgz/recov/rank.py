import json,re,statistics as S,csv
def num(v):
    v=str(v).strip();m=re.match(r"^(\d+)' (\d+)\"$",v)
    if m: return int(m.group(1))+int(m.group(2))/12
    try: return float(v.replace('%','').replace(',','').replace('+',''))
    except: return None
def load(i):
    d=json.load(open(i+'.json'));o={}
    for r in d['rows']:
        if r.get('stats'): o[r['playerName']]=[s['statValue'] for s in r['stats']]
    return o
st={i:load(i) for i in '199 02371 02336 374 130 363 111 02569 115 404 02427 02564 120 437'.split()}
P=set(st['199'])
for k in st: P&=set(st[k])
def z(i,col=0,neg=False):
    v={p:num(st[i][p][col]) for p in P}; m=S.mean(v.values()); s=S.pstdev(v.values())
    return {p:((m-x) if neg else (x-m))/s for p,x in v.items()}
def board(parts):
    zs=[z(*a) for a in parts]; return sorted(P,key=lambda p:-sum(zz[p] for zz in zs)), {p:sum(zz[p] for zz in zs)/len(zs) for p in P}
out={}
for name,parts in [('recovery',[('199',),('02371',0,True)]),('shortgame',[('374',0,True),('130',)]),('putting',[('115',),('404',)])]:
    order,sc=board(parts); out[name]=(order,sc)
def show(name,cols):
    order,sc=out[name]; print('\n==',name,'(n=%d)'%len(order))
    for k,p in enumerate(order[:12],1):
        print(k,p,round(sc[p],2),' | '.join(f"{lab} {st[i][p][c]}" for lab,i,c in cols))
show('recovery',[('GIR off FW','199',0),('holes','199',2),('rough>100','02371',0),('att','02371',2),('birdie% rough','02336',0)])
show('shortgame',[('ARG prox','374',0),('shots','374',2),('scramb','130',0),('missed GIR','130',2),('sand save','111',0),('SG ARG','02569',0)])
show('putting',[('birdie conv','115',0),('GIR','115',2),('5-10','404',0),('att','404',1),('3-5','02427',0),('SG putt','02564',0)])
for i in ['199','02371','374','130','115','404','02427']:
    d=json.load(open(i+'.json')); print(i,d['statTitle'],'tour avg',d.get('tourAvg'))
json.dump({k:[(p,round(v[1][p],3)) for p in v[0]] for k,v in out.items()},open('boards.json','w'))
# overall who appears top 20 in 2+
from collections import Counter
c=Counter(p for k in out for p in out[k][0][:20]); print([x for x in c.items() if x[1]>=2])
