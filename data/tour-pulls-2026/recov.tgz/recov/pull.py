import json,re,sys,subprocess,time
def stat(i):
    for a in range(3):
        h=subprocess.run(['curl','-sS','-m','30','-A','Mozilla/5.0','https://www.pgatour.com/stats/detail/'+i],capture_output=True,text=True).stdout
        m=re.search(r'<script id="__NEXT_DATA__"[^>]*>(.*?)</script>',h,re.S)
        if m:
            qs=[q['state']['data'] for q in json.loads(m.group(1))['props']['pageProps']['dehydratedState']['queries']]
            d=next((x for x in qs if isinstance(x,dict) and x.get('statType')=='YTD' and x.get('rows')),None) or next((x for x in qs if isinstance(x,dict) and x.get('rows')),None)
            if d: return d
        time.sleep(1)
for i in sys.argv[1:]:
    d=stat(i); json.dump(d,open(i+'.json','w'))
    r=[x for x in d['rows'] if x.get('stats')]
    print(i,d.get('statTitle'),'| asOf',d.get('lastProcessed'),'| tourAvg',d.get('tourAvg'),'| n',len(r),'| headers',d.get('statHeaders'),'|',r[0]['playerName'],[s['statValue'] for s in r[0]['stats']])
