const { launch, serve, context } = require('/home/user/rc-greenlight/tools/tests/_lib');
const fs = require('fs');
(async () => { const srv = await serve(), b = await launch();
  const html = fs.readFileSync(__dirname + '/summary.html', 'utf8').replace(/file:\/\/\/home\/user\/rc-greenlight/g, srv.origin);
  const tmp = '/home/user/rc-greenlight/.tmp-cam-sum.html'; fs.writeFileSync(tmp, html);
  const c = await context(b, { width: 1000, height: 1300 }); const p = await c.newPage(); const errs = []; p.on('pageerror', (e) => errs.push(e.message));
  await p.goto(srv.origin + '/.tmp-cam-sum.html', { waitUntil: 'networkidle' }); await p.waitForTimeout(2000);
  const info = await p.evaluate(() => [...document.querySelectorAll('#sheet,#sheet2')].map((s) => { const box = s.getBoundingClientRect(); const over = [];
    s.querySelectorAll('*').forEach((e) => { if (!e.children.length && e.textContent.trim() && (e.scrollWidth > e.clientWidth + 2 || e.scrollHeight > e.clientHeight + 2) && /hidden|clip/.test(getComputedStyle(e).overflow + getComputedStyle(e).overflowY)) over.push(e.textContent.trim().slice(0, 50)); });
    return { id: s.id, h: Math.round(box.height), over: over.slice(0, 8) }; }));
  console.log(JSON.stringify(info), errs);
  await p.addStyleTag({ content: '#savepdf{display:none!important}' });
  for (const id of ['sheet', 'sheet2']) { const el = await p.$('#' + id); if (el) await el.screenshot({ path: __dirname + '/' + id + '.png' }); }
  await p.emulateMedia({ media: 'print' }); await p.pdf({ path: __dirname + '/Cameron Smith - PGA Championship 2026 - Tournament Summary.pdf', width: '8.5in', height: '11in', printBackground: true });
  fs.unlinkSync(tmp); await b.close(); await srv.close(); })();
