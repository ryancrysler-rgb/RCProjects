'use strict';
const fs = require('fs'); const A = (f) => require('/home/user/rc-greenlight/automation/' + f);
const SC = A('shot-csv.js'), BC = A('bag-clubs.js'), M = A('metrics.js'), RP = A('round-patterns.js'), RB = A('raw-report-builder.js');
const { BAG, WEDGE_MAX_YD } = require('./bag.js');
const SCORES = { 1: 69, 2: 71, 3: 68, 4: 68 }, NOTE = { 1: 'T15 after round 1', 2: 'T22 after round 2', 3: 'T11 after round 3', 4: 'T7 final' };
const BEHIND = { 1: null, 2: 2, 3: 4, 4: 4 };   // shots back starting the round (derived from the leaderboard round scores, season file)
function holes(r) { const h = SC.parse(fs.readFileSync(__dirname + '/r' + r + '.csv', 'utf8')).holes; h._bag = BC.apply(h, BAG); return h; }
function rd(r, ai) {
  const H = holes(r), order = JSON.parse(fs.readFileSync(__dirname + '/r' + r + '-order.json'));
  const sm = M.summary(H); const p = RP.patterns(H, { startHole: order[0] });
  p.response = M.clutchFactorResponse(H, { order: p.order });
  if (BEHIND[r] != null && BEHIND[r] <= 3) p.closing = M.clutchFactorClosing(H, { behind: BEHIND[r], order: p.order });
  return RB.buildRawReportData({ player: 'Cameron Smith', event: 'PGA Championship 2026 · Round ' + r, par: 70, round: { score: SCORES[r], toPar: (SCORES[r] - 70 > 0 ? '+' : SCORES[r] === 70 ? 'E' : '−') + Math.abs(SCORES[r] - 70 || 0), note: NOTE[r] },
    putts: sm.putts.value, birdies: sm.counts.birdies, holes: H, plan: null, facets: null, summary: sm, patterns: p, wedgeMaxYd: WEDGE_MAX_YD, bag: BAG,
    totals: { fw: sm.fairways.display, par: 70, yards: '', gir: sm.gir.display, putts: sm.putts.value, flags: '' },
    footnote: (ai && ai.footnote) || 'x', identity: 'RC Greenlight · Raw', decisionGained: null, inBand: null, bandsFrom: null, ai: ai || { decisions: Object.fromEntries(Array.from({ length: 18 }, (_, i) => [String(i + 1), 'data only'])) } });
}
module.exports = { holes, rd, SCORES };
if (require.main === module) for (const r of [1, 2, 3, 4]) { try { const d = rd(r); fs.writeFileSync('rd' + r + '.json', JSON.stringify(d));
  console.log('R' + r, JSON.stringify(d.rules.map((x) => [x.n, x.state, x.stat || x.level || ''])), 'dom', d.clutch && d.clutch.dominance && (d.clutch.dominance.achieved + '/' + d.clutch.dominance.total), 'bag', JSON.stringify(d.holes ? '' : ''));
  } catch (e) { console.log('R' + r, 'ERR', e.message.slice(0, 300)); } }
