'use strict';
const fs = require('fs'); const A = (f) => require('/home/user/rc-greenlight/automation/' + f);
const TS = A('tournament-summary.js'), SLOT = A('data-slot.js');
const { data, P } = require('./week.js');
const pr = JSON.parse(fs.readFileSync(__dirname + '/prose.json', 'utf8'));
// page 2 in metres (page2fix wrote the yard label); notes: what this summary is read from
P.groups[0].rules.forEach((r) => r.rows.forEach((row) => { if (row.label === 'Full wedges (40 yd+)') row.label = 'Full wedges (37 m+)'; }));
P.notes = P.notes.filter((n) => !/stored files/.test(n)).concat([
  'R1–R4: pgatour.com shot data, every hole adding up to the official card (69, 71, 68, 68 = 276, −4, T7); R1 played from the 10th',
  'Metres: every distance converted from the file’s yards (× 0.9144) on the owner’s instruction of 2026-11-04; putting in feet',
  'Clubs read from the owner’s sheet “Cam Smith Yardage” (2026-05-07): 46° = PW, 52° = GW, 56° = SW, 60° = LW; the PW (130 m) is the wedge ceiling']);
// Clutch Factor Closing, round 4 only (owner 2026-11-13: "just for round 4. He was within one at one point versus the leader"):
// the last nine holes played, to par; no field comparison (no per-hole field averages in the files).
{ const g = P.groups[2], i = g.rules.findIndex((r) => r.name === 'Clutch Factor Damage Control');
  g.rules.splice(i + 1, 0, { name: 'Clutch Factor Closing', rows: [{ kind: 'count', label: 'Last nine holes, to par (round 4)', cells: ['—', '—', '—', '+1'], week: '+1' }, { kind: 'count', label: 'The winner, Aaron Rai, on the same nine', cells: ['—', '—', '—', '−4'], week: '−4' }] });
  P.notes.push('Clutch Factor Closing: round 4 only (owner). Round 4 hole by hole against the winner (same holes played, not the same moment on the clock): level after 6, 7, 9 and 10, one ahead after 8; the last nine, Cam +1 and Aaron Rai −4 (birdies 11, 13, 16, 17), from the winner’s own pgatour.com shot data (70, 69, 67, 65 = 271, −9)'); }
Object.assign(data, TS.nameInFull(pr), { rulesPage: P, sourceNote: 'Built from four round tables read from the pgatour.com shot data (each adding up to its official card) and graded by the RC Greenlight engine; distances in metres, converted from the file\u2019s yards on the owner\u2019s instruction' });
const NV = TS.checkWords(TS.proseOf(data), 'cam-pga', null);
console.log('gate', NV.ok ? 'PASS' : 'HOLD', (NV.list || NV.findings || []).filter((x) => x.severity === 'blocking').map((x) => x.id + ': ' + x.message).slice(0, 8));
let html = SLOT.fill(fs.readFileSync('/home/user/rc-greenlight/automation/tournament-summary.template.html', 'utf8'), data, 'tournament summary').replace(/__SITE_URL__/g, 'file:///home/user/rc-greenlight');
try { html = A('racing-report.js').applyTo(html, { sector: 4 }); } catch (e) { console.log('racing', e.message); }
fs.writeFileSync(__dirname + '/summary.html', html);
