'use strict';
const fs = require('fs'); const A = (f) => require('/home/user/rc-greenlight/automation/' + f);
const TS = A('tournament-summary.js'), SR = A('summary-rules.js');
const R = require('./rounds.js'); const { WEDGE_MAX_YD } = require('./bag.js');
const rows = [1, 2, 3, 4].map((r) => ({ report_data: Object.assign(JSON.parse(fs.readFileSync(__dirname + '/rd' + r + '.json')), { roundNumber: r }), link: null }));
const data = TS.assemble(rows, { playerName: 'Cameron Smith', event: 'PGA Championship 2026', finish: 'T7 (276, −4)' });
const rounds = [1, 2, 3, 4].map((r) => ({ n: r, holes: R.holes(r), source: 'files', order: JSON.parse(fs.readFileSync(__dirname + '/r' + r + '-order.json')) }));
const P = SR.page(rounds, { units: 'm', wedgeMaxYd: WEDGE_MAX_YD });
require('/tmp/claude-0/-home-user/c0cfce94-7d29-53ae-a568-1ec015f2a64a/scratchpad/page2fix.js').fix(P, rounds, WEDGE_MAX_YD);
module.exports = { data, P, rows };
if (require.main === module) {
  const c = Object.assign({}, data, { holes: data.holes.map((h) => ({ h: h.h, par: h.par, scores: h.scores })) });
  fs.writeFileSync('computed.json', JSON.stringify(c, null, 1));
  console.log(JSON.stringify(data.facets, null, 1)); console.log(JSON.stringify(data.parTypes), data.total, data.toPar);
  console.log('READ', P.read.headline, '|', P.levels.map((x) => x.level).join(' '));
  P.groups.forEach((g) => g.rules.forEach((r) => r.rows.forEach((row, i) => console.log((i ? '   ' : '') + (i ? '' : r.name + ' :: ') + row.label + ' | ' + JSON.stringify(row.cells) + ' wk ' + JSON.stringify(row.week || row.weekText || '') + (row.why ? ' why ' + row.why : '')))));
  console.log(P.notes);
}
