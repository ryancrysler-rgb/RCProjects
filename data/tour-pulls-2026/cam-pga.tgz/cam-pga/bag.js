/* Cameron Smith's bag: the owner's Drive sheet "Cam Smith Yardage" (2026-05-07), metres as the sheet gives them (carry or total not
 * stated; read as each club's one number). Wedges by loft: 46 = PW, 52 = GW, 56 = SW, 60 = LW. PW 130 m = the wedge ceiling. */
'use strict';
const BAG = { units: 'm', clubs: [['Driver', 265], ['3W', 240], ['7W', 217], ['4i', 204], ['5i', 194], ['6i', 180], ['7i', 167], ['8i', 154], ['9i', 142],
  ['PW', 130], ['GW', 114], ['SW', 100], ['LW', 60]].map(([name, total]) => ({ name, total, tee: /Driver|W$/.test(name) })) };
module.exports = { BAG, WEDGE_MAX_M: 130, WEDGE_MAX_YD: Math.round(130 * 1.09361 * 10) / 10 };
