// The compact files (one array per stroke) back to the pgatour shape the converter reads; checks every hole and round.
'use strict';
const fs = require('fs'); const CARD = { 1: 70, 2: 69, 3: 67, 4: 65 };
for (const r of [1, 2, 3, 4]) {
  const src = JSON.parse(fs.readFileSync(__dirname + '/46414-r' + r + '.json', 'utf8')); const bad = []; let tot = 0;
  const holes = src.map((h) => { tot += +h.score;
    const strokes = h.strokes.map((s, i) => ({ strokeType: s[0], distance: s[1], distanceRemaining: s[2], fromLocation: s[3], fromLocationCode: s[4], toLocation: s[5], toLocationCode: s[6], finalStroke: s[7] }));
    const n = strokes.filter((s) => s.strokeType !== 'DROP').length; if (n !== +h.score) bad.push('H' + h.holeNumber + ' ' + n + ' strokes vs ' + h.score);
    if (!strokes[strokes.length - 1].finalStroke) bad.push('H' + h.holeNumber + ' last not holed');
    return Object.assign({}, h, { strokes }); });
  if (holes.length !== 18 || new Set(holes.map((h) => h.holeNumber)).size !== 18) bad.push('holes ' + holes.length);
  if (tot !== CARD[r]) bad.push('adds to ' + tot + ' card ' + CARD[r]);
  fs.writeFileSync(__dirname + '/35891-shape-r' + r + '.json', JSON.stringify(holes));
  console.log('Rai R' + r, 'total', tot, '| problems', bad.length ? bad : 'none');
}
