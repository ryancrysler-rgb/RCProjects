/* Cameron Smith, PGA Championship 2026, R1-R4, from the pgatour.com ShotLink files kept in research/cam-majors-2026/pga.
 * Owner 2026-11-04: "convert to meters for all Cams data" -> every distance yd x 0.9144, putts in feet. Same conversion as the
 * tour converter: surface lies, PENALTY = a stroke, DROP not; every hole adds to its score, the round to the card. */
'use strict';
const fs = require('fs'); const E = '/home/user/rc-greenlight/automation/';
const PGA = require(E + 'pgatour-adapter.js'), LIV = require(E + 'liv-adapter.js');
function surface(name, code) { const n = String(name || ''), c = String(code || '').toUpperCase();
  if (c === 'OTB' || /^tee box$/i.test(n)) return 'Tee'; if (/bunker/i.test(n)) return 'Bunker'; if (/fairway/i.test(n)) return 'Fairway';
  if (/green/i.test(n)) return 'Green'; if (/rough/i.test(n)) return 'Rough'; if (!n && !c) return ''; return 'Other'; }
const M = (yd) => Math.round(yd * 0.9144 * 10) / 10;
const fmt = (yd, onGreen) => (yd == null ? '' : onGreen ? (Math.round(yd * 3 * 10) / 10) + ' ft' : M(yd) + ' m');
const COLS = ['Hole', 'Par', 'Score', 'Shot', 'Category', 'Club', 'Start Lie', 'End Lie', 'Start Distance', 'Putt Distance', 'Shot Distance', 'Proximity', 'Penalty', 'Hole Yardage'];
const CARD = { 1: 69, 2: 71, 3: 68, 4: 68 };
for (const r of [1, 2, 3, 4]) {
  const holes = JSON.parse(fs.readFileSync('/home/user/rc-greenlight/research/cam-majors-2026/pga/35891-r' + r + '.json'));
  const out = [COLS.join(',')], problems = []; let total = 0; const order = [];
  for (const h of holes) {
    const score = +h.score, par = +h.par; total += score; order.push(h.holeNumber);
    let prevLie = 'Tee', prevRem = +h.yardage, n = 0;
    for (const s of h.strokes) {
      if (s.strokeType === 'DROP') continue; n++;
      if (s.strokeType === 'PENALTY') { out.push([h.holeNumber, par, score, n, 'Penalty', '', prevLie, 'Drop', '', '', '', '', 'yes', M(h.yardage) + ' m'].join(',')); continue; }
      if (s.strokeType !== 'STROKE') problems.push('H' + h.holeNumber + ' ' + s.strokeType);
      const start = surface(s.fromLocation, s.fromLocationCode) || prevLie;
      const holed = !!s.finalStroke && !s.distanceRemaining;
      const end = holed ? 'In The Hole' : surface(s.toLocation, s.toLocationCode);
      const onGreen = start === 'Green';
      const startYd = n === 1 && start === 'Tee' ? +h.yardage : prevRem;
      const rem = holed ? 0 : PGA.toYards(s.distanceRemaining), shot = PGA.toYards(s.distance);
      out.push([h.holeNumber, par, score, n, LIV.categoryOf(start, n, par, startYd), '', start, end || 'Other', fmt(startYd, onGreen), onGreen ? fmt(startYd, true) : '', fmt(shot, onGreen), holed ? '' : fmt(rem, end === 'Green'), 'no', M(h.yardage) + ' m'].join(','));
      prevLie = end || prevLie; prevRem = rem;
    }
    if (n !== score) problems.push('H' + h.holeNumber + ': ' + n + ' strokes, score ' + score);
  }
  if (holes.length !== 18) problems.push(holes.length + ' holes');
  if (total !== CARD[r]) problems.push('adds to ' + total + ', card ' + CARD[r]);
  fs.writeFileSync('r' + r + '.csv', out.join('\n') + '\n');
  fs.writeFileSync('r' + r + '-order.json', JSON.stringify(order));
  console.log('R' + r, 'start H' + order[0], 'total', total, '| problems', problems.length ? problems : 'none');
}
