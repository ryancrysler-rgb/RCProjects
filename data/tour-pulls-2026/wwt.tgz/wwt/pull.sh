#!/bin/bash
# usage: PK=... pull.sh  — every made-cut player, rounds 1-4, skipping files already pulled
B=https://api.parse.bot/scraper/7f7abae7-47ab-46b0-a568-ad8117732086
cd "$(dirname "$0")"
one(){ f=raw/$1-$2.json; [ -s "$f" ] && grep -q '"status":"success"' "$f" && return; for t in 1 2 3; do
  c=$(curl -s -o "$f" -w '%{http_code}' -H "X-API-Key: $PK" "$B/get_player_shots_compact?tournament_id=R2026457&player_id=$1&round=$2"); [ "$c" = 200 ] && return; sleep $((t*3)); done; echo "FAIL $1 R$2 $c"; }
export -f one; export B PK
for id in $(cat ids.txt); do for r in 1 2 3 4; do echo "$id $r"; done; done | xargs -P 4 -n 2 bash -c 'one "$0" "$1"'
echo "done: $(ls raw | wc -l) files"
