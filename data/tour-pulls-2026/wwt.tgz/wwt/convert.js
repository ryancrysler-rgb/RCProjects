/* World Wide Technology Championship 2026 (pgatour.com, R2026457): every made-cut round, from parse.bot's
 * get_player_shots_compact, written as the canonical shot table the DP World reader writes (dpworld-adapter readCsv
 * columns), so SC.parse / metrics / nn-grade read it exactly as they read the Abu Dhabi field.
 *   Lies: pgatour.com names a lie by its side ("Right Fairway", "Left Green"); the house reads the surface:
 *   Fairway · Green · Rough · Bunker (greenside and fairway bunkers alike, rev306) · Tee · Other (native area, cart path,
 *   tee outline, unknown — outside the fairway, as the DP World reader reads OTH/OWA/OUK).
 *   PENALTY rows = a penalty stroke (Penalty, start = the lie before, end Drop); DROP rows are not strokes.
 *   Every hole is checked: STROKE + PENALTY rows = the hole score; every round = its card. A mismatch stops. */
'use strict';
const fs = require('fs'), path = require('path');
const E = '/home/user/rc-greenlight/automation/';
const PGA = require(E + 'pgatour-adapter.js'), LIV = require(E + 'liv-adapter.js');
const D = __dirname;
const lb = JSON.parse(fs.readFileSync(D + '/leaderboard.json')).data.players;
const byId = {}; lb.forEach((p) => { byId[p.id] = p; });

function surface(name, code) {
  const n = String(name || ''), c = String(code || '').toUpperCase();
  if (c === 'OTB' || /^tee box$/i.test(n)) return 'Tee';
  if (/bunker/i.test(n)) return 'Bunker';
  if (/fairway/i.test(n)) return 'Fairway';
  if (/green/i.test(n)) return 'Green';
  if (/rough/i.test(n)) return 'Rough';
  if (!n && !c) return '';
  return 'Other';
}
const fmt = (yd, onGreen) => (yd == null ? '' : onGreen ? (Math.round(yd * 3 * 10) / 10) + ' ft' : (Math.round(yd * 10) / 10) + ' yds');

const COLS = ['Hole', 'Par', 'Score', 'Shot', 'Category', 'Club', 'Start Lie', 'End Lie', 'Start Distance', 'Putt Distance', 'Shot Distance', 'Proximity', 'Penalty', 'Hole Yardage'];
const official = { players: {}, holestats: {}, tee: {} };
for (const r of ['1', '2', '3', '4']) {
  const cs = JSON.parse(fs.readFileSync(D + '/cs' + r + '.json')).data;
  const holes = (cs.courses || cs.data.courses)[0].holes;
  official.holestats[r] = {}; official.tee[r] = {};
  holes.forEach((h) => { official.holestats[r][h.holeNumber] = { par: +h.par, avg: +h.scoringAverageDiff }; official.tee[r][h.holeNumber] = +h.yardage; });
}
fs.mkdirSync(D + '/csv', { recursive: true });
const problems = [];
for (const f of fs.readdirSync(D + '/raw').sort()) {
  const [pid, rnd] = f.replace('.json', '').split('-');
  const p = byId[pid];
  const data = JSON.parse(fs.readFileSync(D + '/raw/' + f)).data;
  const out = [COLS.join(',')];
  let total = 0;
  for (const h of data.holes) {
    const score = +h.score, par = +h.par;
    total += score;
    let prevLie = 'Tee', prevRem = +h.yardage, n = 0;
    for (const s of h.strokes) {
      if (s.strokeType === 'DROP') continue;
      n++;
      if (s.strokeType === 'PENALTY') {
        out.push([h.holeNumber, par, score, n, 'Penalty', '', prevLie, 'Drop', '', '', '', '', 'yes', h.yardage + ' yds'].join(','));
        continue;
      }
      const start = surface(s.fromLocation, s.fromLocationCode) || prevLie;
      const holed = !!s.finalStroke && !s.distanceRemaining;
      const end = holed ? 'In The Hole' : surface(s.toLocation, s.toLocationCode);
      const onGreen = start === 'Green';
      const startYd = n === 1 && start === 'Tee' ? +h.yardage : prevRem;
      const rem = holed ? 0 : PGA.toYards(s.distanceRemaining);
      const shot = PGA.toYards(s.distance);
      const cat = LIV.categoryOf(start, n, par, startYd);
      out.push([h.holeNumber, par, score, n, cat, '', start, end || 'Other', fmt(startYd, onGreen), onGreen ? fmt(startYd, true) : '',
        fmt(shot, onGreen), holed ? '' : fmt(rem, end === 'Green'), 'no', h.yardage + ' yds'].join(','));
      prevLie = end || prevLie; prevRem = rem;
    }
    if (n !== score) problems.push(p.displayName + ' R' + rnd + ' H' + h.holeNumber + ': ' + n + ' strokes, score ' + score);
  }
  const card = +p.rounds[+rnd - 1];
  if (total !== card) problems.push(p.displayName + ' R' + rnd + ': holes add to ' + total + ', card ' + card);
  official.players[pid] = official.players[pid] || { name: p.displayName, position: p.position, total: p.totalStrokes, cards: {} };
  official.players[pid].cards[rnd] = {}; data.holes.forEach((h) => { official.players[pid].cards[rnd][h.holeNumber] = +h.score; });
  fs.writeFileSync(D + '/csv/' + pid + '-' + rnd + '.csv', out.join('\n') + '\n');
}
fs.writeFileSync(D + '/official.json', JSON.stringify(official));
console.log('rounds', fs.readdirSync(D + '/csv').length, '| problems', problems.length);
problems.slice(0, 20).forEach((x) => console.log('  ' + x));
