/* Blades Brown · WWT Championship 2026 · the four-round tournament summary, two pages (Rev 363 anatomy).
 * Page 1 = summary-d.json (counted in code) + the prose below, every figure in it taken from compute output and asserted here.
 * Page 2 = summary-rules.js on the same four rounds. */
'use strict';
const fs = require('fs');
const E = '/home/user/rc-greenlight/automation/';
const SC = require(E + 'shot-csv.js'), SR = require(E + 'summary-rules.js'), SLOT = require(E + 'data-slot.js');
const D = __dirname;
const d = JSON.parse(fs.readFileSync(D + '/summary-d.json'));
const A = (c, m) => { if (!c) throw new Error('prose check failed: ' + m); };

// the figures the prose leans on
A(d.toPar === -23 && d.total === 265 && d.scores.join() === '66,68,68,63', 'card');
A(d.facets.ott.fw === '53/56' && d.facets.ott.driver === '31 / 31' && d.facets.arg.fullWedge === '19 / 22', 'fairways + bag');
const p5 = d.parTypes.find((p) => p.par === 5); A(p5.holes === 16 && p5.toPar === -15, 'par 5s');
A(d.facets.putt.in6 === '47 / 48' && d.facets.putt.cfp === '8 of 12' && d.facets.putt.three === 2, 'putting');
A(d.facets.arg.chips === '23 / 25' && d.facets.arg.cfb === '0 of 2', 'short game');
A(Math.abs(d.diffPerRound - 3.41) < 0.005, 'vs field');
const band = (l) => d.facets.app.bands.find((b) => b[0] === l);
A(band('161–180')[1] === 13 && band('181–200')[1] === 14, 'long bands');

d.kicker = 'Won · −23 · 265 · Ben James also finished on 265';
d.headline = '66 → 68 → 68 → 63: under par every day, a closing 63';
d.story = 'Under par in all four rounds and 3.41 shots a round better than the field. The par 5s carried the week: on the green in three or fewer 16 of 16, 15 under par on them. No double, no penalty stroke, no bogey after a bogey. The closing 63 had 10 birdies.';
d.swot = {
  strengths: [
    '<b>16 of 16 par 5s on the green in three or fewer</b>, 15 under par on them: the week’s scoring, planned hole by hole.',
    '<b>Driver 31 of 31 fairways</b>, 53 of 56 in all, and no regulation approach from the rough: the green was the target every time.',
    '<b>47 of 48 holed inside 6 ft</b>: the short ones held all week.'],
  next: [
    '<b>161–200 yd: 16 of 27 greens</b>, the two busiest bands (7 of 13, 9 of 14). From there, the target that holds the green.',
    '<b>Approach inside 40 ft: 46 of 72 (64%)</b>; the other 74 finishers 68%. From the long bands, the middle of the green first.',
    '<b>Short game inside 6 ft: 10 of 25.</b> 23 of 25 chips and pitches found the green; the next step is the leave.'],
  opportunities: [
    '<b>Birdie or better on 28 of 57 greens hit (49%)</b>; the other 74 finishers 37%. Keep giving the putter those looks.',
    '<b>21 of 24 first putts from 24 ft+ left inside 10%</b>: the lag holds, so the middle of the green is a safe target.',
    '<b>Clutch Factor Putting 8 of 12</b>: the par-saving putts from 5 ft and out went in when they had to.'],
  threats: [
    '<b>Lay-back clubs 22 of 25 fairways</b>: all 3 missed fairways came off a 3-wood or 4-iron. The safer club has to find it.',
    '<b>Clutch Factor Ball Striking 0 of 2</b>: both tee shots into a bunker or native area became bogeys (R3 H5, R4 H4).',
    '<b>Two three-putts, both from 40 ft+</b> (2 of 11): on the longest putts, the leave is the target.']
};
A(d.kicker.length <= 70 && d.headline.length <= 84 && d.story.length <= 330, 'budgets ' + [d.kicker.length, d.headline.length, d.story.length]);
Object.values(d.swot).flat().forEach((b) => A(b.replace(/<\/?b>/g, '').length <= 160, 'swot length: ' + b));

d.note = 'Counted in code from the four PGA TOUR shot files (pgatour.com, R2026457): every hole’s strokes and penalty strokes equal its score and every round equals its official card (66 · 68 · 68 · 63 = 265). No Raw round sheets exist for these rounds, so the facets are counted with the same engine (metrics.js, the Raw builder’s ladder) and the read is written from those counts. FLD = the field’s per-hole scoring average to par from each round’s official course stats, averaged across the four rounds (rounds 1–2 include the players who missed the cut); AVG = the four-round average; DIFF = FLD − average to par; TOT DIFF = the per-round mean vs the field. No clubs in the feed: each club is read from his published stock yardages (MyGolfSpy, his Foresight range video: driver 309, 3-wood 272, 4–9 irons 221·209·196·183·172·155, PW 145, 50° 130, 54° 115, 58° 100; 7-wood and utility not published, so left out) by how far the shot went or its distance to the hole the most likely club; rules 01 and 02 graded literally: one miss is Broken. Clutch Factor Ball Striking and Clutch Factor Putting are proprietary, with no comparator.';
const BG = require('./bag.js');
const rounds = ['1', '2', '3', '4'].map((r) => ({ n: +r, holes: BG.holes(r), source: 'files', order: null }));
const P = SR.page(rounds, { units: 'yd', wedgeMaxYd: BG.WEDGE_MAX });
P.notes = P.notes.map((n) => /stored files/.test(n) ? 'R1–R4: pgatour.com shot data (R2026457), every hole adding up to the official card (66, 68, 68, 63 = 265)' : n);
P.notes.push('Clubs read from his published stock yardages (no clubs in the PGA TOUR feed; 7-wood and utility not published) the most likely club; rules 01 and 02 graded literally: one miss is Broken');
const PF = require('../page2fix.js');
const LIT = PF.fix(P, rounds, BG.WEDGE_MAX);
console.log('literal', JSON.stringify(LIT));
d.rulesPage = P;
let tpl = fs.readFileSync(E + 'tournament-summary.template.html', 'utf8');
A(tpl.includes("var note='Built from the '"), 'template note hook');
tpl = tpl.replace("var note='Built from the '", "var note=d.note?d.note:'Built from the '");
fs.writeFileSync(D + '/Blades Brown - WWT Championship Tournament Summary - Raw.html', SLOT.fill(tpl, d, 'tournament summary'));
console.log('ok · page 2:', P.read.headline, P.read.next ? P.read.next.name : '');
