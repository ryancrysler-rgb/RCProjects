/* Blades Brown's bag, from his published stock yardages (MyGolfSpy, his Foresight range video): one number per club, read as the
 * club's number (the source does not say carry or total). 7-wood (21°) and the utility iron are in the set but have no published
 * yardage, so they are left out — a shot between the 4-iron (221) and the 3-wood (272) reads as one of those two.
 * Wedges by loft: 50° = GW, 54° = SW, 58° = LW. Owner 2026-11-09: "Run his rounds now that you know the bag". */
'use strict';
const E = '/home/user/rc-greenlight/automation/';
const SC = require(E + 'shot-csv.js'), BC = require(E + 'bag-clubs.js');
const fs = require('fs');
const BAG = { units: 'yd', clubs: [['Driver', 309], ['3W', 272], ['4i', 221], ['5i', 209], ['6i', 196], ['7i', 183], ['8i', 172], ['9i', 155],
  ['PW', 145], ['GW', 130], ['SW', 115], ['LW', 100]].map(([name, total]) => ({ name, total, tee: /Driver|W$/.test(name) })) };
const WEDGE_MAX = 145;
function holes(r) { const h = SC.parse(fs.readFileSync(__dirname + '/csv/66417-' + r + '.csv', 'utf8')).holes; const res = BC.apply(h, BAG); h._bag = res; return h; }
module.exports = { BAG, WEDGE_MAX, holes };
