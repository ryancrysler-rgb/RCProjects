const fs=require('fs'),E='/home/user/rc-greenlight/automation/';
global.METRICS=require(E+'metrics.js');
const SC=require(E+'shot-csv.js'),SR=require(E+'summary-rules.js');
const lb=JSON.parse(fs.readFileSync('leaderboard.json')).data.players;
const out=[];
for(const p of lb){ if(p.playerState!=='COMPLETE'&&p.rounds.length<4) continue;
  const rs=[1,2,3,4].map(n=>{const f='csv/'+p.id+'-'+n+'.csv'; if(!fs.existsSync(f)) return null; return SC.parse(fs.readFileSync(f,'utf8')).holes;});
  if(rs.some(r=>!r)) continue;
  const C=rs.map(h=>SR.roundCounts(h,{units:'yd'}));
  const s=k=>C.reduce((a,c)=>[a[0]+c[k][0],a[1]+c[k][1]],[0,0]);
  const g=n=>C.map(c=>c.rules[n]);
  const w150=[0,0], w150r=[];
  rs.forEach(h=>{let m=0;h.forEach(hh=>hh.shots.forEach(x=>{const gr=v=>/^green$/i.test(String(v||'').trim()); if(x.isPutt||x.penalty||x.startYd==null||x.startYd>150||gr(x.startLie))return; const on=x.holed||gr(x.endLie); w150[1]++; if(on)w150[0]++; else m=1;})); w150r.push(m?'broken':'kept');});
  out.push({name:p.displayName,pos:p.position,total:p.total,strokes:p.totalStrokes,rounds:p.rounds,
   in6:s('in6'),w150,w150r,par5:s('par5'),app40:s('app40'),lv24:s('lv24'),sg6:s('sg6'),wAll:s('wAll'),dz:C.reduce((a,c)=>a+c.dzLeaves,0),
   pen:C.reduce((a,c)=>a+c.penalties,0),levels:C.map(c=>String(c.level||'').replace(/\s*STRESS/,'')),r3:g(3),r2:g(2),r4:g(4),
   cfp:s('cfp'),cfbs:s('cfbs'),cfr:s('cfr'),cfdc:s('cfdc'),bc:s('bc'),reset:s('reset'),bogeys:C.reduce((a,c)=>a+c.bogeys,0),doubles:C.reduce((a,c)=>a+c.doubles,0)});
}
fs.writeFileSync('lb-house.json',JSON.stringify(out));
console.log(out.length); console.log(JSON.stringify(out.slice(0,3)));
