/* Blades Brown · World Wide Technology Championship 2026 · four-round tournament summary DATA, counted in code from the four
 * pgatour.com rounds (csv/66417-{1..4}.csv, each hole = its score, each round = its card). No Raw sheet exists for these rounds,
 * so the facets the summary normally reads from the Raw sheets are counted here with the same engine (metrics.js,
 * raw-report-builder ladderCounts, nn-grade) — the counting is printed to compute.json for checking before any prose is written. */
'use strict';
const fs = require('fs');
const E = '/home/user/rc-greenlight/automation/';
const SC = require(E + 'shot-csv.js'), M = require(E + 'metrics.js'), RB = require(E + 'raw-report-builder.js');
const D = __dirname;
const off = JSON.parse(fs.readFileSync(D + '/official.json'));
const BG = require('./bag.js'), NN = require(E + 'nn-grade.js');
const R = ['1', '2', '3', '4'].map((r) => ({ n: +r, holes: BG.holes(r) }));
const frac = (a, b) => ({ made: a, att: b });
const pct = (f) => (f && f.att ? Math.round(100 * f.made / f.att) : null);
const sum = (arr) => arr.reduce((t, f) => ({ made: t.made + f.made, att: t.att + f.att }), { made: 0, att: 0 });
const S = R.map((x) => M.summary(x.holes));
const scores = S.map((s) => s.card.strokes);

// off the tee — driver FIR from the clubs read from the bag (par 4s and 5s)
let drv = { made: 0, att: 0 };
R.forEach((x) => x.holes.forEach((h) => { if (+h.par < 4) return; const t = h.shots[0]; if (t.club !== 'Driver') return; drv.att++; if (/^fairway$/i.test(t.endLie)) drv.made++; }));
let fullW = { made: 0, att: 0 };
R.forEach((x) => NN.wedgeShots(x.holes, { wedgeMaxYd: BG.WEDGE_MAX }).items.forEach((it) => { if (it.tier !== 'f') return; fullW.att++; if (it.onGreen || it.sh.holed) fullW.made++; }));
const fw = S.map((s) => frac(s.fairways.made, s.fairways.att));
let longest = null;
R.forEach((x) => x.holes.forEach((h) => { if (+h.par < 4) return; const t = h.shots[0]; const m = String(t.shotDistance || '').match(/([\d.]+)/); if (m && (!longest || +m[1] > longest.yd)) longest = { yd: Math.round(+m[1]), r: x.n, h: h.hole }; }));
// approach: the published ladder, summed across the rounds (empty bands kept, in order)
const lad = R.map((x) => RB.ladderCounts(x.holes, 'yd'));
const bands = lad[0].map((b, i) => { const n = lad.reduce((t, l) => t + l[i].n, 0), made = lad.reduce((t, l) => t + l[i].made, 0); return [b.label, n, n ? Math.round(100 * made / n) : null, made]; });
// the scoring zone = the first six rungs, under 40 included (raw-report-builder: 160 yd and in)
const in160 = bands.slice(0, 6).reduce((t, b) => ({ made: t.made + b[3], att: t.att + b[1] }), { made: 0, att: 0 });
const gir = S.map((s) => frac(s.gir.made, s.gir.att));
// around the green
const scr = S.map((s) => frac(s.scrambling.made, s.scrambling.att));
let chipsOn = { made: 0, att: 0 };
R.forEach((x) => x.holes.forEach((h) => h.shots.forEach((s) => { if (s.isPutt || s.n === 1 || s.penalty || s.startYd == null || s.startYd > 40) return; chipsOn.att++; if (s.holed || /^green$/i.test(s.endLie)) chipsOn.made++; })));
const cfb = sum(S.map((s) => frac(s.clutchFactorBallStriking.made, s.clutchFactorBallStriking.att)));
// putting
const putts = S.map((s) => s.putts.value);
let three = 0, in6 = { made: 0, att: 0 };
R.forEach((x) => x.holes.forEach((h) => { const p = h.shots.filter((s) => s.isPutt); if (p.length >= 3) three++; p.forEach((s) => { if (s.startFt != null && s.startFt <= 6) { in6.att++; if (s.holed) in6.made++; } }); }));
const cfp = sum(S.map((s) => frac(s.clutchFactorPutting.made, s.clutchFactorPutting.att)));
const bc = sum(S.map((s) => frac(s.birdieConversion.made, s.birdieConversion.att)));
// holes: the four scores + the field's per-round average to par (official course stats), averaged across the four rounds
const holes = [];
for (let k = 1; k <= 18; k++) {
  const par = off.holestats['1'][k].par;
  const sc = R.map((x) => x.holes.find((h) => +h.hole === k).score);
  const avg = sc.reduce((a, b) => a + b, 0) / 4;
  const fld = ['1', '2', '3', '4'].reduce((t, r) => t + off.holestats[r][k].avg, 0) / 4;
  holes.push({ h: k, par, scores: sc, avg, fld, diff: fld - (avg - par) });
}
const parTypes = [3, 4, 5].map((p) => { const hs = holes.filter((h) => h.par === p); const n = hs.length * 4, tot = hs.reduce((t, h) => t + h.scores.reduce((a, b) => a + b, 0), 0); return { par: p, holes: n, avg: tot / n, toPar: tot - p * n }; });
const diffPerRound = holes.reduce((t, h) => t + h.diff, 0);
const counts = S.map((s) => s.counts);

const d = {
  kind: 'summary', player: 'Blades Brown', event: 'World Wide Technology Championship', par: 72, rounds: 4, roundNumbers: [1, 2, 3, 4],
  scores, total: scores.reduce((a, b) => a + b, 0), toPar: scores.reduce((a, b) => a + b, 0) - 288, finish: '1st',
  facets: {
    ott: { fwPct: pct(sum(fw)), fw: sum(fw).made + '/' + sum(fw).att, driver: drv.made + ' / ' + drv.att, byRound: fw.map((f) => pct(f) + '%').join(' · '), longest: longest.yd + ' yd · R' + longest.r + ' H' + longest.h },
    app: { gir: sum(gir).made + '/' + sum(gir).att, bands: bands.map((b) => [b[0], b[1], b[2]]), inside160: in160.made + ' of ' + in160.att, byRound: gir.map((f) => pct(f) + '%').join(' · ') },
    arg: { scrambled: sum(scr).made + '/' + sum(scr).att, missed: sum(scr).att, fullWedge: fullW.made + ' / ' + fullW.att, chips: chipsOn.made + ' / ' + chipsOn.att, byRound: scr.map((f) => f.made + '/' + f.att).join(' · '), cfb: cfb.made + ' of ' + cfb.att },
    putt: { total: putts.reduce((a, b) => a + b, 0), byRound: R.map((x, i) => ({ label: 'R' + x.n + ' · ' + scores[i], val: putts[i] + ' putts · ' + gir[i].made + '/' + gir[i].att })), three, in6: in6.made + ' / ' + in6.att, cfp: cfp.made + ' of ' + cfp.att }
  },
  parTypes, holes, fieldKnown: true, diffPerRound
};
fs.writeFileSync(D + '/summary-d.json', JSON.stringify(d, null, 1));
console.log(JSON.stringify({ drv, fullW, bagNote: R.map((x) => x.holes._bag.filled), scores, toPar: d.toPar, fw: d.facets.ott, gir: d.facets.app.gir, in160: d.facets.app.inside160, bands: d.facets.app.bands, arg: d.facets.arg, putts, three, in6: d.facets.putt.in6, cfp: d.facets.putt.cfp, bc, parTypes, diffPerRound: +diffPerRound.toFixed(2), counts }, null, 0));
