"""Independent recount of every WWT figure we publish, straight from the raw pgatour.com JSON (not the engine)."""
import json, glob, re, collections
lb = {p['id']: p for p in json.load(open('leaderboard.json'))['data']['players']}
W = '66417'
def ft(s):
    s = s or ''
    if 'yd' in s: return float(re.sub(r'[^0-9.]', '', s)) * 3
    f = 0.0
    m = re.search(r'([\d.]+)\s*ft', s); f += float(m.group(1)) if m else 0
    m = re.search(r'([\d.]+)\s*in', s); f += float(m.group(1)) / 12 if m else 0
    return f
def surf(n):
    n = n or ''
    if 'Bunker' in n: return 'B'
    if 'Fairway' in n: return 'F'
    if 'Green' in n: return 'G'
    if 'Rough' in n: return 'R'
    if n == 'Tee Box': return 'T'
    return 'O'
R = collections.defaultdict(lambda: collections.Counter())
for f in glob.glob('raw/*.json'):
    pid, rnd = f[4:-5].split('-'); g = 'W' if pid == W else 'F'
    holes = json.load(open(f))['data']['holes']
    c = R[g]
    seq = []
    for h in sorted(holes, key=lambda h: h['holeNumber']):
        par, score = h['par'], int(h['score']); seq.append(score - par)
        st = [s for s in h['strokes'] if s['strokeType'] == 'STROKE']
        tee = st[0]
        if par >= 4:
            c['fwAtt'] += 1; c['fw'] += surf(tee['toLocation']) == 'F'
        # strokes to reach green (count penalty strokes too)
        n = 0; on = None
        for s in h['strokes']:
            if s['strokeType'] == 'DROP': continue
            n += 1
            if s['strokeType'] == 'STROKE' and (surf(s['toLocation']) == 'G' or (s['finalStroke'] and not s['distanceRemaining'])):
                on = n; break
        if par == 5:
            c['p5'] += 1; c['p5in3'] += on is not None and on <= 3; c['p5toPar'] += score - 5
        # putts from green
        start = {}
        for i, s in enumerate(st): start[id(s)] = ft(st[i-1]['distanceRemaining']) if i else None
        putts = [s for s in st if surf(s['fromLocation']) == 'G']
        for i, p in enumerate(putts):
            d = start[id(p)]; holed = p is putts[-1] and p['finalStroke']
            if d <= 6: c['in6Att'] += 1; c['in6'] += holed
            if 3 <= d <= 6: c['in36Att'] += 1; c['in36'] += holed
        if putts:
            d0 = start[id(putts[0])]
            if d0 >= 24:
                c['lvAtt'] += 1
                left = 0 if putts[0]['finalStroke'] else ft(putts[0]['distanceRemaining'])
                c['lv'] += left <= 0.1 * d0
            if d0 <= 25: c['t25Att'] += 1; c['t25'] += len(putts) >= 3
            if d0 >= 40: c['p40Att'] += 1; c['p40'] += len(putts) >= 3
        # short game: off the green, not tee shot, start within 40 yd
        prev = tee
        for i, s in enumerate(st):
            if i == 0: continue
            startyd = ft(st[i-1]['distanceRemaining']) / 3
            if surf(s['fromLocation']) == 'G' or startyd > 40: continue
            c['chipAtt'] += 1; c['chip'] += surf(s['toLocation']) == 'G' or (s['finalStroke'] and not s['distanceRemaining'])
    # reset hole in hole order
    for a, b in zip(seq, seq[1:]):
        if a > 0: c['resetAtt'] += 1; c['reset'] += b > 0
    c['bogeys'] += sum(1 for x in seq if x > 0)
    c['doubles'] += sum(1 for x in seq if x >= 2)
    c['rounds'] += 1
for g in 'WF':
    c = R[g]; pc = lambda a, b: f"{c[a]}/{c[b]} = {100*c[a]/c[b]:.1f}%" if c[b] else '-'
    print(g, 'rounds', c['rounds'], '| fairways', pc('fw','fwAtt'), '| par5 on in 3', pc('p5in3','p5'), 'toPar', c['p5toPar'],
          '| reset', pc('reset','resetAtt'), '| in6', pc('in6','in6Att'), '| 3-6', pc('in36','in36Att'), '| lag24', pc('lv','lvAtt'),
          '| 3putt<=25', pc('t25','t25Att'), '| 3putt40+', pc('p40','p40Att'), '| chips on green', pc('chip','chipAtt'), '| bogeys', c['bogeys'], 'doubles', c['doubles'])
