// R2 Raw + page 2 for one player. node build.js <pid> "<Name>" <courseId> <par> <score> "<toPar>" <startHole> "<note>" "<total line>"
const path=require('path'),fs=require('fs');const ROOT='/home/user/rc-greenlight';const A=f=>require(path.join(ROOT,'automation',f));
const [pid,PLAYER,CID,PAR,SCORE,TOPAR,START,NOTE]=process.argv.slice(2);const par=+PAR,score=+SCORE,st=+START;
const SC=A('shot-csv.js'),M=A('metrics.js'),RP=A('round-patterns.js'),RB=A('raw-report-builder.js'),SR=A('summary-rules.js'),SLOT=A('data-slot.js'),BC=A('bag-clubs.js');
const D=__dirname+'/'+pid;fs.mkdirSync(D,{recursive:true});
const NAME=PLAYER+' - RSM Classic R3';
fs.copyFileSync(__dirname+'/../'+pid+'-r3.csv',D+'/'+NAME+' - shot by shot.csv');
const load=()=>{const H=SC.parse(fs.readFileSync(D+'/'+NAME+' - shot by shot.csv','utf8')).holes;const BAG=JSON.parse(fs.readFileSync(__dirname+'/bag.json','utf8'));H._bag=BC.apply(H,BAG.bag);
 const c=JSON.parse(fs.readFileSync(__dirname+'/../pull/cs3.json','utf8')).data.courses.find(x=>x.courseId===CID);
 for(const h of H){const fh=c.holes.find(x=>x.holeNumber===h.hole);if(fh&&fh.par===h.par)h.vfld=String(Math.round((fh.scoringAverage-h.score)*1000)/1000);}
 return {H,BAG,c};};
let {H,BAG,c}=load();
const order=Array.from({length:18},(_,i)=>((st-1+i)%18)+1);
const sm=M.summary(H);const p=RP.patterns(H,{startHole:st});p.response=M.clutchFactorResponse(H,{order:p.order});p.closing=M.clutchFactorClosing(H,{behind:0,order:p.order});
const aiF=D+'/ai.json';const ai=fs.existsSync(aiF)?JSON.parse(fs.readFileSync(aiF,'utf8')):{keyShots:{},decisions:{},swot:{strengths:[],next:[],opportunities:[],threats:[]},footnote:''};
const rd=RB.buildRawReportData({player:PLAYER,event:'RSM Classic 2026 · Round 3',par,round:{score,toPar:TOPAR,note:NOTE},
 putts:sm.putts.value,birdies:sm.counts.birdies,holes:H,plan:null,facets:null,summary:sm,patterns:p,wedgeMaxYd:BAG.wedgeMaxYd,
 totals:{fw:sm.fairways.display,par,yards:H.reduce((a,h)=>a+(h.yards||0),0)||'',gir:sm.gir.display,putts:sm.putts.value,flags:''},
 footnote:ai.footnote,identity:'RC Greenlight · Raw',decisionGained:null,inBand:null,bandsFrom:null,ai,bag:BAG.bag});
fs.writeFileSync(D+'/rd.json',JSON.stringify(rd,null,1));
const tpl=fs.readFileSync(path.join(ROOT,'automation/raw-report.template.html'),'utf8');
fs.writeFileSync(D+'/'+NAME+' - Raw.html',tpl.replace('<!--__DATA_SLOT__-->','<script>window.__REPORT_DATA='+JSON.stringify(rd).replace(/</g,'\\u003c')+';</script>').replace(/__SITE_URL__/g,'file://'+ROOT));
console.log('rules',JSON.stringify(rd.rules.map(r=>[r.n,r.state,r.detail||r.note||''])));
console.log('tb',JSON.stringify(rd.topBottom&&{best:rd.topBottom.best,worst:rd.topBottom.worst}));
// page 2
({H}=load());
const P=SR.page([{n:3,holes:H,source:'files',order}],{units:'yd',wedgeMaxYd:BAG.wedgeMaxYd});
P.notes=P.notes.map(n=>/stored files/.test(n)?`R3: pgatour.com (R2026493, ${c.courseName.replace('Sea Island Golf Club - ','')}, par ${par}), every hole matching the card (${score}); field = ${c.courseName.replace('Sea Island Golf Club - ','')} R3 hole averages`:n).filter(n=>!/playing order from hole/.test(n));
P.notes.push('clubs: a standard tour set at TrackMan tour-average carries, an estimate (no set makeup read)');
P.groups=P.groups.filter(g=>!/^The purpose/.test(g.title));P.notes.push('the worst-round row needs two graded rounds');
for(const g of P.groups)for(const r of g.rules)for(const row of r.rows)if(/^Misses on the long side/.test(row.label||'')){row.label='Misses long / open side';row.why='no pins';}
P.notes=P.notes.filter(n=>!/^not measured: the long side/.test(n)&&!/^long par 4s: a reading/.test(n));
const t2=fs.readFileSync(path.join(ROOT,'automation/tournament-summary.template.html'),'utf8');
fs.writeFileSync(D+'/p2.html',SLOT.fill(t2,{player:PLAYER,event:'RSM Classic 2026 · Round 3',rounds:1,roundNumbers:[3],scores:[score],total:score,par,facets:{},holes:[],swot:{},rulesPage:P},'tournament summary'));
console.log('p2',P.read.headline,'|',JSON.stringify(P.read.next));
